(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/es5/build lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ namespace object ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./1fcq78hk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1fcq78hk.entry.js",
		"common",
		102
	],
	"./1fcq78hk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1fcq78hk.sc.entry.js",
		"common",
		103
	],
	"./2i50w2lv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2i50w2lv.entry.js",
		"common",
		104
	],
	"./2i50w2lv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2i50w2lv.sc.entry.js",
		"common",
		105
	],
	"./39fhulxe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/39fhulxe.entry.js",
		"common",
		106
	],
	"./39fhulxe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/39fhulxe.sc.entry.js",
		"common",
		107
	],
	"./3hbcnxuc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3hbcnxuc.entry.js",
		"common",
		54
	],
	"./3hbcnxuc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3hbcnxuc.sc.entry.js",
		"common",
		55
	],
	"./3kzauze7.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3kzauze7.entry.js",
		"common",
		56
	],
	"./3kzauze7.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3kzauze7.sc.entry.js",
		"common",
		57
	],
	"./3pkkvczk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3pkkvczk.entry.js",
		0,
		"common",
		128
	],
	"./3pkkvczk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3pkkvczk.sc.entry.js",
		0,
		"common",
		129
	],
	"./5zcdwzsx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5zcdwzsx.entry.js",
		"common",
		10
	],
	"./5zcdwzsx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5zcdwzsx.sc.entry.js",
		"common",
		11
	],
	"./6kgso7pq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6kgso7pq.entry.js",
		"common",
		12
	],
	"./6kgso7pq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6kgso7pq.sc.entry.js",
		"common",
		13
	],
	"./7hlpr3fd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7hlpr3fd.entry.js",
		0,
		"common",
		130
	],
	"./7hlpr3fd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7hlpr3fd.sc.entry.js",
		0,
		"common",
		131
	],
	"./8wdovu8e.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8wdovu8e.entry.js",
		"common",
		58
	],
	"./8wdovu8e.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8wdovu8e.sc.entry.js",
		"common",
		59
	],
	"./admmxern.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/admmxern.entry.js",
		"common",
		60
	],
	"./admmxern.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/admmxern.sc.entry.js",
		"common",
		61
	],
	"./aubabxbm.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/aubabxbm.entry.js",
		"common",
		14
	],
	"./aubabxbm.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/aubabxbm.sc.entry.js",
		"common",
		15
	],
	"./azzrjyyu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/azzrjyyu.entry.js",
		0,
		"common",
		132
	],
	"./azzrjyyu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/azzrjyyu.sc.entry.js",
		0,
		"common",
		133
	],
	"./b65tzyas.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b65tzyas.entry.js",
		"common",
		16
	],
	"./b65tzyas.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b65tzyas.sc.entry.js",
		"common",
		17
	],
	"./bb7q7tld.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bb7q7tld.entry.js",
		"common",
		108
	],
	"./bb7q7tld.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bb7q7tld.sc.entry.js",
		"common",
		109
	],
	"./bcmaaa8l.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bcmaaa8l.entry.js",
		"common",
		62
	],
	"./bcmaaa8l.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bcmaaa8l.sc.entry.js",
		"common",
		63
	],
	"./bygik61u.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bygik61u.entry.js",
		"common",
		64
	],
	"./bygik61u.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bygik61u.sc.entry.js",
		"common",
		65
	],
	"./ddlg9urb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ddlg9urb.entry.js",
		"common",
		18
	],
	"./ddlg9urb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ddlg9urb.sc.entry.js",
		"common",
		19
	],
	"./devt5yhg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/devt5yhg.entry.js",
		0,
		"common",
		136
	],
	"./devt5yhg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/devt5yhg.sc.entry.js",
		0,
		"common",
		137
	],
	"./dhprnqol.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dhprnqol.entry.js",
		2,
		"common",
		138
	],
	"./dhprnqol.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dhprnqol.sc.entry.js",
		2,
		"common",
		139
	],
	"./djkq5plb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/djkq5plb.entry.js",
		"common",
		66
	],
	"./djkq5plb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/djkq5plb.sc.entry.js",
		"common",
		67
	],
	"./efdsz9yy.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/efdsz9yy.entry.js",
		"common",
		94
	],
	"./efdsz9yy.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/efdsz9yy.sc.entry.js",
		"common",
		95
	],
	"./eghwkqif.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eghwkqif.entry.js",
		"common",
		20
	],
	"./eghwkqif.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eghwkqif.sc.entry.js",
		"common",
		21
	],
	"./ek05jvfc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ek05jvfc.entry.js",
		"common",
		22
	],
	"./ek05jvfc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ek05jvfc.sc.entry.js",
		"common",
		23
	],
	"./ficmbhoi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ficmbhoi.entry.js",
		2,
		"common",
		140
	],
	"./ficmbhoi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ficmbhoi.sc.entry.js",
		2,
		"common",
		141
	],
	"./fkzdmlip.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fkzdmlip.entry.js",
		142
	],
	"./fkzdmlip.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fkzdmlip.sc.entry.js",
		143
	],
	"./fmzmhk3d.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fmzmhk3d.entry.js",
		"common",
		68
	],
	"./fmzmhk3d.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fmzmhk3d.sc.entry.js",
		"common",
		69
	],
	"./fz2rcnow.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fz2rcnow.entry.js",
		"common",
		70
	],
	"./fz2rcnow.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fz2rcnow.sc.entry.js",
		"common",
		71
	],
	"./gnkkjvvk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gnkkjvvk.entry.js",
		"common",
		72
	],
	"./gnkkjvvk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gnkkjvvk.sc.entry.js",
		"common",
		73
	],
	"./helxzsef.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/helxzsef.entry.js",
		144
	],
	"./helxzsef.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/helxzsef.sc.entry.js",
		145
	],
	"./i5bu78vq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i5bu78vq.entry.js",
		"common",
		74
	],
	"./i5bu78vq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i5bu78vq.sc.entry.js",
		"common",
		75
	],
	"./imcdx1xe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/imcdx1xe.entry.js",
		"common",
		114
	],
	"./imcdx1xe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/imcdx1xe.sc.entry.js",
		"common",
		115
	],
	"./iqlhkurd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iqlhkurd.entry.js",
		"common",
		76
	],
	"./iqlhkurd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iqlhkurd.sc.entry.js",
		"common",
		77
	],
	"./isuxxasv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/isuxxasv.entry.js",
		"common",
		78
	],
	"./isuxxasv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/isuxxasv.sc.entry.js",
		"common",
		79
	],
	"./iwgahuhw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iwgahuhw.entry.js",
		"common",
		24
	],
	"./iwgahuhw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iwgahuhw.sc.entry.js",
		"common",
		25
	],
	"./j20d1ikn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j20d1ikn.entry.js",
		"common",
		80
	],
	"./j20d1ikn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j20d1ikn.sc.entry.js",
		"common",
		81
	],
	"./jzwyowjw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jzwyowjw.entry.js",
		"common",
		26
	],
	"./jzwyowjw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jzwyowjw.sc.entry.js",
		"common",
		27
	],
	"./k6eoch7h.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/k6eoch7h.entry.js",
		0,
		"common",
		146
	],
	"./k6eoch7h.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/k6eoch7h.sc.entry.js",
		0,
		"common",
		147
	],
	"./kgjnfunx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kgjnfunx.entry.js",
		"common",
		28
	],
	"./kgjnfunx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kgjnfunx.sc.entry.js",
		"common",
		29
	],
	"./lb8tayd0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lb8tayd0.entry.js",
		"common",
		116
	],
	"./lb8tayd0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lb8tayd0.sc.entry.js",
		"common",
		117
	],
	"./ldqvnzrr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ldqvnzrr.entry.js",
		"common",
		30
	],
	"./ldqvnzrr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ldqvnzrr.sc.entry.js",
		"common",
		31
	],
	"./llyqw4no.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/llyqw4no.entry.js",
		"common",
		82
	],
	"./llyqw4no.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/llyqw4no.sc.entry.js",
		"common",
		83
	],
	"./lsxwd44p.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lsxwd44p.entry.js",
		"common",
		32
	],
	"./lsxwd44p.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lsxwd44p.sc.entry.js",
		"common",
		33
	],
	"./mf2ayo12.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mf2ayo12.entry.js",
		"common",
		34
	],
	"./mf2ayo12.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mf2ayo12.sc.entry.js",
		"common",
		35
	],
	"./migtpkzd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/migtpkzd.entry.js",
		"common",
		36
	],
	"./migtpkzd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/migtpkzd.sc.entry.js",
		"common",
		37
	],
	"./mo7qeek2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mo7qeek2.entry.js",
		"common",
		118
	],
	"./mo7qeek2.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mo7qeek2.sc.entry.js",
		"common",
		119
	],
	"./mri9bdlj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mri9bdlj.entry.js",
		148
	],
	"./mri9bdlj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mri9bdlj.sc.entry.js",
		149
	],
	"./mrs0ks1r.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mrs0ks1r.entry.js",
		0,
		"common",
		150
	],
	"./mrs0ks1r.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mrs0ks1r.sc.entry.js",
		0,
		"common",
		151
	],
	"./najnlwm4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/najnlwm4.entry.js",
		"common",
		38
	],
	"./najnlwm4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/najnlwm4.sc.entry.js",
		"common",
		39
	],
	"./narso64l.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/narso64l.entry.js",
		0,
		"common",
		110
	],
	"./narso64l.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/narso64l.sc.entry.js",
		0,
		"common",
		111
	],
	"./nqozldol.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nqozldol.entry.js",
		0,
		"common",
		152
	],
	"./nqozldol.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nqozldol.sc.entry.js",
		0,
		"common",
		153
	],
	"./o6zsuoqi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/o6zsuoqi.entry.js",
		"common",
		84
	],
	"./o6zsuoqi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/o6zsuoqi.sc.entry.js",
		"common",
		85
	],
	"./oc7j8k7y.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oc7j8k7y.entry.js",
		"common",
		120
	],
	"./oc7j8k7y.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oc7j8k7y.sc.entry.js",
		"common",
		121
	],
	"./ofd4s8dw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ofd4s8dw.entry.js",
		"common",
		96
	],
	"./ofd4s8dw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ofd4s8dw.sc.entry.js",
		"common",
		97
	],
	"./pd9wflli.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pd9wflli.entry.js",
		"common",
		98
	],
	"./pd9wflli.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pd9wflli.sc.entry.js",
		"common",
		99
	],
	"./pdzm9bfy.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pdzm9bfy.entry.js",
		"common",
		100
	],
	"./pdzm9bfy.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pdzm9bfy.sc.entry.js",
		"common",
		101
	],
	"./r8dtlwvb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r8dtlwvb.entry.js",
		0,
		"common",
		154
	],
	"./r8dtlwvb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r8dtlwvb.sc.entry.js",
		0,
		"common",
		155
	],
	"./rkecsmgc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rkecsmgc.entry.js",
		"common",
		122
	],
	"./rkecsmgc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rkecsmgc.sc.entry.js",
		"common",
		123
	],
	"./rrpxfm2a.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rrpxfm2a.entry.js",
		156
	],
	"./rrpxfm2a.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rrpxfm2a.sc.entry.js",
		157
	],
	"./senscofp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/senscofp.entry.js",
		"common",
		40
	],
	"./senscofp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/senscofp.sc.entry.js",
		"common",
		41
	],
	"./tjefn81q.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tjefn81q.entry.js",
		"common",
		42
	],
	"./tjefn81q.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tjefn81q.sc.entry.js",
		"common",
		43
	],
	"./tlbladaf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tlbladaf.entry.js",
		"common",
		44
	],
	"./tlbladaf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tlbladaf.sc.entry.js",
		"common",
		45
	],
	"./tn7df4wj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tn7df4wj.entry.js",
		"common",
		124
	],
	"./tn7df4wj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tn7df4wj.sc.entry.js",
		"common",
		125
	],
	"./uhyavx6a.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uhyavx6a.entry.js",
		0,
		"common",
		158
	],
	"./uhyavx6a.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uhyavx6a.sc.entry.js",
		0,
		"common",
		159
	],
	"./vompwuhi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vompwuhi.entry.js",
		"common",
		46
	],
	"./vompwuhi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vompwuhi.sc.entry.js",
		"common",
		47
	],
	"./vypdotd0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vypdotd0.entry.js",
		"common",
		48
	],
	"./vypdotd0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vypdotd0.sc.entry.js",
		"common",
		49
	],
	"./wb4mk1b9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wb4mk1b9.entry.js",
		0,
		"common",
		160
	],
	"./wb4mk1b9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wb4mk1b9.sc.entry.js",
		0,
		"common",
		161
	],
	"./whjbxjrd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/whjbxjrd.entry.js",
		0,
		"common",
		112
	],
	"./whjbxjrd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/whjbxjrd.sc.entry.js",
		0,
		"common",
		113
	],
	"./wjdsdnuu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wjdsdnuu.entry.js",
		"common",
		86
	],
	"./wjdsdnuu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wjdsdnuu.sc.entry.js",
		"common",
		87
	],
	"./wrpzmdqx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wrpzmdqx.entry.js",
		"common",
		50
	],
	"./wrpzmdqx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wrpzmdqx.sc.entry.js",
		"common",
		51
	],
	"./wzw9zscm.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wzw9zscm.entry.js",
		0,
		"common",
		162
	],
	"./wzw9zscm.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wzw9zscm.sc.entry.js",
		0,
		"common",
		163
	],
	"./x5xnv4jv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/x5xnv4jv.entry.js",
		0,
		"common",
		164
	],
	"./x5xnv4jv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/x5xnv4jv.sc.entry.js",
		0,
		"common",
		165
	],
	"./xajhwvib.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xajhwvib.entry.js",
		"common",
		88
	],
	"./xajhwvib.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xajhwvib.sc.entry.js",
		"common",
		89
	],
	"./xo7dncgt.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xo7dncgt.entry.js",
		"common",
		90
	],
	"./xo7dncgt.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xo7dncgt.sc.entry.js",
		"common",
		91
	],
	"./yifvz1ud.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yifvz1ud.entry.js",
		"common",
		92
	],
	"./yifvz1ud.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yifvz1ud.sc.entry.js",
		"common",
		93
	],
	"./ymem7pf1.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ymem7pf1.entry.js",
		"common",
		52
	],
	"./ymem7pf1.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ymem7pf1.sc.entry.js",
		"common",
		53
	],
	"./ziv0mko0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ziv0mko0.entry.js",
		"common",
		126
	],
	"./ziv0mko0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ziv0mko0.sc.entry.js",
		"common",
		127
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./home/home.module": [
		"./src/app/home/home.module.ts",
		"home-home-module"
	],
	"./list/list.module": [
		"./src/app/list/list.module.ts",
		"list-list-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return __webpack_require__.e(ids[1]).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    {
        path: 'home',
        loadChildren: './home/home.module#HomePageModule'
    },
    {
        path: 'list',
        loadChildren: './list/list.module#ListPageModule'
    }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\n  <ion-split-pane>\n    <ion-menu>\n      <ion-header>\n        <ion-toolbar>\n          <ion-title>Menu</ion-title>\n        </ion-toolbar>\n      </ion-header>\n      <ion-content>\n        <ion-list>\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages\">\n            <ion-item [routerDirection]=\"'root'\" [routerLink]=\"[p.url]\">\n              <ion-icon slot=\"start\" [name]=\"p.icon\"></ion-icon>\n              <ion-label>\n                {{p.title}}\n              </ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n        </ion-list>\n      </ion-content>\n    </ion-menu>\n    <ion-router-outlet main></ion-router-outlet>\n  </ion-split-pane>\n</ion-app>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");





var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.appPages = [
            {
                title: 'Home',
                url: '/home',
                icon: 'home'
            },
            {
                title: 'List',
                url: '/list',
                icon: 'list'
            }
        ];
        this.initializeApp();
    }
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
        });
    };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html")
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");









var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
            entryComponents: [],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(),
                _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"]
            ],
            providers: [
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\xrserasiya\Downloads\Angular Project\Ionic Apps\Sample\JSONWebapiTokenApp\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map