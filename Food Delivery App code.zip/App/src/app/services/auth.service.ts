import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  url = 'http://localhost:8080/api/';

  constructor(private http: HttpClient) { }

  login(formdata: any): Observable<any> {
    return this.http.post('AuthenticationAPI/authenticate', formdata).pipe(response => {
      return response;
    });
  }

  getAllUsers(): Observable<any> {
    return this.http.get('AuthenticationAPI/getalluser').pipe(response => {
      return response;
    });
  }

  refreshToken(modelData: any) {
    return this.http.post('AuthenticationAPI/refreshtoken', modelData).pipe(response => {
      return response;
    });
  }
}
