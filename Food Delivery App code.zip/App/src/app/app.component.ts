import { Component } from '@angular/core';
import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { LocalstoragedataService } from '../app/common/localstoragedata.service';
import { Router } from '@angular/router';
import { Events } from '@ionic/angular';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html'
})
export class AppComponent {
  public appPages = this.getMenuItems();

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private localstoragedataService: LocalstoragedataService,
    private router: Router,
    private events: Events
  ) {
    this.initializeApp();

    // call at time of login (In login click -> published 'user:login' event)
    events.subscribe('user:login', (user) => {
      this.appPages = this.getMenuItems();
    });
    // call at time of login (In logout click -> published 'user:logout' event)
    events.subscribe('user:logout', (user) => {
      this.appPages = this.getMenuItems();
    });
  }

  getMenuItems() {
    return [
      {
        title: 'Home',
        url: '/home',
        icon: 'home',
        isVisible: !this.isMenuVisible()
      },
      {
        title: 'List',
        url: '/list',
        icon: 'list',
        isVisible: this.isMenuVisible()
      },
      {
        title: 'Sign In',
        url: '/login',
        icon: 'log-in',
        isVisible: !this.isMenuVisible()
      },
      {
        title: 'Sign Out',
        url: '/logout',
        icon: 'log-out',
        isVisible: this.isMenuVisible()
      }
    ];
  }

  isMenuVisible() {
    return this.localstoragedataService.getloginUserAccessToken() !== null && this.localstoragedataService.getloginUserAccessToken() !== '';
  }

  Logout() {
    this.events.publish('user:logout',  this.localstoragedataService.setLoginUserDataandToken(null));
    this.router.navigate(['login']);
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
}
