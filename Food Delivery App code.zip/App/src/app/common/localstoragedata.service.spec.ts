import { TestBed } from '@angular/core/testing';

import { LocalstoragedataService } from './localstoragedata.service';

describe('LocalstoragedataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LocalstoragedataService = TestBed.get(LocalstoragedataService);
    expect(service).toBeTruthy();
  });
});
