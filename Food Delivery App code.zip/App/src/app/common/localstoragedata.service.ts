import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LocalstoragedataService {

  constructor() { }

  setLoginUserDataandToken(userdata: any) {
    localStorage.setItem('user_storage', JSON.stringify(userdata));
    this.setAccessToken((userdata !== null && userdata !== '') ? userdata.accessToken : '');
    this.setRefreshToken((userdata !== null && userdata !== '') ? userdata.refreshToken : '');
  }

  setAccessToken(accessToken: string) {
    localStorage.setItem('accesstoken', accessToken);
  }

  setRefreshToken(refreshToken: string) {
    localStorage.setItem('refreshtoken', refreshToken);
  }

  getLoginUserData() {
    return JSON.parse(localStorage.getItem('user_storage'));
  }

  getloginUserAccessToken() {
    return localStorage.getItem('accesstoken');
  }

  getloginUserRefreshToken() {
    return localStorage.getItem('refreshtoken');
  }
}
