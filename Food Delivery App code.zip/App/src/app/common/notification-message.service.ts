import { Injectable } from '@angular/core';
import { ToastController } from '@ionic/angular'; // No need to install any package it comes with ionic installation

@Injectable({
  providedIn: 'root'
})
export class NotificationMessageService {

  constructor(private toastController: ToastController) { }

  async showOperationMessagePopup(operationMessage: string,isSuccessMessage: boolean= true) {

    const popupMessageColor = isSuccessMessage ? 'success' : 'danger';
    const toast = await this.toastController.create({
      message: operationMessage,
      duration: 5000,
      position: 'top',
      color: popupMessageColor,
      buttons: [
        {
          // text: 'Done',
          icon: 'close',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        }
      ]
    });
    toast.present();
  }
}
