import {
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor,
    HttpResponse,
    HttpErrorResponse
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { NotificationMessageService } from '../common/notification-message.service';
import { LocalstoragedataService } from './localstoragedata.service';
import {AuthService } from '../services/auth.service';
import { Component, OnInit } from '@angular/core';

@Injectable()
export class ApiInterceptor implements HttpInterceptor {

    constructor(private router: Router, private notificationMessageService: NotificationMessageService,
        private localstoragedataService: LocalstoragedataService, private authService: AuthService) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        const accesstoken = this.localstoragedataService.getloginUserAccessToken();
        // console.log('current AccessToken:' + accesstoken);
        const baseUrl = environment.baseUrl;

        if (request.url.toLowerCase().indexOf('authenticate') === -1) {
            if (accesstoken == null || accesstoken === '') {
                this.localstoragedataService.setLoginUserDataandToken(null);
                this.router.navigate(['login']);
            }
            if (accesstoken) {
                request = request.clone({
                    setHeaders: {
                        'Authorization': 'Bearer ' + accesstoken
                    }
                });
            }
        }

        if (!request.headers.has('Content-Type')) {
            request = request.clone({
                setHeaders: {
                    'content-type': 'application/json'
                }
            });
        }
        request = request.clone({
            headers: request.headers.set('Accept', 'application/json')
        });

        const apiReq = request.clone({ url: `${baseUrl}${request.url}` });

        return next.handle(apiReq).pipe(
            map((event: HttpEvent<any>) => {
                if (event instanceof HttpResponse) {
                    // console.log('event--->>>', event);
                }
                return event;
            }),
            catchError((error: HttpErrorResponse) => {
                if (error.status === 401) {
                    const tokenexpired = error.headers.get('Token-Expired')
                    if (tokenexpired != null && tokenexpired !== '') {
                        this.callRefreshTokenMethod();
                    } else {
                        this.localstoragedataService.setLoginUserDataandToken(null);
                        this.router.navigate(['login']);
                    }
                } else {
                    this.notificationMessageService.showOperationMessagePopup(error.error.Description, false);
                }
                return throwError(error);
            }));

    }

    callRefreshTokenMethod() {
        const accessToken = this.localstoragedataService.getloginUserAccessToken();
        const refreshToken = this.localstoragedataService.getloginUserRefreshToken();        
        const loginUserID = this.localstoragedataService.getLoginUserData().userID;

        const modelData: any = {
            'AccessToken': accessToken,
            'RefreshToken': refreshToken,
            'LoginUserID': loginUserID
        };

        this.authService.refreshToken(modelData).subscribe((res: any) => {
            if (res) {
                const data = JSON.parse(res).Message;
                // console.log('New AccessToken:' + data.accessToken);
                this.localstoragedataService.setAccessToken(data.accessToken);
                this.localstoragedataService.setRefreshToken(data.refreshToken);
            }
          });
    }

}
