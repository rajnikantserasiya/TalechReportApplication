import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { NotificationMessageService } from '../../common/notification-message.service';
import { LocalstoragedataService } from '../../common/localstoragedata.service';
import { Events } from '@ionic/angular';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  constructor(private authService: AuthService, private router: Router, private notificationMessageService: NotificationMessageService,
              private localstoragedataService: LocalstoragedataService, private events: Events) { }

  ngOnInit() {
  }

  login(formdata: any) {
    this.authService.login(formdata.form.value).subscribe((res: any) => {
      console.log(res);
      if (res) {
        this.events.publish('user:login',  this.localstoragedataService.setLoginUserDataandToken(res));
        this.router.navigateByUrl('list');
      }
    });
  }

}
