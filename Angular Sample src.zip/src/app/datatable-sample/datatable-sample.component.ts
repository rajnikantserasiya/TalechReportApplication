import { Component, OnInit } from '@angular/core';
//import { GridFilterPipe } from './grid-filter.pipe';

@Component({
    selector: 'app-datatable-sample',
    templateUrl: './datatable-sample.component.html',
    styleUrls: ['./datatable-sample.component.css']
})
export class DatatableSampleComponent implements OnInit {

    public name: string='';
    public age: string='';
    public blog: string='';
    public data: any;

    constructor() { }

    ngOnInit() {
        this.data = [
            { "name": 'Anil kumar', "Age": 34, "blog": 'https://code-view.com' },
            { "name": 'Sunil Kumar Singh', "Age": 28, "blog": 'https://code-sample.xyz' },
            { "name": 'Sushil Singh', "Age": 24, "blog": 'https://code-sample.com' },
            { "name": 'Aradhya Singh', "Age": 5, "blog": 'https://code-sample.com' },
            { "name": 'Reena Singh', "Age": 28, "blog": 'https://code-sample.com' },
            { "name": 'Alok Singh', "Age": 35, "blog": 'https://code-sample.com' },
            { "name": 'Dilip Singh', "Age": 34, "blog": 'https://code-sample.com' },
            { "name": 'Sushil Singh', "Age": 24, "blog": 'https://code-sample.com' },
            { "name": 'Aradhya Singh', "Age": 5, "blog": 'https://code-sample.com' },
            { "name": 'Reena Singh', "Age": 28, "blog": 'https://code-sample.com' },
            { "name": 'Alok Singh', "Age": 35, "blog": 'https://code-sample.com' },
            { "name": 'Dilip Singh', "Age": 34, "blog": 'https://code-sample.com' },
            { "name": 'Sushil Singh', "Age": 24, "blog": 'https://code-sample.com' },
            { "name": 'Aradhya Singh', "Age": 5, "blog": 'https://code-sample.com' },
            { "name": 'Reena Singh', "Age": 28, "blog": 'https://code-sample.com' },
            { "name": 'Alok Singh', "Age": 35, "blog": 'https://code-sample.com' },
            { "name": 'Dilip Singh', "Age": 34, "blog": 'https://code-sample.com' },
            { "name": 'Alok Singh', "Age": 35, "blog": 'https://code-sample.com' },
            { "name": 'Dilip Singh', "Age": 34, "blog": 'https://code-sample.com' },
            { "name": 'Sushil Singh', "Age": 24, "blog": 'https://code-sample.com' },
            { "name": 'Aradhya Singh', "Age": 5, "blog": 'https://code-sample.com' },
            { "name": 'Reena Singh', "Age": 28, "blog": 'https://code-sample.com' },
            { "name": 'Alok Singh', "Age": 35, "blog": 'https://code-sample.com' },
            { "name": 'Dilip Singh', "Age": 34, "blog": 'https://code-sample.com' },
            { "name": 'Aradhya Singh', "Age": 5, "blog": 'https://code-sample.com' },
            { "name": 'Reena Singh', "Age": 28, "blog": 'https://code-sample.com' },
            { "name": 'Alok Singh', "Age": 35, "blog": 'https://code-sample.com' },
            { "name": 'Dilip Singh', "Age": 34, "blog": 'https://code-sample.com' },
            { "name": 'Alok Singh', "Age": 35, "blog": 'https://code-sample.com' },
            { "name": 'Dilip Singh', "Age": 34, "blog": 'https://code-sample.com' },
            { "name": 'Sushil Singh', "Age": 24, "blog": 'https://code-sample.com' },
            { "name": 'Aradhya Singh', "Age": 5, "blog": 'https://code-sample.com' },
            { "name": 'Reena Singh', "Age": 28, "blog": 'https://code-sample.com' },
            { "name": 'Alok Singh', "Age": 35, "blog": 'https://code-sample.com' },
            { "name": 'Dilip Singh', "Age": 34, "blog": 'https://code-sample.com' },
            { "name": 'Dilip Singh', "Age": 34, "blog": 'https://code-sample.com' },
            { "name": 'Aradhya Singh', "Age": 5, "blog": 'https://code-sample.com' },
            { "name": 'Reena Singh', "Age": 28, "blog": 'https://code-sample.com' },
            { "name": 'Alok Singh', "Age": 35, "blog": 'https://code-sample.com' },
            { "name": 'Dilip Singh', "Age": 34, "blog": 'https://code-sample.com' },
            { "name": 'Alok Singh', "Age": 35, "blog": 'https://code-sample.com' },
            { "name": 'Dilip Singh', "Age": 34, "blog": 'https://code-sample.com' },
            { "name": 'Sushil Singh', "Age": 24, "blog": 'https://code-sample.com' },
            { "name": 'Aradhya Singh', "Age": 5, "blog": 'https://code-sample.com' },
            { "name": 'Reena Singh', "Age": 28, "blog": 'https://code-sample.com' },
            { "name": 'Alok Singh', "Age": 35, "blog": 'https://code-sample.com' },
            { "name": 'Dilip Singh', "Age": 34, "blog": 'https://code-sample.com' },
            { "name": 'Dilip Singh', "Age": 34, "blog": 'https://code-sample.com' },
            { "name": 'Aradhya Singh', "Age": 5, "blog": 'https://code-sample.com' },
            { "name": 'Reena Singh', "Age": 28, "blog": 'https://code-sample.com' },
            { "name": 'Alok Singh', "Age": 35, "blog": 'https://code-sample.com' },
            { "name": 'Dilip Singh', "Age": 34, "blog": 'https://code-sample.com' },
            { "name": 'Alok Singh', "Age": 35, "blog": 'https://code-sample.com' },
            { "name": 'Dilip Singh', "Age": 34, "blog": 'https://code-sample.com' },
            { "name": 'Sushil Singh', "Age": 24, "blog": 'https://code-sample.com' },
            { "name": 'Aradhya Singh', "Age": 5, "blog": 'https://code-sample.com' },
            { "name": 'Reena Singh', "Age": 28, "blog": 'https://code-sample.com' },
            { "name": 'Alok Singh', "Age": 35, "blog": 'https://code-sample.com' },
            { "name": 'Dilip Singh', "Age": 34, "blog": 'https://code-sample.com' }];    
    }
}
