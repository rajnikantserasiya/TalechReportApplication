import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { Tab1Component } from './tab1/tab1.component';
import { Tab2Component } from './tab2/tab2.component';
import { PendingChangesGuard } from './pending-changes.guard';
import { MorrisLineChartComponent } from './morris-line-chart/morris-line-chart.component';
import { ChartsModule } from 'ng2-charts';
import { MorrisJsModule } from 'angular-morris-js';
import { DatatableSampleComponent } from './datatable-sample/datatable-sample.component';
import {DataTableModule} from "angular-6-datatable";
import { GridFilterPipe } from './datatable-sample/grid-filter.pipe';

const appRoutes: Routes = [
    { path: '', component: Tab1Component, pathMatch: 'full' },
    { path: 'Tab2', component: Tab2Component, canDeactivate: [PendingChangesGuard] },
    { path: 'Morris-Line-Chart', component: MorrisLineChartComponent },
    { path: 'DataTable-Sample', component: DatatableSampleComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    Tab1Component,
    Tab2Component,
    MorrisLineChartComponent,
    DatatableSampleComponent,
    GridFilterPipe
  ],
  imports: [
      BrowserModule,
      FormsModule,
      HttpModule,
      RouterModule.forRoot(appRoutes),
      ChartsModule,
      MorrisJsModule,
      DataTableModule
  ],
  providers: [PendingChangesGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
