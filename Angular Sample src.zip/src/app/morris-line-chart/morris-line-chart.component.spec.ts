import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MorrisLineChartComponent } from './morris-line-chart.component';

describe('MorrisLineChartComponent', () => {
  let component: MorrisLineChartComponent;
  let fixture: ComponentFixture<MorrisLineChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MorrisLineChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MorrisLineChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
