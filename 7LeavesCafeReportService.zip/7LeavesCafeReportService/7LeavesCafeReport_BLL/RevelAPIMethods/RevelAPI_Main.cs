﻿using _7LeavesCafeReport_BLL.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7LeavesCafeReport_BLL.RevelAPIMethods
{
    public class RevelAPI_Main
    {

        public async Task RevelAPIMainMethod()
        {
            try
            {
                RevelAPI_Token objRevelAPI_Token = new RevelAPI_Token();
                await objRevelAPI_Token.GetRevelAPI_Token();



            }
            catch (Exception ex)
            {

                LogHelper.Log("Erro in Revel API Run Async method. Error: " + ex.Message);
            }
        }
    }
}
