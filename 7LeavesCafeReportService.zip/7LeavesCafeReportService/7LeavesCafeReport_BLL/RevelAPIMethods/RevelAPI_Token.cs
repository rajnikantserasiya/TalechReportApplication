﻿using _7LeavesCafeReport_BLL.Helpers;
using _7LeavesCafeReport_BLL.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace _7LeavesCafeReport_BLL.RevelAPIMethods
{
    public class RevelAPI_Token
    {
        public async Task<RevelAccountDetails> GetRevelAPI_Token()
        {
            RevelAccountDetails objRevelAccountDetails = new RevelAccountDetails { api_key = "8044c4c6be464ae39bb4955ad4d1f786", api_secret = "cd6180d73146400ead3f7fc07a8cab0800ffffcea37d4b8db72bd12c163009c2" };

            HttpResponseMessage response = await ExecuteClientGetMethod("/resources/AppliedTaxOrder/?format=json&order=39", null);
            if (response.IsSuccessStatusCode)
            {
                string resTokenMethod = await response.Content.ReadAsStringAsync();
            }

            return objRevelAccountDetails;
        }

        public async Task<HttpResponseMessage> ExecuteClientGetMethod(string uri, JObject inputParameters)
        {

            try
            {
                //UriBuilder builder = new UriBuilder("https://xtremepp.revelup.com/resources/Address/?format=json&api_key=8044c4c6be464ae39bb4955ad4d1f786&api_secret=cd6180d73146400ead3f7fc07a8cab0800ffffcea37d4b8db72bd12c163009c2");
                UriBuilder builder = new UriBuilder("https://xtremepp.revelup.com" + uri);
                //builder.Query = "&api_key=8044c4c6be464ae39bb4955ad4d1f786&api_secret=cd6180d73146400ead3f7fc07a8cab0800ffffcea37d4b8db72bd12c163009c2";

                using (HttpClient client = new HttpClient())
                {
                    string api_key = "8044c4c6be464ae39bb4955ad4d1f786";
                    string api_secret = "cd6180d73146400ead3f7fc07a8cab0800ffffcea37d4b8db72bd12c163009c2";

                    client.DefaultRequestHeaders.Add("API-AUTHENTICATION", api_key + ":" + api_secret);
                    HttpResponseMessage response = client.GetAsync(builder.Uri).Result;

                    return response;
                }
                //HttpResponseMessage response = await client.PostAsJsonAsync(uri, inputParameters);
                //return response;
            }
            catch (Exception ex)
            {

                throw;
            }

        }

    }
}
