﻿using _7LeavesCafeReport_BLL.Helpers;
using _7LeavesCafeReport_BLL.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace _7LeavesCafeReport_BLL.RevelAPIMethods
{
    public class RevelAPI_Token
    {
        public async Task<RevelAccountDetails> GetRevelAPI_Token()
        {
            RevelAccountDetails objRevelAccountDetails = new RevelAccountDetails { api_key = "8044c4c6be464ae39bb4955ad4d1f786", api_secret = "cd6180d73146400ead3f7fc07a8cab0800ffffcea37d4b8db72bd12c163009c2" };

            using (HttpClient client = new HttpClient())
            {
                //SetHTTPClientObjectValues(client);
                HttpResponseMessage response = await ExecuteClientGetMethod("/resources/ATGLog/?format=json", null, objRevelAccountDetails.api_key + ":" + objRevelAccountDetails.api_secret);


                if (response.IsSuccessStatusCode)
                {
                    string resTokenMethod = await response.Content.ReadAsStringAsync();
                    //objTalechTokenMethodResult = JsonConvert.DeserializeObject<TalechTokenMethodResult>(resTokenMethod);//await response.Content.ReadAsAsync<TalechTokenMethodResult>();

                    //APICommonHelper.TalechSecurityToken = objTalechTokenMethodResult.access_token;
                }
            }

            return objRevelAccountDetails;
        }

        public async Task<HttpResponseMessage> ExecuteClientGetMethod(string uri, JObject inputParameters, string securityToken = default(string),
          string merchantID = default(string))
        {

            //if (!string.IsNullOrEmpty(securityToken))
            //    client.DefaultRequestHeaders.Add("API-AUTHENTICATION", securityToken);

            try
            {
                UriBuilder builder = new UriBuilder("https://xtremepp.revelup.com/resources/Address/?format=json&api_key=8044c4c6be464ae39bb4955ad4d1f786&api_secret=cd6180d73146400ead3f7fc07a8cab0800ffffcea37d4b8db72bd12c163009c2");
                //builder.Query = "&api_key=8044c4c6be464ae39bb4955ad4d1f786&api_secret=cd6180d73146400ead3f7fc07a8cab0800ffffcea37d4b8db72bd12c163009c2";

                //Create a query
                HttpClient client = new HttpClient();
                HttpResponseMessage response = client.GetAsync(builder.Uri).Result;

                return response;

                //using (StreamReader sr = new StreamReader(result.Content.ReadAsStreamAsync().Result))
                //{
                //    Console.WriteLine(sr.ReadToEnd());
                //}


                //HttpResponseMessage response = await client.PostAsJsonAsync(uri, inputParameters);
                //return response;
            }
            catch (Exception ex)
            {

                throw;
            }

        }


        //public async Task<JsonObject> GetAsync(string uri)
        //{
        //    var httpClient = new HttpClient();
        //    var response = await httpClient.GetAsync(uri);

        //    //will throw an exception if not successful
        //    response.EnsureSuccessStatusCode();

        //    string content = await response.Content.ReadAsStringAsync();
        //    return await Task.Run(() => JsonObject.Parse(content));
        //}
    }


}
