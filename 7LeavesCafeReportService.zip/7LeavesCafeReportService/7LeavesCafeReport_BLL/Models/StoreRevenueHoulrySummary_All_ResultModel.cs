﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7LeavesCafeReport_BLL.Models
{
    public class StoreRevenueHoulrySummary_All_ResultModel
    {
        //public int cost { get; set; }
        public double discount { get; set; }
        //public int employeeGratuity { get; set; }
        //public int gratuity { get; set; }
        public double grossRevenue { get; set; }
        //public int houseAccountBalance { get; set; }
        //public int loyalty { get; set; }
        //public int netGiftCardsRevenue { get; set; }
        //public int netGiftCardsSold { get; set; }
        public double netRevenue { get; set; }
        public double netRevenuePerReceipt { get; set; }      
        public double noneTaxableRevenue { get; set; }
        public double profitability { get; set; }
        public int receipts { get; set; }
        public double refundAmount { get; set; }
        public double refundDiscountAmount { get; set; }
        //public int refundGratuityAmount { get; set; }
        public int refundReceipts { get; set; }
        public double refundTaxAmount { get; set; }
        //public int reportedTax { get; set; }
        public double roundingRevenue { get; set; }
        //public int storeCreditBalance { get; set; }
        //public int storeCreditGranted { get; set; }
        //public int storeCreditOnlyBalance { get; set; }
        //public int storeCreditReceipts { get; set; }
        public double subTotal { get; set; }
        public double tax { get; set; }
        public double taxableRevenue { get; set; }
        public double tip { get; set; }
        public double totalCollected { get; set; }
        //public int totalCustomers { get; set; }

        public string storeName { get; set; }
        public string DateTimestring { get; set; }
        public DateTime RevenueSummaryDatetime { get; set; }
    }

    public class TimePeriodSummary_Individual_ResultModel
    {
        public int sales_transactions { get; set; }
        public double salesTips { get; set; }
        public double totalCollected { get; set; }
        public double refundTips { get; set; }
        public int refund_transactions { get; set; }
        public double salesAmount { get; set; }
        public double refundAmount { get; set; }
        public string storeName { get; set; }
        public string DateTimestring { get; set; }
        public DateTime RevenueSummaryDatetime { get; set; }
        public string PaymentType { get; set; }
    }

    public class ReceiptTypeSummary_ResultModel
    {
        public int counts { get; set; }
        public string storeName { get; set; }
        public string DateTimestring { get; set; }
        public DateTime RevenueSummaryDatetime { get; set; }
        public string PaymentType { get; set; }
    }

    public class OrderSummary_ResultModel 
    {
        public double profitability { get; set; }
        public double storeCreditGrantedAmount { get; set; }
        public double cost { get; set; }
        public double tipAmount { get; set; }
        public double itemCost { get; set; }
        public double noneTaxableRevenue { get; set; }
        public double discountAmount { get; set; }
        public int numberOfGuests { get; set; }
        public double loyaltyAmount { get; set; }
        public double gratuityAmount { get; set; }
        public int receipts { get; set; }
        public double orderSubtotal { get; set; }
        public double revenue { get; set; }
        public double orderAmount { get; set; }
        public double revenuePerGuest { get; set; }
        public double taxAmount { get; set; }
        public double taxableRevenue { get; set; }
        public string storeName { get; set; }
        public string DateTimestring { get; set; }
        public DateTime RevenueSummaryDatetime { get; set; }
        public string TransactionType { get; set; }
    }


}
