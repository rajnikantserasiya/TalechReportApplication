﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7LeavesCafeReport_BLL.Models
{
    public class RevelAccountDetails
    {
        public string api_key { get; set; }
        public string api_secret { get; set; }
    }
}
