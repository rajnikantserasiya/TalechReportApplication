﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7LeavesCafeReport_BLL.Models
{
    public class ResponseCode
    {
        public string desc { get; set; }
        public int statusCode { get; set; }
        public int totalCnt { get; set; }
    }
}
