﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7LeavesCafeReport_BLL.Models
{
    class TalechAllMerchantStoreInfoResult
    {
        public ResponseCode ResponseCode { get; set; }
        public MerchantStoreDetails merchantStoreDetails { get; set; }
    }

    public class MerchantStoreDetails
    {        
        public List<MerchantDetail> merchantDetails { get; set; }
        public string securityToken { get; set; }              
    }

    public class MerchantDetail
    {       
        public int merchantIdentification { get; set; }        
        public List<Store> stores { get; set; }       
    }

    public class Store
    {
        public Address address { get; set; }
        public string businessCloseHour { get; set; }
        public string businessEmail { get; set; }
        public string businessName { get; set; }
        public string businessPhone { get; set; }      
        public int merchantId { get; set; }
        public string mid { get; set; }           
        public string storeName { get; set; }
      
    }

    public class Address
    {
        public string address1 { get; set; }
        public string address2 { get; set; }
        public string city { get; set; }
        public string country { get; set; }            
        public string state { get; set; }
        public string zip { get; set; }
    }
}
