﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7LeavesCafeReport_BLL.Models
{
    public class OrderDetail
    {
        public double discountAmt { get; set; }
        public string name { get; set; }
        public double price { get; set; }
        public double tax { get; set; }
        public int categoryId { get; set; }
        public double quantity { get; set; }

        public double printedQuantity { get; set; }
        public double refundedPrice { get; set; }
        public double refundedQuantity { get; set; }

        public List<AddOns> addOns { get; set; }

    }

    public class PaymentDetail
    {
        public string cardType { get; set; }
        public string paymentType { get; set; }

    }

    public class Order
    {
        public string orderType { get; set; }
        public string orderCreationTime { get; set; }
        public List<OrderDetail> orderDetails { get; set; }
        public List<PaymentDetail> paymentDetails { get; set; }
        public double tipsAmount { get; set; }
    }


    public class OrderDetailsResultModel
    {
        public Order Order { get; set; }
        public ResponseCode ResponseCode { get; set; }
        public string EmployeeName { get; set; }
        public string StoreName { get; set; }
    }

    public class OrderDetailsExportFields
    {
        public string orderID { get; set; }
        public string TicketNo { get; set; }
        public string Type { get; set; }
        public string Employee { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }
        public string Store { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string ItemName { get; set; }
        public string PaymentType { get; set; }
        public string TransactionType { get; set; }
        public string CreditType { get; set; }
        public double GrossSale { get; set; }
        public double Discounts { get; set; }
        public double Refunds { get; set; }
        public double NetSale { get; set; }
        public double Tax { get; set; }
        public double Total { get; set; }
        public double QtySold { get; set; }
        public double Tips { get; set; }

    }

    public class AddOns
    {
        public double discountAmt { get; set; }
        public string name { get; set; }
        public double price { get; set; }
        public double tax { get; set; }
        public int categoryId { get; set; }
        public double quantity { get; set; }
        public double printedQuantity { get; set; }
        public double refundedPrice { get; set; }
        public double refundedQuantity { get; set; }
    }

    public class OrderHistoryInputParametersModel
    {
        public int offset { get; set; }
        public int limit { get; set; }
        //public string searchString { get; set; }
        public string startDate { get; set; }
        public string endDate { get; set; }
        //public string[] paymentTypes { get; set; }
        public string[] orderStatus { get; set; }
        public string[] transactionTypes { get; set; }
        public int[] storeIds { get; set; }
        public string orderBy { get; set; }
        //public int userId { get; set; }
        public bool hideRefund { get; set; } // To display only sales transaction
        public bool hideSale { get; set; } // To display only refund transaction
        public bool onlySplitCheck { get; set; } // To display only split check transaction


    }

    public class OrderHistorySearchCriteria
    {
        public OrderHistoryInputParametersModel searchCriteria { get; set; }

    }


    public class OrderHistoryResultModel
    {
        public string orderId { get; set; }
        public string transactionCode { get; set; }
        public double amount { get; set; }
        public double discount { get; set; }
        public string listOfItems { get; set; }
        public double revenue { get; set; }
        public double subTotal { get; set; }
        public double tip { get; set; }
        public double tax { get; set; }
        public string orderType { get; set; }
        public string paymentType { get; set; }
        public double refundAmount { get; set; }
        public double refundRevenue { get; set; }
        //public string Employee { get; set; }
        //public string storeName { get; set; }
        public string orderDate { get; set; }
        public string userFirstName { get; set; }
        public string userLastName { get; set; }
        public List<PaymentInfo> paymentInfo { get; set; }
    }


    public class PaymentInfo
    {
        public string transactionType { get; set; }
    }

    public class OrderHistoryFullObject
    {
        //public SearchResult searchResult { get; set; }
        public ResponseCode ResponseCode { get; set; }
    }

    public class OrderDetails
    {
        public string orderId { get; set; }
    }

}
