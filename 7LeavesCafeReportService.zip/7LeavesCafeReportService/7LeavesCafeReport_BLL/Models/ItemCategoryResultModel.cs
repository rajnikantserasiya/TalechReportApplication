﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7LeavesCafeReport_BLL.Models
{
    class ItemCategoryResultModel
    {
        public int categoryId { get; set; }
        public string categoryType { get; set; }
        public string name { get; set; }
    }
}
