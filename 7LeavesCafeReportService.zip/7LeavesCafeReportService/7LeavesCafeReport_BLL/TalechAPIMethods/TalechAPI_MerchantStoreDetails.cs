﻿using _7LeavesCafeReport_BLL.Helpers;
using _7LeavesCafeReport_BLL.Models;
using _7LeavesCafeReport_DAL;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace _7LeavesCafeReport_BLL.TalechAPIMethods
{
    public class TalechAPI_MerchantStoreDetails
    {

        public async Task<List<TalechMerchantStoreDetails>> GetAllMerchantStoreDetails()
        {
            List<TalechMerchantStoreDetails> lstMerchantdetailsObj = new List<TalechMerchantStoreDetails>();
            TalechAPI_Token objTalechAPI_Token = new TalechAPI_Token();

            using (HttpClient client = new HttpClient())
            {
                objTalechAPI_Token.SetHTTPClientObjectValues(client);
                HttpResponseMessage response = await objTalechAPI_Token.ExecuteClientPostMethod("authentication/getAllMerchantStoreInfo", null, client, APICommonHelper.TalechSecurityToken);
                if (response.IsSuccessStatusCode)
                {
                    objTalechAPI_Token.SetRefreshToken(response);

                    var objRes = await response.Content.ReadAsStringAsync();
                    TalechAllMerchantStoreInfoResult objResult = JsonConvert.DeserializeObject<TalechAllMerchantStoreInfoResult>(await response.Content.ReadAsStringAsync());

                    if (objResult.ResponseCode.statusCode == 200 && objResult.merchantStoreDetails != null && objResult.merchantStoreDetails.merchantDetails != null)
                    {                       

                        foreach (var objMerchantDetails in objResult.merchantStoreDetails.merchantDetails)
                        {
                            TalechMerchantStoreDetails obj = new TalechMerchantStoreDetails();
                            obj.merchantIdentification = objMerchantDetails.merchantIdentification.ToString();
                            obj.merchantStoreName = objMerchantDetails.stores.FirstOrDefault().storeName;                           

                            lstMerchantdetailsObj.Add(obj);
                        }

                        //if (lstMerchantdetailsObj.Count() == 9)
                        //{
                        //    TalechMerchantStoreDetails obj = new TalechMerchantStoreDetails();
                        //    obj.merchantIdentification = "782465";
                        //    obj.merchantStoreName = "Artesia";
                        //    //obj.storeId = 1;
                        //    //obj.merchantIdentification = 14847;

                        //    lstMerchantdetailsObj.Add(obj);

                        //    TalechMerchantStoreDetails obj1 = new TalechMerchantStoreDetails();
                        //    obj1.merchantIdentification = "304267";
                        //    obj1.merchantStoreName = "Huntington Beach";
                        //    //obj1.storeId = 1;
                        //    //obj1.merchantId = 8457;

                        //    lstMerchantdetailsObj.Add(obj1);
                        //}

                        #region Download Excel for Merchant Store details

                        DataTable dtMerchantDetails = new DataTable("Merchant_Store_Details");
                        dtMerchantDetails.Columns.Add("StoreName");
                        //dtMerchantDetails.Columns.Add("MId");
                        dtMerchantDetails.Columns.Add("MerchantID");
                        dtMerchantDetails.Columns.Add("MerchantIdentification");
                        dtMerchantDetails.Columns.Add("Address1");
                        dtMerchantDetails.Columns.Add("Address2");
                        dtMerchantDetails.Columns.Add("City");
                        dtMerchantDetails.Columns.Add("Country");
                        dtMerchantDetails.Columns.Add("StateName");
                        dtMerchantDetails.Columns.Add("Zip");
                        dtMerchantDetails.Columns.Add("BusinessCloseHour");
                        dtMerchantDetails.Columns.Add("BusinessEmail");
                        dtMerchantDetails.Columns.Add("BusinessName");
                        dtMerchantDetails.Columns.Add("BusinessPhone");
                        //dtMerchantDetails.Columns.Add("Currency");

                        foreach (var objMerchantDetails in objResult.merchantStoreDetails.merchantDetails)
                        {
                            try
                            {
                                DataRow dr = dtMerchantDetails.NewRow();

                                var storeInfo = objMerchantDetails.stores.FirstOrDefault();
                                var addressInfo = storeInfo.address;

                                dr["StoreName"] = storeInfo.storeName;
                               // dr["MId"] = Convert.ToInt64(storeInfo.mid);
                                dr["MerchantID"] = Convert.ToInt64(storeInfo.merchantId);
                                dr["MerchantIdentification"] = Convert.ToInt64(objMerchantDetails.merchantIdentification);
                                dr["Address1"] = addressInfo.address1;
                                dr["Address2"] = addressInfo.address2;
                                dr["City"] = addressInfo.city;
                                dr["Country"] = addressInfo.country;
                                dr["StateName"] = addressInfo.state;
                                dr["Zip"] = addressInfo.zip;
                                dr["BusinessCloseHour"] = storeInfo.businessCloseHour;
                                dr["BusinessEmail"] = storeInfo.businessEmail;
                                dr["BusinessName"] = storeInfo.businessName;
                                dr["BusinessPhone"] = storeInfo.businessPhone;
                                //dr["Currency"] = storeInfo.currency;

                                dtMerchantDetails.Rows.Add(dr);
                            }
                            catch (Exception ex)
                            {
                                
                                throw;
                            }
                        }

                        MerchantStoreDetailsDAL objMerchantStoreDetailsDAL = new MerchantStoreDetailsDAL();
                        objMerchantStoreDetailsDAL.SaveAllMerchantStoreDetails(dtMerchantDetails);

                        //using (var package = new ExcelPackage())
                        //{
                        //    // Add a new worksheet to the empty workbook
                        //    ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Merchant Store Details");
                        //    worksheet.Cells["A1"].LoadFromDataTable(dtMerchantDetails, true, TableStyles.Light9);
                        //    worksheet.Cells.AutoFitColumns(0);

                        //    FileInfo objFile = GetFileInfo(AppDomain.CurrentDomain.BaseDirectory, dtMerchantDetails.TableName + ".xlsx");
                        //    package.SaveAs(objFile);
                        //} 
                        #endregion

                    }
                }
            }

            return lstMerchantdetailsObj;
        }
    }
}
