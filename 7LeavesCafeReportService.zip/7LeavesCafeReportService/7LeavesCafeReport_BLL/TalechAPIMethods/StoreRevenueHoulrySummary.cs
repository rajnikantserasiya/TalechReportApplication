﻿using _7LeavesCafeReport_BLL.Helpers;
using _7LeavesCafeReport_BLL.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using FetchDataFromTalechPOS_BLL;
using OfficeOpenXml;
using System.Data;
using System.IO;
using OfficeOpenXml.Table;
using System.Drawing;
using _7LeavesCafeReport_DAL;

namespace _7LeavesCafeReport_BLL.TalechAPIMethods
{
    public class StoreRevenueHoulrySummary
    {
        public async Task<int> SaveStoreRevenueHourlySummaryByCriteria(List<TalechMerchantStoreDetails> lstAllMerchantStoreInformation, string startdate, string enddate)
        {
            try
            {
                List<StoreRevenueHoulrySummary_All_ResultModel> lstHourlySummary_All = new List<StoreRevenueHoulrySummary_All_ResultModel>();
                List<TimePeriodSummary_Individual_ResultModel> lstHourlySummary_Individual = new List<TimePeriodSummary_Individual_ResultModel>();
                List<ReceiptTypeSummary_ResultModel> lstReceiptTypeSummary = new List<ReceiptTypeSummary_ResultModel>();
                List<OrderSummary_ResultModel> lstOrderSummary = new List<OrderSummary_ResultModel>();
                TalechAPI_Token objTalechAPI_Token = new TalechAPI_Token();
                StoreRevenueHoulrySummaryInputParameterModel objReportSearchCriteria = new StoreRevenueHoulrySummaryInputParameterModel();
                objReportSearchCriteria.searchCriteria = new HoulrySummaryInputParameterModel();

                objReportSearchCriteria.searchCriteria =
                 new HoulrySummaryInputParameterModel()
                 {
                     startDate = startdate,
                     endDate = enddate,
                     granularity = 2, //1 Daily, 2 Hourly, 4 - Monthly
                     includeShiftsData = false,
                     includedReports = new int[] { 103, 101 }
                 };

                string jsonString = JsonConvert.SerializeObject(objReportSearchCriteria);
                JObject objInputParameters = JObject.Parse(jsonString);

                //Merchant IDs: 304267,864093,782465,401041,706913,938269,146195,184349,260068,225657,322240               
                foreach (var obj in lstAllMerchantStoreInformation)
                {
                    using (HttpClient client = new HttpClient())
                    {
                        objTalechAPI_Token.SetHTTPClientObjectValues(client);
                        HttpResponseMessage response = await objTalechAPI_Token.ExecuteClientPostMethod("reports/receiptssummaryreport", objInputParameters, client, APICommonHelper.TalechSecurityToken, obj.merchantIdentification); //obj.merchantIdentification);
                        if (response.IsSuccessStatusCode)
                        {
                            objTalechAPI_Token.SetRefreshToken(response);

                            var objRes = await response.Content.ReadAsStringAsync();
                            JObject jsonRes = JObject.Parse(objRes);

                            #region Hourly summary Json parse code

                            JToken jTokenDailySummary = jsonRes.FindTokens("dailySummary").FirstOrDefault();
                            JObject JobjDailySummary = JObject.Parse(jTokenDailySummary.ToString());
                            foreach (var jObject in JobjDailySummary)
                            {

                                #region Time Period Summary
                                JToken jTokenTimePeriodSummary = jObject.Value.FindTokens("timePeriodSummary").FirstOrDefault();

                                if (jTokenTimePeriodSummary != null)
                                {

                                    JToken jTokenAll = jTokenTimePeriodSummary.FindTokens("all").FirstOrDefault();
                                    if (jTokenAll != null)
                                    {
                                        StoreRevenueHoulrySummary_All_ResultModel objStoreHourlySummaryResultModel = JsonConvert.DeserializeObject<StoreRevenueHoulrySummary_All_ResultModel>(jTokenAll.ToString());
                                        objStoreHourlySummaryResultModel.storeName = obj.merchantStoreName;
                                        objStoreHourlySummaryResultModel.DateTimestring = jObject.Key;
                                        objStoreHourlySummaryResultModel.RevenueSummaryDatetime = GetDateTimeFromString(objStoreHourlySummaryResultModel.DateTimestring);
                                        lstHourlySummary_All.Add(objStoreHourlySummaryResultModel);
                                    }

                                    JToken jTokenamex = jTokenTimePeriodSummary.FindTokens("amex").FirstOrDefault();
                                    if (jTokenamex != null)
                                    {
                                        TimePeriodSummary_Individual_ResultModel objAmexModel = JsonConvert.DeserializeObject<TimePeriodSummary_Individual_ResultModel>(jTokenamex.ToString());
                                        objAmexModel.storeName = obj.merchantStoreName;
                                        objAmexModel.DateTimestring = jObject.Key;
                                        objAmexModel.RevenueSummaryDatetime = GetDateTimeFromString(objAmexModel.DateTimestring);
                                        objAmexModel.PaymentType = "amex";
                                        lstHourlySummary_Individual.Add(objAmexModel);
                                    }

                                    //JToken jTokencard = jTokenTimePeriodSummary.FindTokens("card").FirstOrDefault();
                                    //TimePeriodSummary_Individual_ResultModel objcardModel = JsonConvert.DeserializeObject<TimePeriodSummary_Individual_ResultModel>(jTokenAll.ToString());
                                    //objcardModel.storeName = obj.merchantStoreName;
                                    //objcardModel.DateTimestring = jObject.Key;
                                    //objcardModel.RevenueSummaryDatetime = GetDateTimeFromString(objcardModel.DateTimestring);
                                    //objcardModel.PaymentType = jObject.Key;
                                    //lstimePeriodSummary.Add(objcardModel);

                                    JToken jTokencash = jTokenTimePeriodSummary.FindTokens("cash").FirstOrDefault();
                                    if (jTokencash != null)
                                    {
                                        TimePeriodSummary_Individual_ResultModel objcashModel = JsonConvert.DeserializeObject<TimePeriodSummary_Individual_ResultModel>(jTokencash.ToString());
                                        objcashModel.storeName = obj.merchantStoreName;
                                        objcashModel.DateTimestring = jObject.Key;
                                        objcashModel.RevenueSummaryDatetime = GetDateTimeFromString(objcashModel.DateTimestring);
                                        objcashModel.PaymentType = "cash";
                                        lstHourlySummary_Individual.Add(objcashModel);
                                    }

                                    JToken jTokencheck = jTokenTimePeriodSummary.FindTokens("check").FirstOrDefault();
                                    if (jTokencheck != null)
                                    {
                                        TimePeriodSummary_Individual_ResultModel objcheckModel = JsonConvert.DeserializeObject<TimePeriodSummary_Individual_ResultModel>(jTokencheck.ToString());
                                        objcheckModel.storeName = obj.merchantStoreName;
                                        objcheckModel.DateTimestring = jObject.Key;
                                        objcheckModel.RevenueSummaryDatetime = GetDateTimeFromString(objcheckModel.DateTimestring);
                                        objcheckModel.PaymentType = "check";
                                        lstHourlySummary_Individual.Add(objcheckModel);
                                    }

                                    JToken jTokendiscover = jTokenTimePeriodSummary.FindTokens("discover").FirstOrDefault();
                                    if (jTokendiscover != null)
                                    {
                                        TimePeriodSummary_Individual_ResultModel objdiscoverModel = JsonConvert.DeserializeObject<TimePeriodSummary_Individual_ResultModel>(jTokendiscover.ToString());
                                        objdiscoverModel.storeName = obj.merchantStoreName;
                                        objdiscoverModel.DateTimestring = jObject.Key;
                                        objdiscoverModel.RevenueSummaryDatetime = GetDateTimeFromString(objdiscoverModel.DateTimestring);
                                        objdiscoverModel.PaymentType = "discover";
                                        lstHourlySummary_Individual.Add(objdiscoverModel);
                                    }

                                    JToken jTokengift = jTokenTimePeriodSummary.FindTokens("gift").FirstOrDefault();
                                    if (jTokengift != null)
                                    {
                                        TimePeriodSummary_Individual_ResultModel objgiftModel = JsonConvert.DeserializeObject<TimePeriodSummary_Individual_ResultModel>(jTokengift.ToString());
                                        objgiftModel.storeName = obj.merchantStoreName;
                                        objgiftModel.DateTimestring = jObject.Key;
                                        objgiftModel.RevenueSummaryDatetime = GetDateTimeFromString(objgiftModel.DateTimestring);
                                        objgiftModel.PaymentType = "gift";
                                        lstHourlySummary_Individual.Add(objgiftModel);
                                    }

                                    JToken jTokenmastercard = jTokenTimePeriodSummary.FindTokens("mastercard").FirstOrDefault();
                                    if (jTokenmastercard != null)
                                    {
                                        TimePeriodSummary_Individual_ResultModel objmastercardModel = JsonConvert.DeserializeObject<TimePeriodSummary_Individual_ResultModel>(jTokenmastercard.ToString());
                                        objmastercardModel.storeName = obj.merchantStoreName;
                                        objmastercardModel.DateTimestring = jObject.Key;
                                        objmastercardModel.RevenueSummaryDatetime = GetDateTimeFromString(objmastercardModel.DateTimestring);
                                        objmastercardModel.PaymentType = "mastercard";
                                        lstHourlySummary_Individual.Add(objmastercardModel);
                                    }

                                    JToken jTokenother = jTokenTimePeriodSummary.FindTokens("other").FirstOrDefault();
                                    if (jTokenother != null)
                                    {
                                        TimePeriodSummary_Individual_ResultModel objotherModel = JsonConvert.DeserializeObject<TimePeriodSummary_Individual_ResultModel>(jTokenother.ToString());
                                        objotherModel.storeName = obj.merchantStoreName;
                                        objotherModel.DateTimestring = jObject.Key;
                                        objotherModel.RevenueSummaryDatetime = GetDateTimeFromString(objotherModel.DateTimestring);
                                        objotherModel.PaymentType = "other";
                                        lstHourlySummary_Individual.Add(objotherModel);
                                    }

                                    JToken jTokenother_card = jTokenTimePeriodSummary.FindTokens("other_card").FirstOrDefault();
                                    if (jTokenother_card != null)
                                    {
                                        TimePeriodSummary_Individual_ResultModel objother_cardModel = JsonConvert.DeserializeObject<TimePeriodSummary_Individual_ResultModel>(jTokenother_card.ToString());
                                        objother_cardModel.storeName = obj.merchantStoreName;
                                        objother_cardModel.DateTimestring = jObject.Key;
                                        objother_cardModel.RevenueSummaryDatetime = GetDateTimeFromString(objother_cardModel.DateTimestring);
                                        objother_cardModel.PaymentType = "other_card";
                                        lstHourlySummary_Individual.Add(objother_cardModel);
                                    }


                                    JToken jTokenstoreCredit = jTokenTimePeriodSummary.FindTokens("storeCredit").FirstOrDefault();
                                    if (jTokenstoreCredit != null)
                                    {
                                        TimePeriodSummary_Individual_ResultModel objstoreCreditModel = JsonConvert.DeserializeObject<TimePeriodSummary_Individual_ResultModel>(jTokenstoreCredit.ToString());
                                        objstoreCreditModel.storeName = obj.merchantStoreName;
                                        objstoreCreditModel.DateTimestring = jObject.Key;
                                        objstoreCreditModel.RevenueSummaryDatetime = GetDateTimeFromString(objstoreCreditModel.DateTimestring);
                                        objstoreCreditModel.PaymentType = "storeCredit";
                                        lstHourlySummary_Individual.Add(objstoreCreditModel);
                                    }


                                    JToken jTokenvisa = jTokenTimePeriodSummary.FindTokens("visa").FirstOrDefault();
                                    if (jTokenvisa != null)
                                    {
                                        TimePeriodSummary_Individual_ResultModel objvisaModel = JsonConvert.DeserializeObject<TimePeriodSummary_Individual_ResultModel>(jTokenvisa.ToString());
                                        objvisaModel.storeName = obj.merchantStoreName;
                                        objvisaModel.DateTimestring = jObject.Key;
                                        objvisaModel.RevenueSummaryDatetime = GetDateTimeFromString(objvisaModel.DateTimestring);
                                        objvisaModel.PaymentType = "visa";
                                        lstHourlySummary_Individual.Add(objvisaModel);
                                    }
                                }
                                #endregion

                                #region Receipt Type Summary
                                JToken jTokenreceiptTypeSummary = jObject.Value.FindTokens("receiptTypeSummary").FirstOrDefault();

                                if (jTokenreceiptTypeSummary != null)
                                {

                                    JToken jTokenOTHER = jTokenreceiptTypeSummary.FindTokens("OTHER").FirstOrDefault();
                                    if (jTokenOTHER != null)
                                    {
                                        ReceiptTypeSummary_ResultModel objOTHERModel = JsonConvert.DeserializeObject<ReceiptTypeSummary_ResultModel>(jTokenOTHER.ToString());
                                        objOTHERModel.storeName = obj.merchantStoreName;
                                        objOTHERModel.DateTimestring = jObject.Key;
                                        objOTHERModel.RevenueSummaryDatetime = GetDateTimeFromString(objOTHERModel.DateTimestring);
                                        objOTHERModel.PaymentType = "OTHER";
                                        lstReceiptTypeSummary.Add(objOTHERModel);
                                    }

                                    JToken jTokenCHECK = jTokenreceiptTypeSummary.FindTokens("CHECK").FirstOrDefault();
                                    if (jTokenCHECK != null)
                                    {
                                        ReceiptTypeSummary_ResultModel objCHECKModel = JsonConvert.DeserializeObject<ReceiptTypeSummary_ResultModel>(jTokenCHECK.ToString());
                                        objCHECKModel.storeName = obj.merchantStoreName;
                                        objCHECKModel.DateTimestring = jObject.Key;
                                        objCHECKModel.RevenueSummaryDatetime = GetDateTimeFromString(objCHECKModel.DateTimestring);
                                        objCHECKModel.PaymentType = "CHECK";
                                        lstReceiptTypeSummary.Add(objCHECKModel);
                                    }

                                    JToken jTokenSTORECRT = jTokenreceiptTypeSummary.FindTokens("STORECRT").FirstOrDefault();
                                    if (jTokenSTORECRT != null)
                                    {
                                        ReceiptTypeSummary_ResultModel objSTORECRTModel = JsonConvert.DeserializeObject<ReceiptTypeSummary_ResultModel>(jTokenSTORECRT.ToString());
                                        objSTORECRTModel.storeName = obj.merchantStoreName;
                                        objSTORECRTModel.DateTimestring = jObject.Key;
                                        objSTORECRTModel.RevenueSummaryDatetime = GetDateTimeFromString(objSTORECRTModel.DateTimestring);
                                        objSTORECRTModel.PaymentType = "STORECRT";
                                        lstReceiptTypeSummary.Add(objSTORECRTModel);
                                    }

                                    JToken jTokenCASH = jTokenreceiptTypeSummary.FindTokens("CASH").FirstOrDefault();
                                    if (jTokenCASH != null)
                                    {
                                        ReceiptTypeSummary_ResultModel objCASHModel = JsonConvert.DeserializeObject<ReceiptTypeSummary_ResultModel>(jTokenCASH.ToString());
                                        objCASHModel.storeName = obj.merchantStoreName;
                                        objCASHModel.DateTimestring = jObject.Key;
                                        objCASHModel.RevenueSummaryDatetime = GetDateTimeFromString(objCASHModel.DateTimestring);
                                        objCASHModel.PaymentType = "CASH";
                                        lstReceiptTypeSummary.Add(objCASHModel);
                                    }

                                    JToken jTokenCCRD = jTokenreceiptTypeSummary.FindTokens("CCRD").FirstOrDefault();
                                    if (jTokenCCRD != null)
                                    {
                                        ReceiptTypeSummary_ResultModel objCCRDModel = JsonConvert.DeserializeObject<ReceiptTypeSummary_ResultModel>(jTokenCCRD.ToString());
                                        objCCRDModel.storeName = obj.merchantStoreName;
                                        objCCRDModel.DateTimestring = jObject.Key;
                                        objCCRDModel.RevenueSummaryDatetime = GetDateTimeFromString(objCCRDModel.DateTimestring);
                                        objCCRDModel.PaymentType = "CCRD";
                                        lstReceiptTypeSummary.Add(objCCRDModel);
                                    }

                                    JToken jTokenSPLIT = jTokenreceiptTypeSummary.FindTokens("SPLIT").FirstOrDefault();
                                    if (jTokenSPLIT != null)
                                    {
                                        ReceiptTypeSummary_ResultModel objSPLITModel = JsonConvert.DeserializeObject<ReceiptTypeSummary_ResultModel>(jTokenSPLIT.ToString());
                                        objSPLITModel.storeName = obj.merchantStoreName;
                                        objSPLITModel.DateTimestring = jObject.Key;
                                        objSPLITModel.RevenueSummaryDatetime = GetDateTimeFromString(objSPLITModel.DateTimestring);
                                        objSPLITModel.PaymentType = "SPLIT";
                                        lstReceiptTypeSummary.Add(objSPLITModel);
                                    }

                                    JToken jTokenGCRD = jTokenreceiptTypeSummary.FindTokens("GCRD").FirstOrDefault();
                                    if (jTokenGCRD != null)
                                    {
                                        ReceiptTypeSummary_ResultModel objGCRDModel = JsonConvert.DeserializeObject<ReceiptTypeSummary_ResultModel>(jTokenGCRD.ToString());
                                        objGCRDModel.storeName = obj.merchantStoreName;
                                        objGCRDModel.DateTimestring = jObject.Key;
                                        objGCRDModel.RevenueSummaryDatetime = GetDateTimeFromString(objGCRDModel.DateTimestring);
                                        objGCRDModel.PaymentType = "GCRD";
                                        lstReceiptTypeSummary.Add(objGCRDModel);
                                    }
                                }
                                #endregion

                                #region  order Summary
                                JToken jTokenorderSummary = jObject.Value.FindTokens("orderSummary").FirstOrDefault();

                                if (jTokenorderSummary != null)
                                {
                                    JToken jTokensale = jTokenorderSummary.FindTokens("sale").FirstOrDefault();
                                    if (jTokensale != null)
                                    {
                                        OrderSummary_ResultModel objsaleModel = JsonConvert.DeserializeObject<OrderSummary_ResultModel>(jTokensale.ToString());
                                        objsaleModel.storeName = obj.merchantStoreName;
                                        objsaleModel.DateTimestring = jObject.Key;
                                        objsaleModel.RevenueSummaryDatetime = GetDateTimeFromString(objsaleModel.DateTimestring);
                                        objsaleModel.TransactionType = "sale";
                                        lstOrderSummary.Add(objsaleModel);
                                    }

                                    JToken jTokenrefund = jTokenTimePeriodSummary.FindTokens("refund").FirstOrDefault();
                                    if (jTokenrefund != null)
                                    {
                                        OrderSummary_ResultModel objrefundModel = JsonConvert.DeserializeObject<OrderSummary_ResultModel>(jTokenrefund.ToString());
                                        objrefundModel.storeName = obj.merchantStoreName;
                                        objrefundModel.DateTimestring = jObject.Key;
                                        objrefundModel.RevenueSummaryDatetime = GetDateTimeFromString(objrefundModel.DateTimestring);
                                        objrefundModel.TransactionType = "refund";
                                        lstOrderSummary.Add(objrefundModel);
                                    }
                                }

                                #endregion
                            }

                            #endregion

                            #region Summary details Json parse code

                            //JToken jToken = jsonRes.FindTokens("all").FirstOrDefault();

                            //if (jToken != null)
                            //{
                            //    SummaryResultModel objStoreSummaryAllResultModel = JsonConvert.DeserializeObject<SummaryResultModel>(jToken.ToString());

                            //    objStoreSummaryAllResultModel.storeName = obj.merchantStoreName;
                            //    lstStoreSummaryAllResultModel.Add(objStoreSummaryAllResultModel);
                            //}
                            #endregion

                        }

                    }

                }

                #region Order Summary

                DataTable dtOrderSummary = new DataTable("OrderSummary");
                dtOrderSummary.Columns.Add("OrderDateTime");
                dtOrderSummary.Columns.Add("OrderType");
                dtOrderSummary.Columns.Add("Profitability");
                dtOrderSummary.Columns.Add("StoreCreditGrantedAmount");
                dtOrderSummary.Columns.Add("Cost");
                dtOrderSummary.Columns.Add("TipAmount");
                dtOrderSummary.Columns.Add("ItemCost");
                dtOrderSummary.Columns.Add("NoneTaxableRevenue");
                dtOrderSummary.Columns.Add("DiscountAmount");
                dtOrderSummary.Columns.Add("NumberOfGuests");
                dtOrderSummary.Columns.Add("LoyaltyAmount");
                dtOrderSummary.Columns.Add("GratuityAmount");
                dtOrderSummary.Columns.Add("Receipts");
                dtOrderSummary.Columns.Add("OrderSubtotal");
                dtOrderSummary.Columns.Add("Revenue");
                dtOrderSummary.Columns.Add("OrderAmount");
                dtOrderSummary.Columns.Add("RevenuePerGuest");
                dtOrderSummary.Columns.Add("TaxAmount");
                dtOrderSummary.Columns.Add("TaxableRevenue");
                dtOrderSummary.Columns.Add("StoreName");

                foreach (var objOrderSummary in lstOrderSummary.OrderBy(s => s.RevenueSummaryDatetime))
                {
                    if (CheckOrderDateWithinRange(objOrderSummary.RevenueSummaryDatetime))
                    {

                        DataRow dr = dtOrderSummary.NewRow();

                        dr["OrderDateTime"] = objOrderSummary.RevenueSummaryDatetime;
                        dr["OrderType"] = objOrderSummary.TransactionType;
                        dr["Profitability"] = objOrderSummary.profitability;
                        dr["StoreCreditGrantedAmount"] = objOrderSummary.storeCreditGrantedAmount;
                        dr["Cost"] = objOrderSummary.cost;
                        dr["TipAmount"] = objOrderSummary.tipAmount;
                        dr["ItemCost"] = objOrderSummary.itemCost;
                        dr["NoneTaxableRevenue"] = objOrderSummary.noneTaxableRevenue;
                        dr["DiscountAmount"] = objOrderSummary.discountAmount;
                        dr["NumberOfGuests"] = objOrderSummary.numberOfGuests;
                        dr["LoyaltyAmount"] = objOrderSummary.loyaltyAmount;
                        dr["GratuityAmount"] = objOrderSummary.gratuityAmount;
                        dr["Receipts"] = objOrderSummary.receipts;
                        dr["OrderSubtotal"] = objOrderSummary.orderSubtotal;
                        dr["Revenue"] = objOrderSummary.revenue;
                        dr["OrderAmount"] = objOrderSummary.orderAmount;
                        dr["RevenuePerGuest"] = objOrderSummary.revenuePerGuest;
                        dr["TaxAmount"] = objOrderSummary.taxAmount;
                        dr["TaxableRevenue"] = objOrderSummary.taxableRevenue;
                        dr["StoreName"] = objOrderSummary.storeName;

                        dtOrderSummary.Rows.Add(dr);
                    }
                }
                #endregion

                #region Receipt Type Summary

                DataTable dtReceiptTypeSummary = new DataTable("ReceiptTypeSummary");
                dtReceiptTypeSummary.Columns.Add("ReceiptDateTime");
                dtReceiptTypeSummary.Columns.Add("ReceiptType");
                dtReceiptTypeSummary.Columns.Add("ReceiptCount");
                dtReceiptTypeSummary.Columns.Add("StoreName");

                foreach (var objReceiptTypeSummary in lstReceiptTypeSummary.OrderBy(s => s.RevenueSummaryDatetime))
                {
                    if (CheckOrderDateWithinRange(objReceiptTypeSummary.RevenueSummaryDatetime))
                    {
                        DataRow dr = dtReceiptTypeSummary.NewRow();

                        dr["ReceiptDateTime"] = objReceiptTypeSummary.RevenueSummaryDatetime;
                        dr["ReceiptType"] = objReceiptTypeSummary.PaymentType;
                        dr["ReceiptCount"] = objReceiptTypeSummary.counts;
                        dr["StoreName"] = objReceiptTypeSummary.storeName;

                        dtReceiptTypeSummary.Rows.Add(dr);
                    }
                }
                #endregion

                #region Time Period Summary All

                DataTable dtTimePeriodSummaryAll = new DataTable("TimePeriodSummaryAll");
                dtTimePeriodSummaryAll.Columns.Add("OrderDateTime");
                dtTimePeriodSummaryAll.Columns.Add("Cost");
                dtTimePeriodSummaryAll.Columns.Add("Discount");
                dtTimePeriodSummaryAll.Columns.Add("Gratuity");
                dtTimePeriodSummaryAll.Columns.Add("GrossRevenue");
                dtTimePeriodSummaryAll.Columns.Add("NetRevenue");
                dtTimePeriodSummaryAll.Columns.Add("NetRevenuePerReceipt");
                dtTimePeriodSummaryAll.Columns.Add("NoneTaxableRevenue");
                dtTimePeriodSummaryAll.Columns.Add("Profitability");
                dtTimePeriodSummaryAll.Columns.Add("Receipts");
                dtTimePeriodSummaryAll.Columns.Add("RefundAmount");
                dtTimePeriodSummaryAll.Columns.Add("RefundDiscountAmount");
                dtTimePeriodSummaryAll.Columns.Add("RefundGratuityAmount");
                dtTimePeriodSummaryAll.Columns.Add("RefundReceipts");
                dtTimePeriodSummaryAll.Columns.Add("RefundTaxAmount");
                dtTimePeriodSummaryAll.Columns.Add("ReportedTax");
                dtTimePeriodSummaryAll.Columns.Add("RoundingRevenue");
                dtTimePeriodSummaryAll.Columns.Add("SubTotal");
                dtTimePeriodSummaryAll.Columns.Add("Tax");
                dtTimePeriodSummaryAll.Columns.Add("TaxableRevenue");
                dtTimePeriodSummaryAll.Columns.Add("Tip");
                dtTimePeriodSummaryAll.Columns.Add("TotalCollected");
                dtTimePeriodSummaryAll.Columns.Add("StoreName");

                foreach (var objTimePeriodSummaryAll in lstHourlySummary_All.OrderBy(s => s.RevenueSummaryDatetime))
                {
                    if (CheckOrderDateWithinRange(objTimePeriodSummaryAll.RevenueSummaryDatetime))
                    {
                        DataRow dr = dtTimePeriodSummaryAll.NewRow();

                        dr["OrderDateTime"] = objTimePeriodSummaryAll.RevenueSummaryDatetime;
                        dr["Cost"] = objTimePeriodSummaryAll.cost;
                        dr["Discount"] = objTimePeriodSummaryAll.discount;
                        dr["Gratuity"] = objTimePeriodSummaryAll.gratuity;
                        dr["GrossRevenue"] = objTimePeriodSummaryAll.grossRevenue;
                        dr["NetRevenue"] = objTimePeriodSummaryAll.netRevenue;
                        dr["NetRevenuePerReceipt"] = objTimePeriodSummaryAll.netRevenuePerReceipt;
                        dr["NoneTaxableRevenue"] = objTimePeriodSummaryAll.noneTaxableRevenue;
                        dr["Profitability"] = objTimePeriodSummaryAll.profitability;
                        dr["Receipts"] = objTimePeriodSummaryAll.receipts;
                        dr["RefundAmount"] = objTimePeriodSummaryAll.refundAmount;
                        dr["RefundDiscountAmount"] = objTimePeriodSummaryAll.refundDiscountAmount;
                        dr["RefundGratuityAmount"] = objTimePeriodSummaryAll.refundGratuityAmount;
                        dr["RefundReceipts"] = objTimePeriodSummaryAll.refundReceipts;
                        dr["RefundTaxAmount"] = objTimePeriodSummaryAll.refundTaxAmount;
                        dr["ReportedTax"] = objTimePeriodSummaryAll.reportedTax;
                        dr["RoundingRevenue"] = objTimePeriodSummaryAll.roundingRevenue;
                        dr["SubTotal"] = objTimePeriodSummaryAll.subTotal;
                        dr["Tax"] = objTimePeriodSummaryAll.tax;
                        dr["TaxableRevenue"] = objTimePeriodSummaryAll.taxableRevenue;
                        dr["Tip"] = objTimePeriodSummaryAll.tip;
                        dr["TotalCollected"] = objTimePeriodSummaryAll.totalCollected;
                        dr["StoreName"] = objTimePeriodSummaryAll.storeName;

                        dtTimePeriodSummaryAll.Rows.Add(dr);
                    }
                }
                #endregion

                #region Time Period Summary Transaction Details

                DataTable dtTimePeriodSummaryTransactionDetails = new DataTable("TimePeriodSummaryTransactionDetails");
                dtTimePeriodSummaryTransactionDetails.Columns.Add("OrderDateTime");
                dtTimePeriodSummaryTransactionDetails.Columns.Add("TransactionType");
                dtTimePeriodSummaryTransactionDetails.Columns.Add("SalesTransactions");
                dtTimePeriodSummaryTransactionDetails.Columns.Add("SalesTips");
                dtTimePeriodSummaryTransactionDetails.Columns.Add("TotalCollected");
                dtTimePeriodSummaryTransactionDetails.Columns.Add("RefundTips");
                dtTimePeriodSummaryTransactionDetails.Columns.Add("RefundTransactions");
                dtTimePeriodSummaryTransactionDetails.Columns.Add("SalesAmount");
                dtTimePeriodSummaryTransactionDetails.Columns.Add("RefundAmount");
                dtTimePeriodSummaryTransactionDetails.Columns.Add("StoreName");

                foreach (var objTimePeriodSummaryTransactionDetails in lstHourlySummary_Individual.OrderBy(s => s.RevenueSummaryDatetime))
                {
                    if (CheckOrderDateWithinRange(objTimePeriodSummaryTransactionDetails.RevenueSummaryDatetime))
                    {
                        DataRow dr = dtTimePeriodSummaryTransactionDetails.NewRow();

                        dr["OrderDateTime"] = objTimePeriodSummaryTransactionDetails.RevenueSummaryDatetime;
                        dr["TransactionType"] = objTimePeriodSummaryTransactionDetails.PaymentType;
                        dr["SalesTransactions"] = objTimePeriodSummaryTransactionDetails.sales_transactions;
                        dr["SalesTips"] = objTimePeriodSummaryTransactionDetails.salesTips;
                        dr["TotalCollected"] = objTimePeriodSummaryTransactionDetails.totalCollected;
                        dr["RefundTips"] = objTimePeriodSummaryTransactionDetails.refundTips;
                        dr["RefundTransactions"] = objTimePeriodSummaryTransactionDetails.refund_transactions;
                        dr["SalesAmount"] = objTimePeriodSummaryTransactionDetails.salesAmount;
                        dr["RefundAmount"] = objTimePeriodSummaryTransactionDetails.refundAmount;
                        dr["StoreName"] = objTimePeriodSummaryTransactionDetails.storeName;

                        dtTimePeriodSummaryTransactionDetails.Rows.Add(dr);
                    }
                }
                #endregion

                StoreRevenueHoulrySummary_DAL objStoreRevenueHoulrySummaryDAL = new StoreRevenueHoulrySummary_DAL();
                objStoreRevenueHoulrySummaryDAL.SaveAllMerchantStoreDetails(dtOrderSummary, dtReceiptTypeSummary, dtTimePeriodSummaryAll, dtTimePeriodSummaryTransactionDetails);

                //SaveRevenueSummaryDetailsintoExcel(lstHourlySummary_All, startdate, enddate);
            }
            catch (Exception ex)
            {
                LogHelper.Log("Error in Store Revenue report. Error: " + ex.Message);
            }

            return 0;

        }

        public void SaveRevenueSummaryDetailsintoExcel(List<StoreRevenueHoulrySummary_All_ResultModel> lstStoreSummaryAllResultModel, string startDate, string endDate)
        {
            if (lstStoreSummaryAllResultModel != null && lstStoreSummaryAllResultModel.Count() > 0)
            {
                DataTable dtStoreSummary = new DataTable("Summary");
                dtStoreSummary.Columns.Add("Location");
                dtStoreSummary.Columns.Add("Receipts", typeof(int));
                dtStoreSummary.Columns.Add("Refund Receipts", typeof(int));
                dtStoreSummary.Columns.Add("Gross Revenue", typeof(double));
                dtStoreSummary.Columns.Add("Discounts", typeof(double));
                dtStoreSummary.Columns.Add("Refunds", typeof(double));
                dtStoreSummary.Columns.Add("Net Revenue", typeof(double));
                dtStoreSummary.Columns.Add("Tax", typeof(double));
                dtStoreSummary.Columns.Add("Tip", typeof(double));
                dtStoreSummary.Columns.Add("Net Collected", typeof(double));
                dtStoreSummary.Columns.Add("Profitability", typeof(double));

                var lstDistinctStoreName = lstStoreSummaryAllResultModel.GroupBy(s => s.storeName).Select(s => new { s.Key }).ToList();

                foreach (var objStoreSummary in lstDistinctStoreName)
                {
                    DataRow dr = dtStoreSummary.NewRow();

                    dr["Location"] = objStoreSummary.Key;
                    dr["Receipts"] = lstStoreSummaryAllResultModel.Where(s => s.storeName == objStoreSummary.Key).Sum(s => s.receipts);
                    dr["Refund Receipts"] = lstStoreSummaryAllResultModel.Where(s => s.storeName == objStoreSummary.Key).Sum(s => s.refundReceipts);// objStoreSummary.refundReceipts;
                    dr["Gross Revenue"] = lstStoreSummaryAllResultModel.Where(s => s.storeName == objStoreSummary.Key).Sum(s => s.grossRevenue); //objStoreSummary.grossRevenue;
                    dr["Discounts"] = lstStoreSummaryAllResultModel.Where(s => s.storeName == objStoreSummary.Key).Sum(s => s.discount); //objStoreSummary.discount;                  
                    dr["Refunds"] = lstStoreSummaryAllResultModel.Where(s => s.storeName == objStoreSummary.Key).Sum(s => s.refundAmount);// objStoreSummary.refundAmount;
                    dr["Net Revenue"] = lstStoreSummaryAllResultModel.Where(s => s.storeName == objStoreSummary.Key).Sum(s => s.netRevenue); //objStoreSummary.netRevenue;                   
                    dr["Tax"] = lstStoreSummaryAllResultModel.Where(s => s.storeName == objStoreSummary.Key).Sum(s => s.tax); //objStoreSummary.tax;
                    dr["Tip"] = lstStoreSummaryAllResultModel.Where(s => s.storeName == objStoreSummary.Key).Sum(s => s.tip); //objStoreSummary.tip;                  
                    dr["Net Collected"] = lstStoreSummaryAllResultModel.Where(s => s.storeName == objStoreSummary.Key).Sum(s => s.totalCollected); //objStoreSummary.totalCollected;                  
                    dr["Profitability"] = lstStoreSummaryAllResultModel.Where(s => s.storeName == objStoreSummary.Key).Sum(s => s.profitability); //objStoreSummary.profitability;

                    dtStoreSummary.Rows.Add(dr);
                }

                using (var package = new ExcelPackage())
                {
                    // Add a new worksheet to the empty workbook
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Store Revenue Details");
                    worksheet.Cells["A2"].Value = "Summary from " + Convert.ToDateTime(startDate).ToString("MM/dd/yyyy") + " to " + Convert.ToDateTime(endDate).ToString("MM/dd/yyyy");
                    using (var range = worksheet.Cells["A2"])
                    {
                        range.Style.Font.Bold = true;
                        range.Style.Font.Size = 14;
                        range.Style.Font.Color.SetColor(Color.FromArgb(41, 128, 185));
                    }
                    worksheet.Cells["A3"].LoadFromDataTable(dtStoreSummary, true, TableStyles.Light9);
                    worksheet.Cells.AutoFitColumns(0);
                    worksheet.Cells[3, 4, 14, 11].Style.Numberformat.Format = "$#,##0.00";
                    worksheet.Cells["E4:E14"].Style.Font.Color.SetColor(Color.Red);
                    worksheet.Cells["F4:F14"].Style.Font.Color.SetColor(Color.Red);


                    #region Hourly Net Revenue

                    worksheet.Cells["A16"].Value = "Net Revenue";
                    using (var range = worksheet.Cells["A16"])
                    {
                        range.Style.Font.Bold = true;
                        range.Style.Font.Size = 14;
                        range.Style.Font.Color.SetColor(Color.FromArgb(41, 128, 185));
                    }
                    worksheet.Cells["A17"].LoadFromDataTable(SaveHourlyNetRevenueDetailsIntoExcel(lstStoreSummaryAllResultModel), true, TableStyles.Light9);
                    worksheet.Cells.AutoFitColumns(0);
                    worksheet.Cells[18, 2, 41, 12].Style.Numberformat.Format = "$#,##0.00";
                    #endregion

                    #region Receipt

                    worksheet.Cells["A43"].Value = "Receipts";
                    using (var range = worksheet.Cells["A43"])
                    {
                        range.Style.Font.Bold = true;
                        range.Style.Font.Size = 14;
                        range.Style.Font.Color.SetColor(Color.FromArgb(41, 128, 185));
                    }
                    worksheet.Cells["A44"].LoadFromDataTable(SaveHourlyReceiptIntoExcel(lstStoreSummaryAllResultModel), true, TableStyles.Light9);
                    worksheet.Cells.AutoFitColumns(0);
                    #endregion

                    #region Hourly Revenue Per Receipt

                    worksheet.Cells["A70"].Value = "Revenue Per Receipt";
                    using (var range = worksheet.Cells["A70"])
                    {
                        range.Style.Font.Bold = true;
                        range.Style.Font.Size = 14;
                        range.Style.Font.Color.SetColor(Color.FromArgb(41, 128, 185));
                    }
                    worksheet.Cells["A71"].LoadFromDataTable(SaveHourlyRevenuePerReceiptIntoExcel(lstStoreSummaryAllResultModel), true, TableStyles.Light9);
                    worksheet.Cells.AutoFitColumns(0);
                    worksheet.Cells[72, 2, 95, 12].Style.Numberformat.Format = "$#,##0.00";
                    #endregion

                    FileInfo objFile = LogHelper.GetFileInfo(AppDomain.CurrentDomain.BaseDirectory, "Revenue Summary_" + Convert.ToDateTime(startDate).ToString("MM-dd-yyyy") + "_API.xlsx");
                    package.SaveAs(objFile);
                }
            }
        }

        public DataTable SaveHourlyNetRevenueDetailsIntoExcel(List<StoreRevenueHoulrySummary_All_ResultModel> lstHourlySummary_All)
        {
            DataTable dtStoreHourlySummary = new DataTable("Net_Revenue_Hourly_Summary");
            if (lstHourlySummary_All != null && lstHourlySummary_All.Count() > 0)
            {

                dtStoreHourlySummary.Columns.Add("Date");
                dtStoreHourlySummary.Columns.Add("Cypress", typeof(double));
                dtStoreHourlySummary.Columns.Add("Fountain Valley", typeof(double));
                dtStoreHourlySummary.Columns.Add("Alhambra", typeof(double));
                dtStoreHourlySummary.Columns.Add("Artesia", typeof(double));
                dtStoreHourlySummary.Columns.Add("Chino Hills", typeof(double));
                dtStoreHourlySummary.Columns.Add("Westminster", typeof(double));
                dtStoreHourlySummary.Columns.Add("Tustin", typeof(double));
                dtStoreHourlySummary.Columns.Add("Irvine", typeof(double));
                dtStoreHourlySummary.Columns.Add("Euclid", typeof(double));
                dtStoreHourlySummary.Columns.Add("Huntington Beach", typeof(double));
                dtStoreHourlySummary.Columns.Add("Costa Mesa", typeof(double));

                var lstDistinctDateTime = lstHourlySummary_All.GroupBy(s => s.DateTimestring).Select(s => new { s.Key }).ToList();

                foreach (var objDateTime in lstDistinctDateTime)
                {
                    DataRow dr = dtStoreHourlySummary.NewRow();

                    dr["Date"] = objDateTime.Key;
                    dr["Cypress"] = lstHourlySummary_All.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "cypress").netRevenue;
                    dr["Fountain Valley"] = lstHourlySummary_All.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "fountain valley").netRevenue;
                    dr["Alhambra"] = lstHourlySummary_All.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "alhambra").netRevenue;
                    dr["Artesia"] = lstHourlySummary_All.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "artesia").netRevenue;
                    dr["Chino Hills"] = lstHourlySummary_All.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "chino hills").netRevenue;
                    dr["Westminster"] = lstHourlySummary_All.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "westminster").netRevenue;
                    dr["Tustin"] = lstHourlySummary_All.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "tustin").netRevenue;
                    dr["Irvine"] = lstHourlySummary_All.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "irvine").netRevenue;
                    dr["Euclid"] = lstHourlySummary_All.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "euclid").netRevenue;
                    dr["Huntington Beach"] = lstHourlySummary_All.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "huntington beach").netRevenue;
                    dr["Costa Mesa"] = lstHourlySummary_All.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "costa mesa").netRevenue;

                    dtStoreHourlySummary.Rows.Add(dr);
                }

            }

            return dtStoreHourlySummary;
        }

        public DataTable SaveHourlyRevenuePerReceiptIntoExcel(List<StoreRevenueHoulrySummary_All_ResultModel> lstHourlySummary)
        {
            DataTable dtStoreHourlySummary = new DataTable("RevenuePerReceiptSummary");
            if (lstHourlySummary != null && lstHourlySummary.Count() > 0)
            {

                dtStoreHourlySummary.Columns.Add("Date");
                dtStoreHourlySummary.Columns.Add("Cypress", typeof(double));
                dtStoreHourlySummary.Columns.Add("Fountain Valley", typeof(double));
                dtStoreHourlySummary.Columns.Add("Alhambra", typeof(double));
                dtStoreHourlySummary.Columns.Add("Artesia", typeof(double));
                dtStoreHourlySummary.Columns.Add("Chino Hills", typeof(double));
                dtStoreHourlySummary.Columns.Add("Westminster", typeof(double));
                dtStoreHourlySummary.Columns.Add("Tustin", typeof(double));
                dtStoreHourlySummary.Columns.Add("Irvine", typeof(double));
                dtStoreHourlySummary.Columns.Add("Euclid", typeof(double));
                dtStoreHourlySummary.Columns.Add("Huntington Beach", typeof(double));
                dtStoreHourlySummary.Columns.Add("Costa Mesa", typeof(double));

                var lstDistinctDateTime = lstHourlySummary.GroupBy(s => s.DateTimestring).Select(s => new { s.Key }).ToList();

                foreach (var objDateTime in lstDistinctDateTime)
                {
                    DataRow dr = dtStoreHourlySummary.NewRow();

                    dr["Date"] = objDateTime.Key;
                    dr["Cypress"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "cypress").netRevenuePerReceipt;
                    dr["Fountain Valley"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "fountain valley").netRevenuePerReceipt;
                    dr["Alhambra"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "alhambra").netRevenuePerReceipt;
                    dr["Artesia"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "artesia").netRevenuePerReceipt;
                    dr["Chino Hills"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "chino hills").netRevenuePerReceipt;
                    dr["Westminster"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "westminster").netRevenuePerReceipt;
                    dr["Tustin"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "tustin").netRevenuePerReceipt;
                    dr["Irvine"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "irvine").netRevenuePerReceipt;
                    dr["Euclid"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "euclid").netRevenuePerReceipt;
                    dr["Huntington Beach"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "huntington beach").netRevenuePerReceipt;
                    dr["Costa Mesa"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "costa mesa").netRevenuePerReceipt;

                    dtStoreHourlySummary.Rows.Add(dr);
                }

            }

            return dtStoreHourlySummary;
        }

        public DataTable SaveHourlyReceiptIntoExcel(List<StoreRevenueHoulrySummary_All_ResultModel> lstHourlySummary)
        {
            DataTable dtStoreHourlySummary = new DataTable("HourlyReceipts");
            if (lstHourlySummary != null && lstHourlySummary.Count() > 0)
            {

                dtStoreHourlySummary.Columns.Add("Date");
                dtStoreHourlySummary.Columns.Add("Cypress", typeof(double));
                dtStoreHourlySummary.Columns.Add("Fountain Valley", typeof(double));
                dtStoreHourlySummary.Columns.Add("Alhambra", typeof(double));
                dtStoreHourlySummary.Columns.Add("Artesia", typeof(double));
                dtStoreHourlySummary.Columns.Add("Chino Hills", typeof(double));
                dtStoreHourlySummary.Columns.Add("Westminster", typeof(double));
                dtStoreHourlySummary.Columns.Add("Tustin", typeof(double));
                dtStoreHourlySummary.Columns.Add("Irvine", typeof(double));
                dtStoreHourlySummary.Columns.Add("Euclid", typeof(double));
                dtStoreHourlySummary.Columns.Add("Huntington Beach", typeof(double));
                dtStoreHourlySummary.Columns.Add("Costa Mesa", typeof(double));

                var lstDistinctDateTime = lstHourlySummary.GroupBy(s => s.DateTimestring).Select(s => new { s.Key }).ToList();

                foreach (var objDateTime in lstDistinctDateTime)
                {
                    DataRow dr = dtStoreHourlySummary.NewRow();

                    dr["Date"] = objDateTime.Key;
                    dr["Cypress"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "cypress").receipts;
                    dr["Fountain Valley"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "fountain valley").receipts;
                    dr["Alhambra"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "alhambra").receipts;
                    dr["Artesia"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "artesia").receipts;
                    dr["Chino Hills"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "chino hills").receipts;
                    dr["Westminster"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "westminster").receipts;
                    dr["Tustin"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "tustin").receipts;
                    dr["Irvine"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "irvine").receipts;
                    dr["Euclid"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "euclid").receipts;
                    dr["Huntington Beach"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "huntington beach").receipts;
                    dr["Costa Mesa"] = lstHourlySummary.FirstOrDefault(s => s.DateTimestring == objDateTime.Key && s.storeName.ToLower() == "costa mesa").receipts;

                    dtStoreHourlySummary.Rows.Add(dr);
                }
            }

            return dtStoreHourlySummary;
        }

        public DateTime GetDateTimeFromString(string DateTimestring)
        {

            string[] strArr = null;
            strArr = DateTimestring.Split(new string[] { "-" }, StringSplitOptions.RemoveEmptyEntries);
            DateTime datetime = new DateTime(Convert.ToInt32(strArr[0]), Convert.ToInt32(strArr[1]), Convert.ToInt32(strArr[2]), Convert.ToInt32(strArr[3]), 0, 0);

            return (datetime);
        }

        public Boolean CheckOrderDateWithinRange(DateTime orderDateTime)
        {
            if (orderDateTime.Hour >= 5 && orderDateTime.Hour <= 23)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
