﻿using _7LeavesCafeReport_BLL.Helpers;
using _7LeavesCafeReport_BLL.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace _7LeavesCafeReport_BLL.TalechAPIMethods
{
    public class TalechAPI_Token
    {
        public async Task<TalechTokenMethodResult> GetTalechAPI_Token()
        {
            TalechTokenMethodResult objTalechTokenMethodResult = new TalechTokenMethodResult();

            TalechAccountDetails objdetails = new TalechAccountDetails
            {
                refresh_token = "191072574/5kHP9zQJ8mADp8oSG15bw6x2",
                client_secret = "49B9GDPU",
                client_id = "rserasiya@gmail.com",
                grant_type = "refresh_token"
            };

            string jsonString = JsonConvert.SerializeObject(objdetails);
            JObject objInputParameters = JObject.Parse(jsonString);


            using (HttpClient client = new HttpClient())
            {
                SetHTTPClientObjectValues(client);
                HttpResponseMessage response = await ExecuteClientPostMethod("o/oauth2/token", objInputParameters, client);

                LogHelper.Log("Refresh Token Method Response code: " + response.StatusCode);
                if (response.IsSuccessStatusCode)
                {
                    string resTokenMethod = await response.Content.ReadAsStringAsync();
                    objTalechTokenMethodResult = JsonConvert.DeserializeObject<TalechTokenMethodResult>(resTokenMethod);//await response.Content.ReadAsAsync<TalechTokenMethodResult>();

                    APICommonHelper.TalechSecurityToken = objTalechTokenMethodResult.access_token;
                }
            }

            return objTalechTokenMethodResult;
        }

        public bool SetHTTPClientObjectValues(HttpClient client)
        {

            client.BaseAddress = new Uri("https://mapi.talech.com​/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            return true;
        }

        public async Task<HttpResponseMessage> ExecuteClientPostMethod(string uri, JObject inputParameters, HttpClient client, string securityToken = default(string),
          string merchantID = default(string))
        {

            if (!string.IsNullOrEmpty(securityToken))
                client.DefaultRequestHeaders.Add("securityToken", securityToken);
            if (!string.IsNullOrEmpty(merchantID))
                client.DefaultRequestHeaders.TryAddWithoutValidation("X-POS-MerchantId", merchantID.ToString());

            HttpResponseMessage response = await client.PostAsJsonAsync(uri, inputParameters);

            return response;
        }

        public bool SetRefreshToken(HttpResponseMessage response)
        {
            HttpHeaders headers = response.Headers;
            IEnumerable<string> values;
            if (headers.TryGetValues("X-POS-SecurityToken", out values))
            {
                 APICommonHelper.TalechSecurityToken  = values.First();                
            }

            return true;
        }
    }
}
