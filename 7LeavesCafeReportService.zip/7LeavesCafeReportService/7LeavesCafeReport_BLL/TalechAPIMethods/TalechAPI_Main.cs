﻿using _7LeavesCafeReport_BLL.Helpers;
using _7LeavesCafeReport_BLL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7LeavesCafeReport_BLL.TalechAPIMethods
{
    public class TalechAPI_Main
    {
        public async Task TalechAPIMainMethod()
        {
            try
            {
                TalechAPI_Token objTalechAPI_Token = new TalechAPI_Token();
                TalechAPI_MerchantStoreDetails objTalechAPI_MerchantStoreDetails = new TalechAPI_MerchantStoreDetails();

                TalechTokenMethodResult objTalechTokenMethodResult = await objTalechAPI_Token.GetTalechAPI_Token();
                LogHelper.Log("Access token:" + objTalechTokenMethodResult.access_token + " Expires in:" + objTalechTokenMethodResult.expires_in + " token_type:" + objTalechTokenMethodResult.token_type);

                List<TalechMerchantStoreDetails> lstAllMerchantStoreInformation = await objTalechAPI_MerchantStoreDetails.GetAllMerchantStoreDetails();
                LogHelper.Log("Merchant Store Count: " + lstAllMerchantStoreInformation.Count() + " Time: " + DateTime.Now);


            }
            catch (Exception ex)
            {

                LogHelper.Log("Erro in Run Async method. Error: " + ex.Message);
            }
        }
    }
}
