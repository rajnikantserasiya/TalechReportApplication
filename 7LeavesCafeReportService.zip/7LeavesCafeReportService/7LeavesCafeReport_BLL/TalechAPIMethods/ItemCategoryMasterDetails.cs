﻿using _7LeavesCafeReport_BLL.Helpers;
using _7LeavesCafeReport_BLL.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using FetchDataFromTalechPOS_BLL;
using _7LeavesCafeReport_DAL;

namespace _7LeavesCafeReport_BLL.TalechAPIMethods
{
    class ItemCategoryMasterDetails
    {
        public async Task<List<ItemCategoryResultModel>> ItemCategoryByCriteria(List<TalechMerchantStoreDetails> lstAllMerchantStoreInformation)
        {
            List<ItemCategoryResultModel> objitemResult = new List<ItemCategoryResultModel>();

            ItemCategoryInputParameterModel objMenuItemsSearchCriteria =
             new ItemCategoryInputParameterModel()
             {
                 storeid = 1,
                 offset = 0,
                 maxRecords = 1000,
                 searchString = "",
                 inventoryOnly = false,
                 //categoryId = 123343//546862
             };

            string jsonString = JsonConvert.SerializeObject(objMenuItemsSearchCriteria);
            JObject objInputParameters = JObject.Parse(jsonString);

            foreach (var obj in lstAllMerchantStoreInformation)
            {
                TalechAPI_Token objtalech = new TalechAPI_Token();

                using (HttpClient client = new HttpClient())
                {

                    objtalech.SetHTTPClientObjectValues(client);
                    HttpResponseMessage response = await objtalech.ExecuteClientPostMethod("managemenu/menuitem/allmenuitems", objInputParameters, client, APICommonHelper.TalechSecurityToken, obj.merchantIdentification);
                    if (response.IsSuccessStatusCode)
                    {

                        objtalech.SetRefreshToken(response);
                        var objRes = await response.Content.ReadAsStringAsync();
                        JObject jsonRes = JObject.Parse(objRes);
                        JToken jTokenItemResult = jsonRes.FindTokens("items").FirstOrDefault();


                        foreach (var jObjectItem in jTokenItemResult.Children())
                        {
                            ItemCategoryResultModel objMenu = JsonConvert.DeserializeObject<ItemCategoryResultModel>(jObjectItem.ToString());
                            if (objMenu != null && !objitemResult.Any(s => s.name == objMenu.name && s.categoryType == objMenu.categoryType))
                                objitemResult.Add(objMenu);
                        }

                    }

                }

            }


            // DataTable dt = objitemResult.ToDataTable();
            DataTable dtMerchantDetails = new DataTable("ItemCategoryMasterDetails");

            dtMerchantDetails.Columns.Add("TalechCategoryID");
            dtMerchantDetails.Columns.Add("CategoryName");
            dtMerchantDetails.Columns.Add("ItemCategoryType");

            foreach (var objMerchantDetails in objitemResult)
            {
                DataRow dr = dtMerchantDetails.NewRow();

                dr["TalechCategoryID"] = Convert.ToInt64(objMerchantDetails.categoryId);
                dr["CategoryName"] = objMerchantDetails.name;
                dr["ItemCategoryType"] = objMerchantDetails.categoryType;

                dtMerchantDetails.Rows.Add(dr);

            }

            ItemCategoryMasterDetails_DAL objMerchantStoreDetailsDAL = new ItemCategoryMasterDetails_DAL();
            objMerchantStoreDetailsDAL.SaveItemCategoryMasterDetails_DAL(dtMerchantDetails);

            return objitemResult;

        }


    }
}
