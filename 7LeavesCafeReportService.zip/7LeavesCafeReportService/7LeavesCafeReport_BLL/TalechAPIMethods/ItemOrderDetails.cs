﻿using _7LeavesCafeReport_BLL.Helpers;
using _7LeavesCafeReport_BLL.Models;
using FetchDataFromTalechPOS_BLL;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OfficeOpenXml;
using OfficeOpenXml.Table;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace _7LeavesCafeReport_BLL.TalechAPIMethods
{
    public class ItemOrderDetails
    {
        public async Task<int> SaveItemOrderDetailsByCriteria(List<TalechMerchantStoreDetails> lstAllMerchantStoreInformation,
            string startdate, string enddate, List<ItemCategoryResultModel> lstItemCategory)
        {
            TalechAPI_Token objTalechAPI_Token = new TalechAPI_Token();
            List<OrderDetailsExportFields> lstFinalResult = new List<OrderDetailsExportFields>();
            LogHelper.Log("Start Date: " + startdate + " End Date: " + enddate);
            foreach (var objAllMerchantStoreInformation in lstAllMerchantStoreInformation)
            {

                OrderHistorySearchCriteria objReportSearchCriteria = new OrderHistorySearchCriteria();
                objReportSearchCriteria.searchCriteria = new OrderHistoryInputParametersModel();
                objReportSearchCriteria.searchCriteria =
                 new OrderHistoryInputParametersModel()
                 {
                     offset = 0,
                     limit = 100000,
                     //searchString = "",
                     startDate = startdate,
                     endDate = enddate,
                     //paymentTypes = new string[] { "CASH", "CCRD", "DCRD", "CHECK" },
                     orderStatus = new string[] { "PAID", "PARTIAL_PAID", "OPEN" },
                     transactionTypes = new string[] { "SALE", "VOID", "REFUND", "PARTIALREFUND", "PARTIALVOID", "UPDATETIP" },
                     storeIds = new int[] { 1 },
                     orderBy = "firstPaymentDate",
                     //userId = objEmployee.id,//232741//

                     //Sale option
                     hideSale = false,  // To display only refund transaction
                     hideRefund = true, // To display only sales transaction
                     onlySplitCheck = false // To display only split check transaction

                     //Refund option
                     //hideSale = true,  // To display only refund transaction
                     //hideRefund = false, // To display only sales transaction
                     //onlySplitCheck = false // To display only split check transaction

                     //Split Check option
                     //hideSale = false,  // To display only refund transaction
                     //hideRefund = false, // To display only sales transaction
                     //onlySplitCheck = true // To display only split check transaction
                 };

                string jsonString = JsonConvert.SerializeObject(objReportSearchCriteria);
                JObject objInputParameters = JObject.Parse(jsonString);

                try
                {
                    string objRes = string.Empty;
                    OrderHistoryFullObject objOrderHistoryFullObject = null;
                    using (HttpClient client = new HttpClient())
                    {
                        objTalechAPI_Token.SetHTTPClientObjectValues(client);
                        HttpResponseMessage response = await objTalechAPI_Token.ExecuteClientPostMethod("order/getorderhistory", objInputParameters, client, APICommonHelper.TalechSecurityToken, objAllMerchantStoreInformation.merchantIdentification);
                        if (response.IsSuccessStatusCode)
                        {
                            objTalechAPI_Token.SetRefreshToken(response);
                            objRes = await response.Content.ReadAsStringAsync();
                            objOrderHistoryFullObject = JsonConvert.DeserializeObject<OrderHistoryFullObject>(objRes);
                        }
                    }

                    //if (!string.IsNullOrEmpty(objRes) && !objRes.ToLower().Contains("records not found"))
                    if (objOrderHistoryFullObject != null && objOrderHistoryFullObject.ResponseCode.statusCode == 200)
                    {
                        List<OrderDetailsExportFields> lstStoreResult = new List<OrderDetailsExportFields>();

                        JObject jsonRes = JObject.Parse(objRes);
                        JToken jTokenSearchResult = jsonRes.FindTokens("searchResult").FirstOrDefault();
                        JObject JobjSearchResult = JObject.Parse(jTokenSearchResult.ToString());
                        JToken jTokenOrder = jsonRes.FindTokens("orders").FirstOrDefault();

                        LogHelper.Log("Store: " + objAllMerchantStoreInformation.merchantStoreName + " Orders Count: " + jTokenOrder.Children().Count() + " Time: " + DateTime.Now);

                        foreach (var jObjectOrder in jTokenOrder.Children())
                        {
                            OrderHistoryResultModel objOrderHistory = JsonConvert.DeserializeObject<OrderHistoryResultModel>(jObjectOrder.ToString());

                            if (!lstStoreResult.Any(s => s.TicketNo == objOrderHistory.transactionCode && objOrderHistory.paymentType == "SPLITCHECK"))
                            {
                                OrderDetailsExportFields objOrderDetailsExportFields = new OrderDetailsExportFields();
                                objOrderDetailsExportFields.TicketNo = objOrderHistory.transactionCode;
                                objOrderDetailsExportFields.Type = objOrderHistory.orderType;
                                objOrderDetailsExportFields.Employee = objOrderHistory.userFirstName + " " + objOrderHistory.userLastName;
                                objOrderDetailsExportFields.Store = objAllMerchantStoreInformation.merchantStoreName;
                                objOrderDetailsExportFields.Date = Convert.ToDateTime(objOrderHistory.orderDate).ToString("MM/dd/yyyy");
                                objOrderDetailsExportFields.Time = Convert.ToDateTime(objOrderHistory.orderDate).ToString("hh:mm tt");
                                objOrderDetailsExportFields.ItemName = objOrderHistory.listOfItems;
                                objOrderDetailsExportFields.PaymentType = objOrderHistory.paymentType;
                                objOrderDetailsExportFields.TransactionType = objOrderHistory.paymentInfo.FirstOrDefault().transactionType;
                                objOrderDetailsExportFields.GrossSale = objOrderHistory.subTotal;
                                objOrderDetailsExportFields.Discounts = objOrderHistory.discount;
                                objOrderDetailsExportFields.Refunds = objOrderHistory.refundAmount;
                                objOrderDetailsExportFields.NetSale = objOrderDetailsExportFields.GrossSale - objOrderDetailsExportFields.Discounts - objOrderDetailsExportFields.Refunds;
                                objOrderDetailsExportFields.Tips = objOrderHistory.tip;
                                objOrderDetailsExportFields.Tax = objOrderHistory.tax;
                                objOrderDetailsExportFields.Total = objOrderDetailsExportFields.NetSale + objOrderDetailsExportFields.Tax + objOrderDetailsExportFields.Tips;

                                //lstStoreResult.Add(objOrderDetailsExportFields);

                                //OrderHistoryResultModel objOrderHistory = JsonConvert.DeserializeObject<OrderHistoryResultModel>(jObjectOrder.ToString());
                                if (objOrderHistory != null && !string.IsNullOrEmpty(objOrderHistory.orderId))
                                {
                                    List<OrderDetailsExportFields> objResult =
                                        await GetOrderDetailsByOrderID(objOrderHistory.orderId, objOrderHistory.transactionCode, objAllMerchantStoreInformation.merchantIdentification, objOrderHistory.userFirstName + " " + objOrderHistory.userLastName, objAllMerchantStoreInformation.merchantStoreName, lstItemCategory);

                                    if (objResult != null && objResult.Count() > 0)
                                    {
                                        lstStoreResult.AddRange(objResult);

                                        double ItemDetailsSum = objResult.Sum(s => s.NetSale);
                                        //double difference = objOrderDetailsExportFields.NetSale - ItemDetailsSum;
                                        //if (!objOrderDetailsExportFields.NetSale.Equals3DigitPrecision(ItemDetailsSum))
                                        //{
                                        if (Math.Abs(objOrderDetailsExportFields.NetSale - ItemDetailsSum) > 0.1)
                                        {
                                            double difference = objOrderDetailsExportFields.NetSale - ItemDetailsSum;
                                            LogHelper.Log("Ticket no: " + objOrderHistory.transactionCode + " Order ID:" + objOrderHistory.orderId + " Order NetSale: " + objOrderDetailsExportFields.NetSale + " Order Details Net Sale: " + ItemDetailsSum + " Difference: " + difference + " Order Date:" + objOrderDetailsExportFields.Date + " Time:" + objOrderDetailsExportFields.Time);
                                        }

                                        double GrossSaleSum = objResult.Sum(s => s.GrossSale);
                                        //double GrossSaledifference = objOrderDetailsExportFields.GrossSale - GrossSaleSum;
                                        if (Math.Abs(objOrderDetailsExportFields.GrossSale - GrossSaleSum) > 0.1)
                                        {
                                            double GrossSaledifference = objOrderDetailsExportFields.GrossSale - GrossSaleSum;
                                            LogHelper.Log("Ticket no: " + objOrderHistory.transactionCode + " Order ID:" + objOrderHistory.orderId + " Order GrossSale: " + objOrderDetailsExportFields.GrossSale + " Order Details Gross Sale: " + GrossSaleSum + " Difference: " + GrossSaledifference + " Order Date:" + objOrderDetailsExportFields.Date + " Time:" + objOrderDetailsExportFields.Time);
                                        }
                                    }
                                }
                            }
                            else
                            {
                                LogHelper.Log("Transaction is duplicate. Transaction Code: " + objOrderHistory.transactionCode);
                            }
                        }
                        lstFinalResult.AddRange(lstStoreResult);
                    }
                }
                catch (Exception ex)
                {
                    LogHelper.Log("Error: " + ex.Message);
                }
            }

            try
            {
                LogHelper.Log("Total Records: " + lstFinalResult.Count());

                var lstOutOfDateRangeOrder = lstFinalResult.Where(s => Convert.ToDateTime(s.Date) < Convert.ToDateTime(startdate) || Convert.ToDateTime(s.Date) > Convert.ToDateTime(enddate));
                if (lstOutOfDateRangeOrder != null && lstOutOfDateRangeOrder.Count() > 0)
                {
                    lstFinalResult = lstFinalResult.Where(s => Convert.ToDateTime(s.Date) >= Convert.ToDateTime(startdate) && Convert.ToDateTime(s.Date) <= Convert.ToDateTime(enddate)).ToList();
                    LogHelper.Log("After removing out of range orders. Total Records: " + lstFinalResult.Count() + " " + DateTime.Now);

                    List<OrderDetailsExportFields> lstNewOrder = new List<OrderDetailsExportFields>();
                    foreach (var item in lstOutOfDateRangeOrder)
                    {
                        LogHelper.Log("Store: " + item.Store + "Ticket no: " + item.TicketNo + " Order ID:" + item.orderID + " Order Date:" + item.Date + " Time:" + item.Time);

                        string merchantStoreIdentification = lstAllMerchantStoreInformation.FirstOrDefault(s => s.merchantStoreName.ToLower() == item.Store.ToLower()).merchantIdentification;
                        lstNewOrder = await GetOrderDetailsByOrderID(item.orderID, item.TicketNo, merchantStoreIdentification, item.Employee, item.Store, lstItemCategory);

                        if (lstNewOrder != null && lstNewOrder.Count() > 0)
                        {
                            lstFinalResult.AddRange(lstNewOrder);
                        }
                    }

                    LogHelper.Log("After calling again order details api method and added new records into list. Total Records: " + lstFinalResult.Count() + " " + DateTime.Now);
                }

                string filename = "ItemDetails_All_Stores_" + Convert.ToDateTime(startdate).ToString("MM-dd-yyyy") + "_API";
                SaveItemOrderDetailsIntoExcel(lstFinalResult, filename);

                LogHelper.Log("File: " + filename + " saved successfully. " + DateTime.Now);
            }
            catch (Exception ex)
            {
                LogHelper.Log("Error in Item order details save data into excel/db. " + ex.Message);
            }

            return 0;

        }

        public async Task<List<OrderDetailsExportFields>> GetOrderDetailsByOrderID(string orderID, string transactionCode, string merchantIdentification, string Employeename, string storeName, List<ItemCategoryResultModel> lstItemCategory)
        {
            TalechAPI_Token objTalechAPI_Token = new TalechAPI_Token();
            List<OrderDetailsExportFields> lstOrderDetailsExportFields = new List<OrderDetailsExportFields>();
            try
            {

                OrderDetails objOrderDetails = new OrderDetails()
                {
                    orderId = orderID//"10075532813763"
                };

                string jsonString = JsonConvert.SerializeObject(objOrderDetails);
                JObject objInputParameters = JObject.Parse(jsonString);

                using (HttpClient client = new HttpClient())
                {
                    objTalechAPI_Token.SetHTTPClientObjectValues(client);
                    HttpResponseMessage response = await objTalechAPI_Token.ExecuteClientPostMethod("order/getorderbyid", objInputParameters, client, APICommonHelper.TalechSecurityToken, merchantIdentification);
                    if (response.IsSuccessStatusCode)
                    {
                        objTalechAPI_Token.SetRefreshToken(response);

                        var objRes = await response.Content.ReadAsStringAsync();
                        OrderDetailsResultModel objOrderDetailsResultModel = JsonConvert.DeserializeObject<OrderDetailsResultModel>(objRes.ToString());

                        double tips = 0.0;
                        foreach (OrderDetail objOrderDetail in objOrderDetailsResultModel.Order.orderDetails)
                        {
                            OrderDetailsExportFields objOrderDetailsExportFields = setItemOrderObject(objOrderDetailsResultModel, objOrderDetail, transactionCode, Employeename, storeName, ref tips, lstItemCategory, orderID);
                            lstOrderDetailsExportFields.Add(objOrderDetailsExportFields);

                            if (objOrderDetail.addOns != null && objOrderDetail.addOns.Count() > 0)
                            {
                                foreach (AddOns objAddOns in objOrderDetail.addOns)
                                {
                                    OrderDetailsExportFields objOrderDetailsExportFields_AddOns = new OrderDetailsExportFields();
                                    objOrderDetailsExportFields_AddOns.orderID = orderID;
                                    objOrderDetailsExportFields_AddOns.TicketNo = transactionCode;
                                    objOrderDetailsExportFields_AddOns.Type = objOrderDetailsResultModel.Order.orderType;
                                    objOrderDetailsExportFields_AddOns.Employee = Employeename;
                                    objOrderDetailsExportFields_AddOns.Store = storeName;
                                    objOrderDetailsExportFields_AddOns.Date = Convert.ToDateTime(objOrderDetailsResultModel.Order.orderCreationTime).ToString("MM/dd/yyyy");
                                    objOrderDetailsExportFields_AddOns.Time = Convert.ToDateTime(objOrderDetailsResultModel.Order.orderCreationTime).ToString("hh:mm tt");
                                    var categoryObj = lstItemCategory.FirstOrDefault(s => s.name.Contains(objAddOns.name));
                                    if (categoryObj != null)
                                        objOrderDetailsExportFields_AddOns.CategoryName = lstItemCategory.FirstOrDefault(s => s.name.Contains(objAddOns.name)).categoryType;//objCategory.FirstOrDefault(s => s.Key == objOrderDetail.categoryId.ToString()).Value;
                                    objOrderDetailsExportFields_AddOns.ItemName = objAddOns.name;
                                    if (objAddOns.refundedQuantity == 0.0 && objAddOns.quantity < objAddOns.printedQuantity && !objAddOns.quantity.Equals3DigitPrecision(objAddOns.printedQuantity))
                                    {
                                        objOrderDetailsExportFields_AddOns.QtySold = objAddOns.printedQuantity;
                                        LogHelper.Log("AddOns Item: Quantity: " + objAddOns.quantity + ",Printed Quantity: " + objAddOns.printedQuantity + ",Refunded Quantity: " + objAddOns.refundedQuantity);
                                    }
                                    else
                                        objOrderDetailsExportFields_AddOns.QtySold = objAddOns.quantity + objAddOns.refundedQuantity;

                                    objOrderDetailsExportFields_AddOns.PaymentType = objOrderDetailsResultModel.Order.paymentDetails.FirstOrDefault().paymentType;
                                    objOrderDetailsExportFields_AddOns.CreditType = objOrderDetailsResultModel.Order.paymentDetails.FirstOrDefault().cardType;
                                    objOrderDetailsExportFields_AddOns.GrossSale = objAddOns.price * objOrderDetailsExportFields_AddOns.QtySold;
                                    objOrderDetailsExportFields_AddOns.Discounts = objAddOns.discountAmt * (objAddOns.quantity + objAddOns.refundedQuantity);
                                    objOrderDetailsExportFields_AddOns.Refunds = objAddOns.price * objAddOns.refundedQuantity;
                                    objOrderDetailsExportFields_AddOns.NetSale =
                                        (objOrderDetailsExportFields_AddOns.GrossSale - objOrderDetailsExportFields_AddOns.Discounts - objOrderDetailsExportFields_AddOns.Refunds) < 0 ? 0 : (objOrderDetailsExportFields_AddOns.GrossSale - objOrderDetailsExportFields_AddOns.Discounts - objOrderDetailsExportFields_AddOns.Refunds);
                                    objOrderDetailsExportFields_AddOns.Tips = 0.0;
                                    objOrderDetailsExportFields_AddOns.Tax = objAddOns.tax;
                                    objOrderDetailsExportFields_AddOns.Total = objOrderDetailsExportFields_AddOns.NetSale + objOrderDetailsExportFields_AddOns.Tax + objOrderDetailsExportFields_AddOns.Tips;

                                    lstOrderDetailsExportFields.Add(objOrderDetailsExportFields_AddOns);
                                }
                            }
                        }

                    }

                }
            }
            catch (Exception ex)
            {
                LogHelper.Log("Error in Order details method. OrderID: " + orderID + " Error: " + ex.Message);
            }

            return lstOrderDetailsExportFields;

        }

        public OrderDetailsExportFields setItemOrderObject(OrderDetailsResultModel objOrderDetailsResultModel, OrderDetail objOrderDetail,
            string transactionCode, string Employeename, string storeName, ref double tips,
            List<ItemCategoryResultModel> lstItemCategory, string orderID)
        {

            OrderDetailsExportFields objOrderDetailsExportFields = new OrderDetailsExportFields();
            objOrderDetailsExportFields.orderID = orderID;
            objOrderDetailsExportFields.TicketNo = transactionCode;
            objOrderDetailsExportFields.Type = objOrderDetailsResultModel.Order.orderType;
            objOrderDetailsExportFields.Employee = Employeename;
            objOrderDetailsExportFields.Store = storeName;
            objOrderDetailsExportFields.Date = Convert.ToDateTime(objOrderDetailsResultModel.Order.orderCreationTime).ToString("MM/dd/yyyy");
            objOrderDetailsExportFields.Time = Convert.ToDateTime(objOrderDetailsResultModel.Order.orderCreationTime).ToString("hh:mm tt");
            var categoryObj = lstItemCategory.FirstOrDefault(s => s.name.Contains(objOrderDetail.name));
            if (categoryObj != null)
                objOrderDetailsExportFields.CategoryName = lstItemCategory.FirstOrDefault(s => s.name.Contains(objOrderDetail.name)).categoryType;//objCategory.FirstOrDefault(s => s.Key == objOrderDetail.categoryId.ToString()).Value;
            objOrderDetailsExportFields.ItemName = objOrderDetail.name;
            //LogHelper.Log("Regular Item: Quantity: " + objOrderDetail.quantity + ",Printed Quantity: " + objOrderDetail.printedQuantity + ",Refunded Quantity: " + objOrderDetail.refundedQuantity);
            objOrderDetailsExportFields.QtySold = objOrderDetail.quantity + objOrderDetail.refundedQuantity;
            objOrderDetailsExportFields.PaymentType = objOrderDetailsResultModel.Order.paymentDetails.FirstOrDefault().paymentType;
            objOrderDetailsExportFields.CreditType = objOrderDetailsResultModel.Order.paymentDetails.FirstOrDefault().cardType;
            objOrderDetailsExportFields.GrossSale = objOrderDetail.price * objOrderDetailsExportFields.QtySold;
            objOrderDetailsExportFields.Discounts = objOrderDetail.discountAmt * objOrderDetailsExportFields.QtySold;
            objOrderDetailsExportFields.Refunds = objOrderDetail.price * objOrderDetail.refundedQuantity;
            //If net sale is less than 0 then all items are refunded. So net sale = 0
            objOrderDetailsExportFields.NetSale =
                (objOrderDetailsExportFields.GrossSale - objOrderDetailsExportFields.Discounts - objOrderDetailsExportFields.Refunds) < 0 ? 0 : (objOrderDetailsExportFields.GrossSale - objOrderDetailsExportFields.Discounts - objOrderDetailsExportFields.Refunds);

            if (tips == 0.0)
                tips = objOrderDetailsExportFields.Tips = objOrderDetailsResultModel.Order.tipsAmount;
            else
                objOrderDetailsExportFields.Tips = 0.0;
            objOrderDetailsExportFields.Tax = objOrderDetail.tax;
            objOrderDetailsExportFields.Total = objOrderDetailsExportFields.NetSale + objOrderDetailsExportFields.Tax + objOrderDetailsExportFields.Tips;

            return objOrderDetailsExportFields;
        }

        public void SaveItemOrderDetailsIntoExcel(List<OrderDetailsExportFields> lstFinalResult, string sheetName)
        {

            if (lstFinalResult != null && lstFinalResult.Count() > 0)
            {
                DataTable dtOrderDetail = new DataTable("Order_Details");
                dtOrderDetail.Columns.Add("Ticket #");
                dtOrderDetail.Columns.Add("Type", typeof(string));
                dtOrderDetail.Columns.Add("Employee", typeof(string));
                dtOrderDetail.Columns.Add("Date", typeof(string));
                dtOrderDetail.Columns.Add("Time", typeof(string));
                dtOrderDetail.Columns.Add("Store", typeof(string));
                dtOrderDetail.Columns.Add("Category", typeof(string));
                dtOrderDetail.Columns.Add("Item Name", typeof(string));
                dtOrderDetail.Columns.Add("Qty Sold", typeof(double));
                //dtOrderDetail.Columns.Add("Transaction Type", typeof(string));
                dtOrderDetail.Columns.Add("Payment Type", typeof(string));
                dtOrderDetail.Columns.Add("Credit Type", typeof(string));
                dtOrderDetail.Columns.Add("Gross Sale", typeof(double));
                dtOrderDetail.Columns.Add("Discounts", typeof(double));
                dtOrderDetail.Columns.Add("Refund", typeof(double));
                dtOrderDetail.Columns.Add("Net Sale", typeof(double));
                dtOrderDetail.Columns.Add("Tips", typeof(double));
                dtOrderDetail.Columns.Add("Tax", typeof(double));
                dtOrderDetail.Columns.Add("Total", typeof(double));


                foreach (var objResult in lstFinalResult)
                {
                    DataRow dr = dtOrderDetail.NewRow();

                    dr["Ticket #"] = objResult.TicketNo;
                    dr["Type"] = objResult.Type == "togo" ? "To Go" : "To Stay";
                    dr["Employee"] = objResult.Employee;
                    dr["Date"] = objResult.Date;
                    dr["Time"] = objResult.Time;
                    dr["Store"] = objResult.Store;
                    dr["Category"] = objResult.CategoryName;
                    dr["Item Name"] = objResult.ItemName;
                    dr["Qty Sold"] = objResult.QtySold;
                    //dr["Transaction Type"] = objResult.TransactionType;
                    dr["Payment Type"] = objResult.PaymentType;
                    dr["Credit Type"] = objResult.CreditType;
                    dr["Gross Sale"] = objResult.GrossSale;
                    dr["Discounts"] = objResult.Discounts;
                    dr["Refund"] = objResult.Refunds;
                    dr["Net Sale"] = objResult.NetSale;
                    dr["Tips"] = objResult.Tips;
                    dr["Tax"] = objResult.Tax;
                    dr["Total"] = objResult.Total;

                    dtOrderDetail.Rows.Add(dr);
                }

                using (var package = new ExcelPackage())
                {
                    // Add a new worksheet to the empty workbook
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(sheetName);

                    worksheet.Cells["A1"].LoadFromDataTable(dtOrderDetail, true, TableStyles.Light9);
                    worksheet.Cells.AutoFitColumns(0);
                    worksheet.Cells[2, 11, dtOrderDetail.Rows.Count + 1, 18].Style.Numberformat.Format = "$#,##0.00";

                    FileInfo objFile = LogHelper.GetFileInfo(AppDomain.CurrentDomain.BaseDirectory, sheetName + ".xlsx");
                    package.SaveAs(objFile);
                }
            }
        }

    }


}
