﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7LeavesCafeReport_BLL.Helpers
{
    public static class LogHelper
    {
        public static void Log(string message)
        {
           
            using (FileStream objFileStream = new FileStream(AppDomain.CurrentDomain.BaseDirectory + "\\LogFile.txt", FileMode.Append, FileAccess.Write))
            {
                using (StreamWriter sw = new StreamWriter(objFileStream))
                {
                    sw.WriteLine(message);
                }
            }
        }       
    }
}
