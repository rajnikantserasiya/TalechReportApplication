﻿using _7LeavesCafeReport_DAL.Helpers.Helpers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7LeavesCafeReport_DAL
{
   public class StoreRevenueHoulrySummary_DAL
    {
       public bool SaveAllMerchantStoreDetails(DataTable OrderSummary, DataTable ReceiptTypeSummary, DataTable TimePeriodSummaryAll, DataTable TimePeriodSummaryTransactionDetails)
        {
            try
            {
                //DBHelper.ExecuteNonQuery("", GetSaveAllMerchantStoreDetailsParameters(dtAllmerchantStore));

                DBHelper.ExecuteProcedure("SaveSummaryDetails", GetSaveAllMerchantStoreDetailsParameters(OrderSummary, ReceiptTypeSummary, TimePeriodSummaryAll, TimePeriodSummaryTransactionDetails));
                return true;
            }
            catch (Exception ex)
            {
                return false;
                //throw;
            }

        }

       public IList<SqlParameter> GetSaveAllMerchantStoreDetailsParameters(DataTable OrderSummary, DataTable ReceiptTypeSummary, DataTable TimePeriodSummaryAll, DataTable TimePeriodSummaryTransactionDetails)
        {
            IList<SqlParameter> lstParameters = new List<SqlParameter>();

            SqlParameter parameters = new SqlParameter();
            parameters.ParameterName = "@OrderSummary";
            parameters.SqlDbType = SqlDbType.Structured;
            parameters.Value = OrderSummary;

            lstParameters.Add(parameters);

            SqlParameter parameters1 = new SqlParameter();
            parameters1.ParameterName = "@ReceiptTypeSummary";
            parameters1.SqlDbType = SqlDbType.Structured;
            parameters1.Value = ReceiptTypeSummary;

            lstParameters.Add(parameters1);

            SqlParameter parameters2 = new SqlParameter();
            parameters2.ParameterName = "@TimePeriodSummaryAll";
            parameters2.SqlDbType = SqlDbType.Structured;
            parameters2.Value = TimePeriodSummaryAll;

            lstParameters.Add(parameters2);

            SqlParameter parameters3 = new SqlParameter();
            parameters3.ParameterName = "@TimePeriodSummaryTransactionDetails";
            parameters3.SqlDbType = SqlDbType.Structured;
            parameters3.Value = TimePeriodSummaryTransactionDetails;

            lstParameters.Add(parameters3);

            return lstParameters;
        }
    }
}
