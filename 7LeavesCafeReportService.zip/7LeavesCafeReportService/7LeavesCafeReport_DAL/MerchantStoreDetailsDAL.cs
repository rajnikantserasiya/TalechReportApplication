﻿using _7LeavesCafeReport_DAL.Helpers.Helpers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7LeavesCafeReport_DAL
{
    public class MerchantStoreDetailsDAL
    {
        /// <summary>
        /// Save All Merchant Store Details
        /// </summary>
        /// <param name="dtAllmerchantStore"></param>
        /// <returns></returns>
        public bool SaveAllMerchantStoreDetails(DataTable dtAllmerchantStore)
        {
            try
            {
                //DBHelper.ExecuteNonQuery("", GetSaveAllMerchantStoreDetailsParameters(dtAllmerchantStore));

                DBHelper.ExecuteProcedure("SaveMerchantStoreDetails", GetSaveAllMerchantStoreDetailsParameters(dtAllmerchantStore));
                return true;
            }
            catch (Exception ex)
            {
                return false;
                //throw;
            }

        }

        public IList<SqlParameter> GetSaveAllMerchantStoreDetailsParameters(DataTable dtAllmerchantStore)
        {
            IList<SqlParameter> lstParameters = new List<SqlParameter>();

            SqlParameter parameters = new SqlParameter();
            parameters.ParameterName = "@userStoreDetails";
            parameters.SqlDbType = SqlDbType.Structured;
            parameters.Value = dtAllmerchantStore;

            lstParameters.Add(parameters);

            return lstParameters;
        }
    }
}
