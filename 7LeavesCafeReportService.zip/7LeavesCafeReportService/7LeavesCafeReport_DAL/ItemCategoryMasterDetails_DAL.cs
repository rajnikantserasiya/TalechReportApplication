﻿using _7LeavesCafeReport_DAL.Helpers.Helpers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7LeavesCafeReport_DAL
{
    public class ItemCategoryMasterDetails_DAL
    {
        public bool SaveItemCategoryMasterDetails_DAL(DataTable dtAllmerchantStore)
        {
            try
            {
                DBHelper.ExecuteProcedure("SaveItemCategoryMasterDetails", GetItemCategoryMasterDetailsParameters(dtAllmerchantStore));
                return true;
            }
            catch (Exception ex)
            {
                return false;
                //throw;
            }

        }

        public IList<SqlParameter> GetItemCategoryMasterDetailsParameters(DataTable dtAllmerchantStore)
        {
            IList<SqlParameter> lstParameters = new List<SqlParameter>();

            SqlParameter parameters = new SqlParameter();
            parameters.ParameterName = "@itemCategoryDetails";
            parameters.SqlDbType = SqlDbType.Structured;
            parameters.Value = dtAllmerchantStore;

            lstParameters.Add(parameters);

            return lstParameters;
        }
    }
}
