﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7LeavesCafeReport_DAL.Helpers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Data;
    using System.Data.SqlClient;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Configuration;

    namespace Helpers
    {
        public static class DBHelper
        {

            private static string defaultConnectionString = ConfigurationManager.ConnectionStrings["7LeavesConnectionString"].ToString();//"Data Source=68.64.167.202;Initial Catalog=GLOBOBH_MapaAntenas;Integrated Security=SSPI";

            public static string DefaultConnectionString
            {
                get
                {
                    return defaultConnectionString;
                }
            }

            public static DataTable ExecuteProcedure(string PROC_NAME, IList<SqlParameter> parameters)
            {

                try
                {
                    DataTable dtResult = new DataTable();
                    dtResult = Query(PROC_NAME, parameters);
                    
                    return dtResult;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }          

            public static int ExecuteNonQuery(string PROC_NAME, IList<SqlParameter> parameters)
            {
                try
                {
                    return NonQuery(PROC_NAME, parameters);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            public static object ExecuteScalar(string PROC_NAME, IList<SqlParameter> parameters)
            {
                try
                {
                    return Scalar(PROC_NAME, parameters);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            #region Private Methods

            private static DataTable Query(String query, IList<SqlParameter> parametros)
            {              
                try
                {
                    DataTable dt = new DataTable();
                    SqlConnection connection = new SqlConnection(defaultConnectionString);
                    SqlCommand command = new SqlCommand();
                    SqlDataAdapter da;
                    try
                    {
                        connection.Open();                       
                        command.Connection = connection;
                        command.CommandText = query;
                        command.CommandType = CommandType.StoredProcedure;
                        if (parametros != null)
                        {
                            command.Parameters.AddRange(parametros.ToArray());                            
                        }
                        da = new SqlDataAdapter(command);
                        da.Fill(dt);                       
                    }
                    finally
                    {
                        if (connection != null)
                            connection.Close();
                    }
                    return dt;
                }
                catch (Exception ex)
                {                   
                    throw;
                }

            }

            private static int NonQuery(string query, IList<SqlParameter> parameters)
            {
                SqlTransaction objTrans = null;
                int noofRowsAffected = 0;

                try
                {


                    DataSet dt = new DataSet();
                    SqlConnection connection = new SqlConnection(defaultConnectionString);
                    SqlCommand command = new SqlCommand();

                    try
                    {
                        connection.Open();
                        objTrans = connection.BeginTransaction();
                        command.Connection = connection;
                        command.CommandText = query;
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddRange(parameters.ToArray());
                        noofRowsAffected = command.ExecuteNonQuery();

                        objTrans.Commit();

                    }
                    finally
                    {
                        if (connection != null)
                            connection.Close();
                    }

                }
                catch (Exception ex)
                {
                    objTrans.Rollback();
                    throw ex;
                }

                return noofRowsAffected;
            }

            private static object Scalar(string query, IList<SqlParameter> parametros)
            {
                SqlTransaction objTrans = null;
                object id = 0;

                try
                {
                    DataSet dt = new DataSet();
                    SqlConnection connection = new SqlConnection(defaultConnectionString);
                    SqlCommand command = new SqlCommand();

                    try
                    {
                        connection.Open();
                        objTrans = connection.BeginTransaction();
                        command.Connection = connection;
                        command.CommandText = query;
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddRange(parametros.ToArray());

                        id = command.ExecuteScalar();
                        objTrans.Commit();

                    }
                    finally
                    {
                        if (connection != null)
                            connection.Close();
                    }

                }
                catch (Exception ex)
                {
                    objTrans.Rollback();
                    throw ex;
                }

                return id;
            }

            #endregion
        }

    }
}
