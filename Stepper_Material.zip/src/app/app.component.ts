import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {MatStepperModule, VERSION} from '@angular/material';
import { StepperSelectionEvent } from '@angular/cdk/stepper';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

    //ng add @angular/material
    //npm install --save @angular/material @angular/cdk @angular/animations
    

    isLinear = false;
    firstFormGroup: FormGroup;
    secondFormGroup: FormGroup;
    selectedIndex = 0;

    constructor(private _formBuilder: FormBuilder) { }

    ngOnInit() {

        // Form Validation
        this.firstFormGroup = this._formBuilder.group({
            firstCtrl: ['', Validators.required]
        });
        this.secondFormGroup = this._formBuilder.group({
            secondCtrl: ['', Validators.required]
        });
    }   
    
    //get current step index and next step index
    public selectionChange($event?: StepperSelectionEvent): void {
        console.log('stepper.selectedIndex: ' + this.selectedIndex
            + '; $event.selectedIndex: ' + $event.selectedIndex);

        if ($event.selectedIndex == 0) return; // First step is still selected

        this.selectedIndex = $event.selectedIndex;
    }    
}
