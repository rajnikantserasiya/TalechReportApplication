
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'paginationFilter'
})
export class PaginationPipe implements PipeTransform {
    //it will take initial and end index and will return the filtered items 
    transform(items: any[], filterConfig: object): any[] {
        if (!items) return [];
        else if (filterConfig["startIndex"] && filterConfig["itemsPerPage"]) {
            items = items.slice((filterConfig["startIndex"] - 1) * filterConfig["itemsPerPage"], filterConfig["startIndex"] * filterConfig["itemsPerPage"]);
        }
        if (filterConfig["searchText"] && filterConfig["searchText"].length > 0) {
            //need to see filter works on a single field or all the fields of an object
        }
        return items.filter(item => {
            return item;
        });
    }
}