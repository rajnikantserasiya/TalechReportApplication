import { PaginationPipe } from './pagination.pipe';

describe('PaginationPipe', () => {
  it('create an instance', () => {
    const pipe = new PaginationPipe();
    expect(pipe).toBeTruthy();
  });
});
