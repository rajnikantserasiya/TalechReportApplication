import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/delay';

export class AuthService {

    // Assuming this would be cached somehow from a login call.
    public authTokenStale: string = localStorage.getItem("token");
    public currentToken: string;

    constructor() {
        this.currentToken = this.authTokenStale;
    }

    getAuthToken() {
        return this.currentToken;
    }

    setAuthToken(token) {
        //debugger;
        localStorage.setItem("token", token);
        this.currentToken = this.authTokenStale = localStorage.getItem("token");
    }

    setTokenExpiryTime(dtExpiry) {
        localStorage.setItem("tokenExpiryTime", dtExpiry);
    }

    getTokenExpiryTime() {
        return localStorage.getItem("tokenExpiryTime");
    }


}