import { Injectable } from "@angular/core";
import { HttpInterceptor, HttpRequest, HttpHandler, HttpSentEvent, HttpHeaderResponse, HttpProgressEvent, HttpResponse, HttpUserEvent, HttpErrorResponse } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/finally';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/take';
//Azure AD Changes
import { CommonService } from '../services/common.service';
import {Http, Response, Headers, RequestOptions} from "@angular/http";
import { LoaderService } from './../services/loader.service';
import {DialogModule} from 'primeng/dialog';

import { AuthService } from "./auth.service";
import { LogoutService } from '../services/logout.service';

@Injectable()
export class InterceptorComponent implements HttpInterceptor {

    display: boolean = false;
    errorMessage = '';
    private IsSessionexpiredPopupDisplayed: boolean = false;

    //Azure AD Changes (Added private _http: Http)
    constructor(private authService: AuthService, private _http: Http,
        private loaderService: LoaderService, private logoutService: LogoutService,
        private commonService: CommonService) { }

    addToken(req: HttpRequest<any>, token: string): HttpRequest<any> {

        //this.loaderService.display(true); 

        //Azure AD Changes
        if (this.commonService.getAzureADAuthenticationEnableFlagValue()) {
            req = req.clone({ headers: req.headers.set('Authorization', 'Bearer ' + token) });
        }
        return req;
               
    }


    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpSentEvent | HttpHeaderResponse | HttpProgressEvent | HttpResponse<any> | HttpUserEvent<any>> {

        return next.handle(this.addToken(req, this.authService.getAuthToken())).do((event: HttpResponse<any>) => {
            if (event instanceof HttpResponse) {
                //this.loaderService.display(false);
                this.refreshToken();
            }
        }, (err: any) => {
            if (err instanceof HttpErrorResponse) {

                //if (err.status === 401 || err.status === 403) {
                if (err.status === 401) {
                    //Azure AD Changes                    
                    if (!this.IsSessionexpiredPopupDisplayed) {
                        this.IsSessionexpiredPopupDisplayed = true;
                        alert("Your session has been expired. Please logout and log in again.");
                        this.logoutService.logoutUserFromAzureAD();
                    }
                    //console.log("handle error here")
                }
                else {
                    this.refreshToken();
                }

            }
        });
    }

    //Azure AD Changes 
    private refreshToken() {
        if (this.commonService.getAzureADAuthenticationEnableFlagValue()) {

            let tokenExpiryTime: Date = new Date(this.authService.getTokenExpiryTime());
            let currentTime: Date = new Date();

            if (currentTime < tokenExpiryTime && tokenExpiryTime.getMinutes() - currentTime.getMinutes() <= 30 && tokenExpiryTime.getMinutes() - currentTime.getMinutes() > 0) {
                console.log("Token Expiry Time: " + tokenExpiryTime);
                console.log("Current Time: " + currentTime);
                this.logoutService.refreshToken();
            }
        }
    }


    //Azure AD Changes
    private handleError(error: any): any {
        //let body = error.json();
        console.log(error);
    }

    private showDialog(message) {
        this.errorMessage = message;
        this.display = true;
    }

}
