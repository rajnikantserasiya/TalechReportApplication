import { Component, OnInit } from '@angular/core';
import { SelectEquipmentMasterService } from './../services/select-equipment-master.service';
import { GetEqBySnService } from './../services/get-eq-by-sn.service';
import { AddPopupService } from '../add-popup/add-popup.component';
import {CustomerCountryService} from './../services/customer-country.service';
import { Country_mm } from '../services/eq-exclusions-class';
import { DataService } from './../services/data-component.service';
import {PaginationPipe} from '../pipes/pagination.pipe';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { AppConstant } from './../app.constant';

@Component({
    selector: 'app-select-equipment-exist-sn',
    templateUrl: './select-equipment-exist-sn.component.html',
    styleUrls: ['./select-equipment-exist-sn.component.css'],
    providers: [GetEqBySnService, AddPopupService, CustomerCountryService]
})
export class SelectEquipmentExistSnComponent implements OnInit {

    ccHeadText = "CC";
    custHeadText = "Customer";
    siteHeadText = "Site";
    snHeadText = "SN";
    modHeadText = "Model";
    modcatHeadText = "Model Category";
    ActivOnlyText = " Active Only";
    searchboxText = "Search";
    addText = "Add >";

    pagingConfig = { "startIndex": 1, "endIndex": 5, "itemsPerPage": 10, "action": "refresh" };
   
    equipbysnOriginal: any = [];
    totalCount: number = 0;

    selectedItems: any = [];
    selectedMODELItems: any = [];
    selectedMODELLife: any = [];
    selectedMODELCATEGORY: any =[];
    selectedMODELHR_TYPE: any =[];
    selectedHrsYear1Boom: any =[];

    searchText: string = "";

    checkedColumnCount: number = 0;

    public countrymm: Country_mm[];

    public equipbysn: SelectEquipmentMasterService[];

    COUNTRY = 'Select Country';
    loadFlag = false;

    constructor(private selectEquipmentMasterService: SelectEquipmentMasterService, private addPopupService: AddPopupService, private customerCountryService: CustomerCountryService, private dataService : DataService , private fetchCurrentDataService : FetchCurrentDataService , private appConstant : AppConstant) {
        this.fetchCurrentDataService.screenDataStream$.subscribe(
            () => {
              if(!this.fetchCurrentDataService.disableFlagSaveExistingSN){
                this.fetchCurrentDataService.disableFlagSaveExistingSN = true;
                if(this.equipbysn &&  this.equipbysn.length>0){   
                    this.fetchCurrentDataService.createJsonToSave(this.equipbysn, this.appConstant.selectedSnRoot);
                    this.fetchCurrentDataService.createJsonToSave(this.countrymm, this.appConstant.countryList);
                }       
              }           
            });
    }

    ngOnInit() {     
        document.getElementById("slide-nav").style.width = "0";
        var cachedData = this.dataService.getData('countryList' );
        if(cachedData && cachedData.length>0){ 
            if (localStorage.getItem("COUNTRY") == null || localStorage.getItem("COUNTRY") == "") {
                this.countrymm = cachedData;
                this.selectEquipmentMasterService.selectEquipment((cachedData.length.toString()));
            }
            else
            {
                this.countrymm = cachedData;
                this.selectEquipmentMasterService.selectEquipment((cachedData.length.toString()));
                this.COUNTRY = localStorage.getItem("COUNTRY") || '';
                this.getEquipBySN(this.COUNTRY);
            }

        } else {
            if (localStorage.getItem("COUNTRY") == null || localStorage.getItem("COUNTRY") == "") {
                this.getCountryByMM();
            }
            else
            {
                this.getCountryByMM();
                this.COUNTRY = localStorage.getItem("COUNTRY")||'';
                this.getEquipBySN(this.COUNTRY);
            }
        }       
    }
   
    getCustomList(COUNTRY) {
        if(COUNTRY) {
            localStorage.setItem("COUNTRY", COUNTRY);   
        }        
    }
    
    getCountryByMM(): void {
        this.customerCountryService.customerCountryData().then(result => {
            this.countrymm = result;
            this.dataService.setData('countryList', result , false );
            this.customerCountryService.selectCountry((result.length.toString()));
       })
        .catch(error => console.log(error));
    }

    continueExistingSessionPopup(): void {
    }

    getEquipBySN(COUNTRY) {
        this.loadFlag = true;
        document.getElementById("slide-nav").style.width = "0";

        if(COUNTRY && COUNTRY != 'Select Country'){
            localStorage.setItem("COUNTRY", COUNTRY);
            this.selectEquipmentMasterService.selectEquipmentMasterData()
                .then(result => {
                    this.loadFlag = false;
                    this.equipbysn = result;
                    this.equipbysnOriginal = JSON.parse(JSON.stringify(result));
                    this.totalCount = this.equipbysn.length;
                }
                )
                .catch(error => console.log(error));
        } else {
            this.loadFlag = false;
            this.equipbysn = [];
            this.equipbysnOriginal = [];
            this.totalCount = 0;
        }
    }

    search(equip, event) {
        document.getElementById("slide-nav").style.width = "0";

        var index = this.selectedItems.indexOf(equip.SERIAL_NO);

        if (event.target.checked) {        
                this.selectedItems.push(equip.SERIAL_NO);
                this.selectedMODELItems.push(equip.MODEL);
                this.selectedMODELLife.push(equip.EQ_LIFE);
                this.selectedMODELCATEGORY.push(equip.MODELCATEGORY);
                this.selectedMODELHR_TYPE.push(equip.HR_TYPE);   
                this.selectedHrsYear1Boom.push(equip.HrsYear1Boom);                                         
        }
        else {
            if (index !== -1) {
                this.selectedItems.splice(index, 1);
                this.selectedMODELItems.splice(index, 1);
                this.selectedMODELLife.splice(index, 1);
                this.selectedMODELCATEGORY.splice(index, 1);
                this.selectedMODELHR_TYPE.splice(index, 1); 
                this.selectedHrsYear1Boom.splice(index, 1); 
            }
        }

        localStorage.setItem("SelectedSN", this.selectedItems);
        localStorage.setItem("SelectedMODEL", this.selectedMODELItems);
        localStorage.setItem("selectedMODELLife", this.selectedMODELLife);
        localStorage.setItem("selectedMODELCATEGORY", this.selectedMODELCATEGORY);
        localStorage.setItem("selectedMODELHR_TYPE", this.selectedMODELHR_TYPE);
        localStorage.setItem("HrsYear1Boom", this.selectedHrsYear1Boom);

        console.log(localStorage.getItem("SelectedSN"));
        console.log(localStorage.getItem("SelectedMODEL"));

        this.maintainCheckedCount();
    }

    maintainCheckedCount() {
        this.checkedColumnCount = 0;
        this.equipbysn.forEach(element => {
            if (element["checked"]) {
                this.checkedColumnCount++;
            }
        });
    }

    add(equipbysn): void {

        document.getElementById("slide-nav").style.width = "0";

        this.selectedItems = [];
        this.selectedMODELItems = [];
        this.selectedMODELLife = [];
        let selectedSNValues: string = localStorage.getItem("SelectedSN");
        if (selectedSNValues != "" && selectedSNValues != null && equipbysn != undefined) {
            let selectedSNValueArr: any = [];
            selectedSNValueArr = selectedSNValues.split(",");
            for (let i = 0; i < selectedSNValueArr.length; i++) {
                var selectedSNValuestr = selectedSNValueArr[i];


                var index = equipbysn.findIndex(obj => obj["SERIAL_NO"] === selectedSNValuestr)
                if (index >= 0) {
                    equipbysn[index]['checked'] = false;
                }

                var indexOriginal = equipbysn.findIndex(obj => obj["SERIAL_NO"] === selectedSNValuestr)
                if (index >= 0) {
                    equipbysn[indexOriginal]['checked'] = false;
                }
            };
        }
        this.maintainCheckedCount();
        this.addPopupService.show();
        
    }

    refreshData(configData): void {
        console.log("Recieved Data from  paging component" + JSON.stringify(configData));
        this.pagingConfig = configData;
        document.getElementById("slide-nav").style.width = "0";
    }

   onSearchTextChange(value): void {

       debugger;
       document.getElementById("slide-nav").style.width = "0";

        if(value.length >= 2){
            this.searchText = value;
            this.pagingConfig["searchText"] = value;
            this.equipbysn = JSON.parse(JSON.stringify(this.equipbysnOriginal));
            let that = this;
            this.equipbysn = this.equipbysn.filter(it => {
                if (that.selectedItems.indexOf(it["SERIAL_NO"]) >= 0) {
                    it["checked"] = true;
                } else {
                    it["checked"] = false;
                }
                value = value.trim();                                   
                return (it["SERIAL_NO"].trim().toUpperCase().includes(value.toUpperCase()) || it["MODEL"].toUpperCase().includes(value.toUpperCase()) || it["MODELCATEGORY"].toUpperCase().includes(value.toUpperCase()));
            });
            this.totalCount = this.equipbysn.length;
            this.pagingConfig = { "startIndex": 1, "endIndex": 5, "itemsPerPage": 10, "action": "refresh" };     
           
        } else  if(value.length == 0){
            let that = this;
            var checkedRecord : any = this.equipbysn.filter(item => {                                  
                return   item["checked"] == true;;
            });
            this.equipbysn = JSON.parse(JSON.stringify(this.equipbysnOriginal));
            this.equipbysn.forEach(item => {
                if (that.selectedItems.indexOf(item["SERIAL_NO"]) >= 0) {
                    item["checked"] = true;
                } else {
                    item["checked"] = false;
                }
            });        
            this.totalCount = this.equipbysn.length;
            this.pagingConfig = { "startIndex": 1, "endIndex": 5, "itemsPerPage": 10, "action": "refresh" };     
        }                      
    }

    enableDisableAdd() {
        return this.checkedColumnCount > 0 ? false : true;
    }

}