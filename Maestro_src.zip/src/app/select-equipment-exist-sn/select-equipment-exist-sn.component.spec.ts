import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectEquipmentExistSnComponent } from './select-equipment-exist-sn.component';

describe('SelectEquipmentExistSnComponent', () => {
  let component: SelectEquipmentExistSnComponent;
  let fixture: ComponentFixture<SelectEquipmentExistSnComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectEquipmentExistSnComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectEquipmentExistSnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
