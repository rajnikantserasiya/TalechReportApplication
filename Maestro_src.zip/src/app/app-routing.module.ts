import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContSessionComponent } from './load-session-specification-tab/load-session-specification-tab.component';
import { AppComponent } from './app.component';
import { MiddleContentHomeComponent } from './middle-content-home/middle-content-home.component';
import { CphReportHtmlformatComponent } from './cph-report-htmlformat/cph-report-htmlformat.component';
import { PartConsumptionReportHtmlFormatComponent } from './part-consumption-report-html-format/part-consumption-report-html-format.component';
import { CostForecastReportHtmlFormatComponent } from './cost-forecast-report-html-format/cost-forecast-report-html-format.component';

export const routes: Routes = [
    { path: '', redirectTo: '/main', pathMatch: 'full' },
    { path: "main", component: MiddleContentHomeComponent },
    { path: "contsession", component: ContSessionComponent },
    { path: "cphreport", component: CphReportHtmlformatComponent },
    { path: "partconsumptionreport", component: PartConsumptionReportHtmlFormatComponent },
    { path: "costforecastreport", component: CostForecastReportHtmlFormatComponent }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }


