import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {
    transform(items: any[], searchText: string): any[] {
        if (!items) return [];
        if (!searchText) return items;        
        return items.filter(it => {

            if (it.SERIAL_NO != undefined) {
                return (it.SERIAL_NO.includes(searchText) || it.MODEL.includes(searchText) || it.MODELCATEGORY.includes(searchText));
            }
            else {
                return (it.MODEL.includes(searchText) || it.MODELCATEGORY.includes(searchText));
            }
        });
    }
}