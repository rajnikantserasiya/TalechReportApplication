import { Component, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable } from '@angular/core';
import {SaveService } from '../services/save.service';
import * as FileSaver from 'file-saver';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { SelectEquipmentMasterService } from './../services/select-equipment-master.service';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { CommonUtil } from './../common/common-util';
import { DataService } from './../services/data-component.service';
import { AppConstant } from './../app.constant';

declare var PNotify: any;

@Component({
    selector: 'app-save-existing-session-popup',
    templateUrl: './save-existing-session-popup.component.html',
    styleUrls: ['./save-existing-session-popup.component.css']
})
export class SaveExistingSessionPopupComponent implements OnInit {

    savefilename: any = 'MaestroSession';
    savefilepath: string;
    showInvalidError: boolean = false;

    constructor(public activeModal: NgbActiveModal, public changeRef: ChangeDetectorRef, private saveService: SaveService, private selectEquipmentMasterService: SelectEquipmentMasterService, private fetchCurrentDataService: FetchCurrentDataService , private commonUtil : CommonUtil , public router : Router , private dataService : DataService , private appConstant : AppConstant) {
    }

    ngOnInit() {
        this.showInvalidError = false;
    }

    onChangeFileName(value : string){
        this.savefilename = value;
        if(value.length ==  0 ){
            this.showInvalidError = false;
        } else {
            if(this.commonUtil.checkSpecialRegex(this.savefilename , false , true)){
                this.showInvalidError = true;
            } else {
                this.showInvalidError = false;
            }   
        }
    }

    onSaveExistingSessionClicked(savefilename, savefilepath): void {    
        if(!this.commonUtil.checkSpecialRegex(this.savefilename , false , true)){
            this.showInvalidError = false;
            if (savefilename.trim() === "") {
                var slideOutDiv = (<HTMLInputElement>document.getElementById("error_login_Save_File"));
                slideOutDiv.style.display = 'block';
            }
            else {
                this.fileSave(savefilename);
                var closeLoginBtn = document.getElementById("closesavefileBtn");
                closeLoginBtn.click();
    
                this.saveService.saveMaestroSessionData().then().catch(error => console.log(error));
            }        
        } else {
            this.showInvalidError = true;
        }                
    }

    private equipmentsSelected: eqSelectedClass[] = [];

    public removeSpaces(e) {
        return e.target.value.split(' ').join('');
    }

    fileSave(savefilename): void {       
        PNotify.prototype.options.styling = "fontawesome";
        PNotify.prototype.options.stack.firstpos2 = 250;
        // UI Changes (Changed width to 500 from 300
        new PNotify({
            text: 'Save Inprogress',
            delay: 3000,
            width: 500
        });    
        this.fetchCurrentDataService.recordData();       
        var that = this;
        setTimeout(() => {
            this.fetchCurrentDataService.disableFlagSaveFactor = false;
            this.fetchCurrentDataService.disableFlagSavePreview = false;
            this.fetchCurrentDataService.disableFlagSaveExclusion = false;
            this.fetchCurrentDataService.disableFlagSaveOptions = false;
            this.fetchCurrentDataService.disableFlagSaveReports = false;    
            this.fetchCurrentDataService.disableFlagSaveSelectedEquip = false;
            this.fetchCurrentDataService.disableFlagSaveCostForcast = false;
            this.fetchCurrentDataService.disableFlagSavePartscon = false; 
            this.fetchCurrentDataService.disableFlagSaveImportBom = false;    
            this.fetchCurrentDataService.disableFlagImportBomPopUp = false;       
            var customer: string = '{' + '"' + "ListSelectedEquipmentsFromUser" + '"' + ":" + JSON.stringify(this.equipmentsSelected) + '}';            
            customer = JSON.stringify(that.fetchCurrentDataService.getJsonAppData());
            var textToSaveAsBlob = new Blob([customer], { type: "text/plain" });           
            var fileNameToSaveAs = savefilename + ".json";
            FileSaver.saveAs(textToSaveAsBlob, fileNameToSaveAs);                           
        }, 3000);
    }

    refreshCurrentTab() {
        //we should set selectedEquip data from api in case screen other than select equipment is active
        this.selectEquipmentMasterService.selectedEquipmentMaster().then(
            result => {
                this.equipmentsSelected = result;
                this.cacheSelectEqipData(result);
                document.getElementById('reload_tab').click();
        })
        .catch(error => console.log(error));
               
    }

    cacheSelectEqipData(data) {
        if (this.dataService.getData(this.appConstant.selectedEquipemtRoot).length == 0) {
            this.dataService.setData(this.appConstant.selectedEquipemtRoot, data, true);
        }     
    }

}

@Injectable() export class SaveExistingSessionPopupService {

    constructor(private modalService: NgbModal) { }

    public show() {
        const modalRef = this.modalService.open(SaveExistingSessionPopupComponent);
        modalRef.componentInstance.name = "showsavefiledlg";
        modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }
}


export class eqSelectedClass {

    UserName: string;
    EqSourceType: string;
    SerialNo: string;
    Model: string;
    Quantity: string;
    HourFrom: string;
    HourTo: string;
    MODELCATEGORY: string;
    EQ_LIFE: string;
    HR_TYPE: string;

}
