import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SaveExistingSessionPopupComponent } from './save-existing-session-popup.component';

describe('SaveExistingSessionPopupComponent', () => {
  let component: SaveExistingSessionPopupComponent;
  let fixture: ComponentFixture<SaveExistingSessionPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SaveExistingSessionPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaveExistingSessionPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
