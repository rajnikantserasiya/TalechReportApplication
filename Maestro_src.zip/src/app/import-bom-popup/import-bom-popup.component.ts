import {Component, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable ,ElementRef} from '@angular/core';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Subject }    from 'rxjs/Subject';
import { PanelModule} from 'primeng/panel';
import { DataService } from './../services/data-component.service';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { AppConstant } from './../app.constant';
import {SelectEquipmentOtherService}  from '../services/select-equipment-other.service';


declare var jquery: any;
declare var $: any; 

@Injectable() export class LoadBomModalService {
    columns : any = [];
    onOkClick = new Subject<any>();
    onOkClickStream$ = this.onOkClick.asObservable();
    
    constructor(private modalService: NgbModal) {   
    }

    public show() {
        const modalRef = this.modalService.open(ImportBomPopupComponent);
        modalRef.componentInstance.name = "importBomPopUp";
        modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }

    setColumns(columns){
        this.columns = columns;
    }

    getColumns() {
        return this.columns;
    }

    onOkClicked(data) {
        this.onOkClick.next(data);
    }
}

@Component({
    selector: 'app-import-bom-popup',
    templateUrl: './import-bom-popup.template.html',
    styleUrls: ['./import-bom-popup.component.css'],
    providers :[SelectEquipmentOtherService]
  })  
  export class ImportBomPopupComponent implements OnInit {
  
    columns : any = [];
    modelCategory : any = [];
    modelList : any = [];
    selectedModelCategory : string = 'select';
    selectedModel : string = 'select';
    formModel : any = { 'modelCategory' :'select' ,'model' :'select' , 'serialNumber':'select' , 'level':'select' , 'parentId':'select', 'parentDescription':'select' , 'item':'select' , 'itemDescription':'select' , 'quantity':'select' , 'lifeHours':'select'};       
    constructor(private eRef : ElementRef , public activeModal: NgbActiveModal, public changeRef: ChangeDetectorRef , private loadBomModalService : LoadBomModalService , private selectEquipmentOtherService : SelectEquipmentOtherService ) {
    }

    ngOnInit() {                
        this.modelCategory = [];
        this.columns = this.loadBomModalService.getColumns();
        this.getModelCategory();
    }

    getModelCategory() {
        this.selectEquipmentOtherService.getModelCategory().then( 
            (data) =>  {         
                if(data) {
                    this.modelCategory = data;                     
                }                       
            }
        )
        .catch(error => console.log(error));
    }

    getModelforBom(value) {          
        this.selectEquipmentOtherService.getModel(value).then( 
            (data) =>  {
                if(data) {
                    this.modelList = data;
                }                
            }
        )
        .catch(error => console.log(error));
    }

    ngOnDestroy() {
        this.columns = [];
    }

    onModelChange(value , str){                   
        if(str === 'modelCategory') {            
            this.selectedModelCategory = value;            
            this.getModelforBom(value);
        } else if(str === 'model') {
            this.selectedModel = value;
        } 
        this.formModel[str] = value;                      
    }
    
    onOkClick() {     
        /*
            callback on parent component registered via subjects            
        */          
        this.loadBomModalService.onOkClicked(this.formModel);
        this.activeModal.dismiss(true);
    }

    onReset() {
        /*
            callback on parent component registered via subjects            
        */   
        this.activeModal.dismiss(true);        
    }

    validateForm() {           
        return $('select').hasClass('ng-invalid-bom-panel');
    }

    getDynamicClass(ref , modelCategory) {
        var className = "";
        className =  modelCategory.value == 'select' ?  'ng-invalid-bom-panel' : 'ng-valid-bom-panel' ;
        return className;
    }
      
  }

