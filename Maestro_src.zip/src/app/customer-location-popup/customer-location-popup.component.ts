import {Component, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable } from '@angular/core';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import {CustomerCountryService} from './../services/customer-country.service';
import { Country_mm } from './../services/Country-mm.service';

@Component({
  selector: 'app-customer-location-popup',
  templateUrl: './customer-location-popup.component.html',
  styleUrls: ['./customer-location-popup.component.css'],
  providers: [CustomerCountryService]
})

export class CustomerLocationPopupComponent implements OnInit {

    countrymm: Country_mm[];
    customermm: Country_mm[];
    COUNTRY: string = "";

    constructor(public activeModal: NgbActiveModal, public changeRef: ChangeDetectorRef,private customerCountryService: CustomerCountryService) { }

    ngOnInit() { 	
		this.getCountryByMM();		
    }

    onOkClicked(COUNTRY): void {        
        var resultString;
		localStorage.setItem("COUNTRY", COUNTRY); 
    }

	getCustomList(){
        this.getCustomByMM();
	}

	getCustomByMM(): void {
       this.customerCountryService.getCountryData().then(result => this.customermm = result)
        .catch(error => console.log(error));
    }

    getCountryByMM(): void {
       this.customerCountryService.customerCountryData().then(result => this.countrymm = result)
        .catch(error => console.log(error));
    }
   
}

@Injectable() export class CustomerDialogService {

    constructor(private modalService: NgbModal) { }

    public show() {
        const modalRef = this.modalService.open(CustomerLocationPopupComponent);
        modalRef.componentInstance.name = "showCustomerlg";
		modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }
}
