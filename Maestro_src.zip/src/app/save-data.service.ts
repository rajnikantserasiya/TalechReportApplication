import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import {Http, Response, Headers, RequestOptions} from "@angular/http";
import {Observable} from "rxjs/Rx";

@Injectable()
export class SaveDataService {

  constructor(private http : Http){}
  
  fetchData(){
    let customer:string='{"ListMaestroSessionMetadata":[{"UserId":"Test","SessionId":"Session","CurrentDate":"2017-11-13T14:47:21.4675082+05:30","ItemId":"Item"},{"UserId":"Test","SessionId":"Session1","CurrentDate":"2017-11-13T15:47:21.929521+05:30","ItemId":"Item1"}]}';
    let body = JSON.stringify(customer);
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: headers });
  }
  
  success(){
    return "success";
  }
}

