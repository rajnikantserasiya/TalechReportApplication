import { Component, OnInit, ElementRef, ViewEncapsulation, ViewChild} from '@angular/core';
import { JsonPipe } from '@angular/common';
import { TreeModule, TreeNode, TreeTableModule, DataTableModule } from 'primeng/primeng';
import { TableModule  } from 'primeng/table';
import { filter } from 'rxjs/operators';
import { EqSelectedList } from '../services/eq-exclusions-class';
import { EqPreviewList } from '../services/eq-exclusions-class';
import { EqExclusionsServiceService } from '../services/eq-exclusions-service.service';
import { EqSelectedPreviewList } from '../services/eq-exclusions-class';
import { SelectEquipmentMasterService } from './../services/select-equipment-master.service';
import { PaginationPipe } from '../pipes/pagination.pipe';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { AppConstant } from './../app.constant';
import { DataService } from './../services/data-component.service';
import { CommonUtil }  from './../common/common-util';
import { DropdownModule } from 'primeng/dropdown';
import { AdvancedSearchService } from './../services/advanced-search.service';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { ConfirmationService } from 'primeng/api';
import {SelectItem} from './../new-user-mapping/api';

declare var jquery: any;
declare var $: any;

@Component({
    selector: 'app-preview',
    templateUrl: './preview.component.html',
    styleUrls: ['./preview.component.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [SelectEquipmentMasterService, ConfirmationService]
})
export class PreviewComponent implements OnInit {

    //  @ViewChild('dataTable') dataTable: TableModule;

    searchboxText = "Search";
    eqInclHeadText = "Inc?";
    eqHeadText = "Equip";
    classHeadText = "Maestro Item Type";
    sectionHeadText = "Section";
    itemnumHeadText = "Item No";
    itemdescHeadText = "Item Desc";
    commcodeHeadText = "Comm Code";
    bomqtyHeadText = "BOM Qty";
    actusgHeadText = "Actual Usg";
    adjlifehrsHeadText = "Adj Life Hrs";
    itcostHeadText = "Item Price";
    paridhrsHeadText = "Parent Item Id";
    resetbtnText = "Reset";
    resetFilter: boolean = false;
    toggleChecked: boolean = false;
    skipAdditionalOnSortCall = false;

    dataTable: any;
    firstPage: number;

    cols = [
        { field: 'IsInclude', header: 'Inc?', width: '3%' },
        { field: 'REC', header: 'REC', width: '3%' },
        { field: 'SectionId', header: 'Parent Item Id', width: '7%' },
        { field: 'Section', header: 'Section', width: '17%' },
        { field: 'Item', header: 'Item No', width: '8%' },
        { field: 'Description', header: 'Item Desc', width: '17%' },
        { field: 'Qty', header: 'BOM Qty', width: '5%' },
        { field: 'LifetimeHours', header: 'Adj Life Hrs', width: '7%' },
        { field: 'UnitPrice', header: 'Item Price', width: '7%' },
        { field: 'PercHrsType', header: 'Per', width: '3%' },
        { field: 'CompHrsType', header: 'Com', width: '3%' },
        { field: 'EngHrsType', header: 'Eng', width: '3%' },
        { field: 'HydHrsType', header: 'HYD', width: '3%' },
        { field: 'LHPowerHrsType', header: 'LH', width: '2%' },       
        { field: 'ItemClass', header: 'Maestro Item Type', width: '6%' },
        { field: 'PART_TYPE', header: 'Sandvik Item Type', width: '6%' }
    ];

    pagingConfig = { "startIndex": 1, "endIndex": 5, "itemsPerPage": 10, "action": "refresh" };

    PriceListPriceType = "";
    totalCount: number = 0;

    equippreview: EqPreviewList[] = [];
    selectedEquipment: EqSelectedList[];
    eqSelectedPreviewList: EqSelectedPreviewList[] = [];

    equippreviewOriginal: any = [];

    Equipment: any;

    strEquipment = "Select equipment";

    loadFlag = false;
    nodes: TreeNode[] = [];
    exclusionDataForEquipment: any = [];

    searchText: string = "";
    beforeEditStart: any = "";
    onEditcomplete: any = "";
    noRecordFound: boolean = false;
    datasource: any = [];
    totalRecords: number = 0;
    first: number = 0;
    rerender = true;
    loading: boolean;

    selectedItems: any = [];
    dt: any;
    sortOrder: number = 1;
    sortField: string = "";

    excludeRangeObj: any = { 'startRange': 0, 'endRange': 0 };
    filterModifiedFlag: boolean = false;
    paginationEmpty: boolean = false;

    MaestroItemTypeListItems: any = [];
    strSelectedMaestroItemType: string = '';

    constructor(private eRef: ElementRef, private eqExclusionsServiceService: EqExclusionsServiceService, private selectEquipmentMasterService: SelectEquipmentMasterService, private fetchCurrentDataService: FetchCurrentDataService, private appConstant: AppConstant, private dataService: DataService, private commonUtil: CommonUtil, private advancedSearchService: AdvancedSearchService, private confirmationService: ConfirmationService, private tableModule: TableModule) {
        this.fetchCurrentDataService.screenDataStream$.subscribe(
            () => {
                if (!this.fetchCurrentDataService.disableFlagSavePreview) {

                    var selectedEquipment = this.dataService.getPreviewSelected() || "";
                    this.fetchCurrentDataService.disableFlagSavePreview = true;
                    if (this.dataService.getPreviewSelectedEquipment().length > 0) {
                        var filterdata = this.dataService.getPreviewList(selectedEquipment, false);
                        if (filterdata.length > 0) {
                            var filters = this.dataService.getData('activeFilters') || [];
                            this.fetchCurrentDataService.createJsonToSave(filterdata[0]["filterValue"], this.appConstant.previewRoot);
                            this.fetchCurrentDataService.createJsonToSave(selectedEquipment, this.appConstant.previewSelected);
                            this.fetchCurrentDataService.createJsonToSave(filters, this.appConstant.activeFilters);
                        }
                    }
                }
            });

        this.dataService.previewTabCachingStream$.subscribe(
            () => {

            });

        this.fetchCurrentDataService.refreshScreenStream$.subscribe(
            () => {
                if (!this.fetchCurrentDataService.reloadFlagPreview) {
                    this.fetchCurrentDataService.reloadFlagPreview = true;
                    this.datasource = [];
                    this.totalCount = 0;
                    this.selectedEquipment = [];
                    this.equippreview = [];
                    this.eqSelectedPreviewList = [];
                    this.filterModifiedFlag = false;
                    this.ngOnInit();
                }
            });
    }

    setData(selectedEquipment) {
    }

    ngOnInit() {
        setTimeout(() => {
            var countryList = [];
            var CountryCode;
            this.dataService.setSkipTabChange(false, 'all');
            this.loading = true;
            var price = this.dataService.getOptionsPriceType();
            var country;
            if (!price || price.length == 0) {
                price = 'GLP';
            }
            countryList = this.dataService.getData('optionsCountryList');
            if (countryList.length > 0) {
                if (price === 'GLP') {
                    var selectedValue = this.dataService.getOptions('glpDropdown');
                    CountryCode = selectedValue.split('-')[1];
                }
                else {
                    var selectedValue = this.dataService.getOptions('maplDropdown');
                    CountryCode = selectedValue.split('-')[1];
                }
            }
            country = this.dataService.getCountryFromCode(CountryCode);
            this.PriceListPriceType = "Price: " + price + "/" + country;
            this.getSelectedEquipmentList();
        }, 2000);

    }

    getSelectedEquipmentList(): void {
        if (this.dataService.getData('selectedEquipment').length > 0) {
            var result = this.dataService.getData('selectedEquipment');
            this.getEquipmentSelectedList(result);
        } else {
            this.selectEquipmentMasterService.selectedEquipmentMaster()
                .then(result => {
                    this.getEquipmentSelectedList(result)
                })
                .catch(error => console.log(error));
        }
    }

    getMaestroItemTypelist() {
        this.MaestroItemTypeListItems = [];
        let arrMaestroItemType = this.equippreviewOriginal.map(item => item.ItemClass).filter((value, index, self) => self.indexOf(value) === index)

        //arrMaestroItemType.foreach
        arrMaestroItemType.forEach(item => {
            if (item.trim() != "" && item.trim() != null) {
                var obj = {
                    "label": item.trim(), "value": item.trim()
                }
                this.MaestroItemTypeListItems.push(obj);
            }
        });

        return this.MaestroItemTypeListItems;
        //this.MaestroItemTypeListItems = arrMaestroItemType.filter(item => {
        //    if (item.trim() != "" && item.trim() != null) {
        //        //return item.trim();
        //        var obj =
        //            {
        //                "label": item.trim(), "value": item.trim()
        //            };

        //        return obj;
        //    }
        //});
    }

    VisiblePagingSection() {
        return this.totalRecords > 200 ? true : false
    }

    getEquipmentSelectedList(result) {
        this.selectedEquipment = result;
        let previewDropdownSelected: string = "";
        let intInc: number = 0;
        previewDropdownSelected = this.dataService.getPreviewSelected();

        for (let entry of this.selectedEquipment) {
            let strEquipment: string = "";
            intInc = intInc + 1;
            if (entry["EqSourceType"] == "1") {
                strEquipment = entry["Model"] + ' SN:' + entry["SerialNo"];
            };
            if (entry["EqSourceType"] == "2") {
                strEquipment = entry["Model"] + ' SN:' + entry["SerialNo"];
            }
            if (entry["EqSourceType"] == "3") {
                strEquipment = entry["Model"] + ' SN:' + entry["SerialNo"] + "_Other";
            }
            let newName = {
                Id: intInc.toString(),
                Equipment: strEquipment,
                EqSourceType: entry["EqSourceType"].toString(),
                SerialNo: entry["SerialNo"].toString(),
                Model: entry["Model"].toString(),
                UserName: entry["UserName"].toString(),
                Quantity: entry["Quantity"]
            };
            this.eqSelectedPreviewList.push(newName);
        }
        if (previewDropdownSelected.length > 0) {
            var filteredValue = this.eqSelectedPreviewList.filter(item => {
                return item['Equipment'] === previewDropdownSelected;
            });
            if (filteredValue.length > 0) {
                this.dataService.setPreviewSelectedEquipment(filteredValue[0]['Id']);
            }
            //console.log('selected equip set to' + filteredValue[0]);
        }
        if (this.dataService.getPreviewSelectedEquipment().length > 0) {
            this.strEquipment = this.dataService.getPreviewSelectedEquipment();
            this.getSelectedEquipment(this.strEquipment);
        }
    }


    getSelectedEquipment(Equipment): void {

        document.getElementById("slide-nav").style.width = "0";
        if (Equipment != 'Select equipment') {
            this.loadFlag = true;
            this.dataService.setPreviewSelectedEquipment(Equipment);
            for (let entry of this.eqSelectedPreviewList.filter(s => s.Id == Equipment)) {
                let strModel: string = "";
                let strSerialNo: string = "";

                if (entry["EqSourceType"] == "1") {
                    strSerialNo = entry["SerialNo"];
                };
                if (entry["EqSourceType"] == "2") {
                    strModel = entry["Model"];
                }
                if (entry["EqSourceType"] == "3") {
                    strModel = entry["Model"];
                    strSerialNo = entry["SerialNo"];
                }

                let newSalectedEQ = [{
                    SerialNo: strSerialNo,
                    Model: strModel,
                    EqSourceType: entry["EqSourceType"].toString(),
                    UserName: entry["UserName"].toString(),
                    Quantity: "",
                    HourFrom: "",
                    HourTo: "",
                    MODELCATEGORY: "",
                    EQ_LIFE: "",
                    HR_TYPE: "",
                    quant: entry["Quantity"],
                    serNo: entry["SerialNo"],
                    mod: entry["Model"],
                    id: entry["Model"] + ' SN:' + entry["SerialNo"] + "_" + entry["EqSourceType"].toString()
                }];
                let objEqSelected: EqSelectedList = JSON.parse(JSON.stringify(newSalectedEQ));
                var filterdata = this.dataService.getPreviewList(objEqSelected[0]['id'], false);
                if (filterdata.length > 0 && filterdata[0]["filterValue"].length > 0) {
                    this.handlePreviewOutput(JSON.parse(JSON.stringify(filterdata[0].filterValue)), objEqSelected, true);
                } else {
                    var priceType = this.dataService.getOptionsPriceType();
                    var priceList = this.dataService.getActivePriceList();
                    this.eqExclusionsServiceService.selectedPreviewEquipment(objEqSelected, priceType, priceList)
                        .then(result => {
                            this.handlePreviewOutput(result, objEqSelected, false);
                        }
                        )
                        .catch(error => console.log(error));
                }
            }
        } else {
            this.rerender = false;
            this.equippreview = [];
            this.equippreviewOriginal = [];
            this.totalCount = 0;
            this.noRecordFound = false;
            this.datasource = this.equippreview;
            this.totalRecords = this.equippreview.length;
            setTimeout(() => {
                this.rerender = true;
                this.loading = true;
                this.forcefulUpdatePage();
            }, 0);
        }
    }


    handlePreviewOutput(result, objEqSelected, isCachedData) {
        this.rerender = false;
        this.rerender = true;
        result.forEach(item => {
            //item['isHidden'] = false;
            item['isModified'] = false;
        });
        this.searchText = "";
        this.noRecordFound = result.length > 0;
        this.equippreview = result;
        //this.validateWithExclusionData(objEqSelected);
        this.datasource = this.equippreview;
        //this.equippreview = this.datasource.slice(0, 20);
        //this.totalRecords = result.length;
        this.equippreviewOriginal = JSON.parse(JSON.stringify(result));
        var filterdata = this.dataService.getPreviewList(objEqSelected[0]["id"], false);
        if (!isCachedData) {
            try {
                var obj = { "filterName": objEqSelected[0]["id"], "filterValue": this.equippreviewOriginal };
                this.dataService.setPreviewSelected(objEqSelected[0]["id"]);
                this.dataService.setPreviewList(obj);
            } catch (e) {
            }
        }

        // bind Maestro item type dropdown list
        this.getMaestroItemTypelist();
        this.strSelectedMaestroItemType = "";

        // this.totalCount = this.equippreview.length;
        // this.filterAllData(true);
        this.rearrangeRecords({ 'field': 'Qty' });
        this.loadFlag = false;
    }

    validateWithExclusionData(newSalectedEQ) {
        var label = newSalectedEQ[0]["mod"] + ' SN :' + newSalectedEQ[0]["serNo"] + ' (' + newSalectedEQ[0]["quant"] + ')';
        var filterdata = this.dataService.getEqExclusionsMaster(label.trim(), false);
        if (filterdata.length > 0 && filterdata[0]["filterValue"].length > 0) {
            this.exclusionDataForEquipment = [];
            filterdata[0]["filterValue"].forEach(element => {
                this.getExclusionDataInList(element, false);
            });
            this.equippreview.forEach(item => {
                var val: any = false;
                var matchCount: number = -1;
                this.exclusionDataForEquipment.forEach(itemExclusion => {
                    var value: any = true;
                    if (item["pth"] === itemExclusion["Path"]) {
                        matchCount += 1;
                        value = itemExclusion["IsInclude"] === "True" ? true : false;
                        item["IsInclude"] = value;
                        //console.log("Excluded for" + itemExclusion);
                    }
                })
                if (matchCount == -1) {
                    item["IsInclude"] = val;
                }
            });
        }
    }

    getExclusionDataInList(parent, flag) {
        var that = this;
        if (parent && parent.children) {
            if (parent["IsInclude"] && parent["IsInclude"] === "True") {
                this.insertWithoutDuplicates(parent);
            }
            for (var i = 0, l = parent.children.length; i < l; ++i) {
                var child = parent.children[i];
                var temp = {};
                child.index = i;
                if (child["IsInclude"] && child["IsInclude"] === "True") {
                    this.insertWithoutDuplicates(child);
                }
                this.getExclusionDataInList(child, flag);
            }
        }
    }

    insertWithoutDuplicates(node) {
        var temp: any = [];
        var filteredTemp = this.exclusionDataForEquipment.filter(s => {
            return s["Path"] === node["Path"];
        });
        if (filteredTemp.length >= 1) {
            this.exclusionDataForEquipment = this.exclusionDataForEquipment.filter(s => {
                return s["Path"] != node["Path"];
            });
        }
        temp = {
            "Path": node["Path"], "Qty": node["Qty"], "Description": node["Description"], "Equipment": node["Equipment"],
            "IsInclude": node["IsInclude"], "Item": node["Item"], "LifetimeHours": node["LifetimeHours"], "SectionId": node["SectionId"]
        };
        this.exclusionDataForEquipment.push(temp);
    }

    onOkUpdatePreviewClicked(equippreview: any, tabReloadFlag: boolean): any {

        var filters = this.dataService.getData('activeFilters') || [];
        this.dataService.setTabModified('tab-preview', false);
        this.dataService.setSkipTabChange(false, 'tab-preview');
        this.eqExclusionsServiceService.saveMaestroPreviewData(equippreview, filters).then(
            result => {
                this.dataService.setTabModified('tab-preview', false);
                this.dataService.setSkipTabChange(false, 'all');
                if (tabReloadFlag) {
                    var prevSelected = this.dataService.getPreviewSelectedEquipment();
                    this.dataService.clearReferenceForList(false);
                    this.dataService.setPreviewSelectedEquipment(prevSelected);
                    this.filterModifiedFlag = false;
                    document.getElementById('reload_tab').click();
                }
            })
            .catch(error => console.log(error));
    }

    onBlurMethod(data, field) {
    }

    onModelChange(value, data, field, tableInstance) {
        try {
            this.dataTable = tableInstance;
            this.firstPage = tableInstance.first;
            var path = data['pth'].split(':');
            var initialValue = 0;
            var id: string = field;
            path.forEach(item => {
                item = item.replace(/\s/g, '');
                item = item.replace('/', '')
                id = id.concat('X' + item.trim());
            });
            var ngNativeEl = this.eRef.nativeElement.querySelector('#' + id);
        } catch (e) {
            console.log(e);
        }
        if (value) {
            switch (field) {
                case 'Qty':
                    var maxLength = 7;
                    if (value.indexOf('.') > 0) {
                        maxLength = 10;
                    }
                    if (this.commonUtil.checkSpecialRegex(value, true, false) || value.length > 6) {
                        value = data[field];
                        ngNativeEl.value = data[field];
                    } else {
                        initialValue = JSON.parse(JSON.stringify(value));
                        data[field] = value;
                        this.updatePrimaryDataSource(field, value, data['pth']);
                        this.dataService.setTabModified('tab-preview', true);
                    }
                    break;

                case 'LifetimeHours':
                    var maxLength = 7;
                    if (value.indexOf('.') > 0) {
                        maxLength = 10;
                    }
                    if (this.commonUtil.checkSpecialRegex(value, true, false) || value.length > 10) {
                        value = data[field];
                        ngNativeEl.value = data[field];
                    } else {
                        initialValue = JSON.parse(JSON.stringify(data[field]));
                        data[field] = value;
                        this.updatePrimaryDataSource(field, value, data['pth']);
                        this.dataService.setTabModified('tab-preview', true);
                    }
                    //if (data[field] == 0 && data['UnitPrice'] == 0) {
                    //    this.loadFlag = true;
                    //    this.showConfirmationDialog(data, initialValue, 'LifetimeHours', tableInstance);
                    //}
                    break;

                case 'UnitPrice':
                    var maxLength = 7;
                    if (value.indexOf('.') > 0) {
                        maxLength = 10;
                    }
                    if (this.commonUtil.checkSpecialRegex(value, true, false) || value.length > 10) {
                        value = data[field];
                        ngNativeEl.value = data[field];
                    } else {
                        initialValue = JSON.parse(JSON.stringify(value));
                        data[field] = value;
                        this.updatePrimaryDataSource(field, value, data['pth']);
                        this.dataService.setTabModified('tab-preview', true);
                    }
                    //if (data['LifetimeHours'] == 0 && data['UnitPrice'] == 0) {
                    //    this.loadFlag = true;
                    //    this.showConfirmationDialog(data, initialValue, 'UnitPrice', tableInstance);
                    //}
                    //if (data['UnitPrice'] == '') {
                    //    this.loadFlag = true;
                    //    this.showConfirmationDialog(data, initialValue, 'UnitPrice', tableInstance);
                    //}
                    break;
            }
        } else {
            data[field] = value;
        }
    }


    showConfirmationDialog(data, initialValue, field, tableInstance) {
        var indexOriginalRecord = [];
        var indexCurrentRecord = [];
        this.confirmationService.confirm({
            message: 'This record will not be consider for further analysis. Do you want to continue ?',
            header: 'Confirmation',
            icon: 'pi pi-exclamation-triangle',
            accept: () => {
                this.forcefulUpdatePage();
                data['isHidden'] = true;
                for (var i = 0; i < this.equippreviewOriginal.length; i++) {
                    if (this.equippreviewOriginal[i]['pth'] === data['pth']) {
                        //shift the position of the record in both the array
                        this.equippreviewOriginal[i]['isHidden'] = true;
                        indexOriginalRecord.push(i);
                    }
                }
                for (var i = 0; i < this.equippreview.length; i++) {
                    if (this.equippreview[i]['pth'] === data['pth']) {
                        //shift the position of the record in both the array
                        this.equippreview[i]['isHidden'] = true;
                        indexCurrentRecord.push(i);
                    }
                }
                indexOriginalRecord.forEach(item => {
                    var item = this.equippreviewOriginal.splice(i, 1);
                    this.equippreviewOriginal.push(item);
                });
                indexCurrentRecord.forEach(item => {
                    var item = this.equippreviewOriginal.splice(i, 1);
                    this.equippreview.push(item);
                });
                this.totalRecords = this.equippreview.length - this.getTotalCountForHiddenRecords();
                this.loadFlag = false;
                this.reloadScreen(true, tableInstance);
            },
            reject: () => {
                data[field] = initialValue;
                this.loadFlag = false;
            }
        });
    }


    reloadScreen(setPage: boolean, tableInstance: any) {
        this.rerender = false;
        this.loadFlag = true;
        setTimeout(() => {
            this.rerender = true;
            this.totalRecords = this.equippreview.length - this.getTotalCountForHiddenRecords();
            if (setPage) {
                //tableInstance.first = this.firstPage;                          
            }
            this.loadFlag = false;
        }, 100);
    }

    refreshData(configData): void {
        document.getElementById("slide-nav").style.width = "0";
        //console.log("Recieved Data from  paging component" + JSON.stringify(configData));
        this.pagingConfig = configData;
    }

    onSearchTextChange(value, strSelectedMaestroItemType): void {

        debugger;
        document.getElementById("slide-nav").style.width = "0";
        if (value.length >= 3 ||
            (strSelectedMaestroItemType != "" && strSelectedMaestroItemType != null && strSelectedMaestroItemType != "Select Maestro Item Type")) {
            this.searchText = value;
            //this.pagingConfig["searchText"] = value;
            //this.pagingConfig["strSelectedMaestroItemType"] = strSelectedMaestroItemType.trim();
            this.equippreview = JSON.parse(JSON.stringify(this.equippreviewOriginal));
            let that = this;
            this.equippreview = this.equippreview.filter(it => {
                if (typeof value === "string" && value) {
                    value = value.trim().toUpperCase();
                }
                if (typeof strSelectedMaestroItemType === "string" && strSelectedMaestroItemType) {
                    strSelectedMaestroItemType = strSelectedMaestroItemType.trim().toUpperCase();
                }

                if ((value == "" || value == null || (value && value.length < 3)) &&
                    (strSelectedMaestroItemType != "" && strSelectedMaestroItemType != null && strSelectedMaestroItemType != "SELECT MAESTRO ITEM TYPE")) {

                    return (this.getItemTypeBasedOnMultiSelection(it, strSelectedMaestroItemType));
                    //return (it["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType));
                }
                else if ((value != "" || value != null && value.length >= 3) &&
                    (strSelectedMaestroItemType == "" || strSelectedMaestroItemType == null || strSelectedMaestroItemType == "SELECT MAESTRO ITEM TYPE")) {

                    return (it['Description'] && it["Description"].trim().toUpperCase().includes(value) || it["Section"].toUpperCase().includes(value) || it["ModelCategory"].toUpperCase().includes(value) || it["Item"].includes(value) || it["SectionId"].toUpperCase().includes(value));
                }
                else if ((value != "" || value != null && value.length >= 3) &&
                    (strSelectedMaestroItemType != "" && strSelectedMaestroItemType != null && strSelectedMaestroItemType != "SELECT MAESTRO ITEM TYPE")) {

                    return (it['Description'] && it["Description"].trim().toUpperCase().includes(value) || it["Section"].toUpperCase().includes(value) || it["ModelCategory"].toUpperCase().includes(value) || it["Item"].includes(value) || it["SectionId"].toUpperCase().includes(value))
                        &&
                        (this.getItemTypeBasedOnMultiSelection(it, strSelectedMaestroItemType));
                    //(it["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType));
                }

            });
            /*var indexCurrentRecord =[];    
            for(var i = 0; i < this.equippreview.length; i++) {                                
                if(this.equippreview[i]['isHidden']) {                              
                    indexCurrentRecord.push({'index':i , 'item': this.equippreview[i]});                     
                }
            }            
            indexCurrentRecord.forEach( item => {
                var item =  this.equippreviewOriginal.splice(item['index'],1);
                this.equippreview.push(item);
            });*/
            this.totalCount = this.equippreview.length;
            this.pagingConfig = { "startIndex": 1, "endIndex": 5, "itemsPerPage": 10, "action": "refresh" };
            this.datasource = this.equippreview;
            this.totalRecords = this.equippreview.length;
        } else {
            //if ((value == "" || value == null || (value && value.length < 3))
            //&& (strSelectedMaestroItemType == "" || strSelectedMaestroItemType == null || strSelectedMaestroItemType == "Select Maestro Item Type"))
            this.equippreview = JSON.parse(JSON.stringify(this.equippreviewOriginal));
            this.totalCount = this.equippreview.length;
            this.pagingConfig = { "startIndex": 1, "endIndex": 5, "itemsPerPage": 10, "action": "refresh" };
            this.datasource = this.equippreview;
            this.totalRecords = this.equippreviewOriginal.length;
            this.rearrangeRecords({ 'field': 'Qty' });

        }

        //jquery chaining
        $("p-sorticon span").removeClass('fa-sort-asc').removeClass('fa-sort-desc');
    }

    getItemTypeBasedOnMultiSelection(items, strSelectedMaestroItemType) {

        if (strSelectedMaestroItemType.length == 1) {
            return items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[0]);
        }
        else if (strSelectedMaestroItemType.length == 2) {
            return items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[0]) || items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[1]);
        }
        else if (strSelectedMaestroItemType.length == 3) {
            return items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[0]) || items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[1]) ||
                items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[2]);
        }
        else if (strSelectedMaestroItemType.length == 4) {
            return items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[0]) || items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[1]) ||
                items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[2]) || items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[3]);
        }
        else if (strSelectedMaestroItemType.length == 5) {
            return items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[0]) || items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[1]) ||
                items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[2]) || items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[3])
                || items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[4]);
        }
        else if (strSelectedMaestroItemType.length == 6) {
            return items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[0]) || items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[1]) ||
                items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[2]) || items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[3]) ||
                items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[4]) || items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[5]);
        }

        ////debugger;
        //var strItemClassQuery = "";//items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType);
        //for (let i = 0; i < strSelectedMaestroItemType.length; i++) {
        //    if (strSelectedMaestroItemType.length == 1 || i == strSelectedMaestroItemType.length - 1) {
        //        strItemClassQuery += items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[i]);
        //    }
        //    else {
        //        strItemClassQuery = items["ItemClass"].trim().toUpperCase().includes(strSelectedMaestroItemType[i]) + " || ";
        //    }
        //}
        //return strItemClassQuery;
    }

    getPreviewEq(Equipment: EqSelectedList): void {
        let strEquipment: string = "";
        if (Equipment[0]["EqSourceType"] == "1") {
            strEquipment = Equipment[0]["SerialNo"];
        }
        if (Equipment[0]["EqSourceType"] == "2") {
            strEquipment = Equipment[0]["Model"];
        }
        if (Equipment[0]["EqSourceType"] == "3") {
            strEquipment = Equipment[0]["Model"] + " SN " + Equipment[0]["SerialNo"];
        }
    }

    highlightQty(equip): boolean {
        return (equip['Qty'] == 0 || equip['Qty'] == undefined);
    }

    highlightLifetimeHours(equip): boolean {
        return (equip['LifetimeHours'] == 0 || equip['LifetimeHours'] == undefined);
    }

    highlightUnitPrice(equip): boolean {
        return (equip['UnitPrice'] == 0 || equip['UnitPrice'] == undefined);
    }

    getStyle(event, value, field, data) {
        try {
            var path = data['pth'].split(':');
            var id: string = field;
            path.forEach(item => {
                id = id.concat('X' + item.trim());
            });
            var ngNativeEl = this.eRef.nativeElement.querySelector('#' + id);
        } catch (e) {
            console.log(e);
        }
        if (ngNativeEl) {
            if (data[field] == 0 || data[field] == "" || !data[field]) {
                ngNativeEl.style.backgroundColor = "#ff9e9e";
                ngNativeEl.style.width = "80%";
                ngNativeEl.value = value;
            }
            else {
                ngNativeEl.style.backgroundColor = "transparent";
                ngNativeEl.style.width = "80%";
                ngNativeEl.value = value;
            }
        }
        return "";
    }

    loadData(event: any) {
        this.loading = true;
        /* setTimeout( () => {
           this.equippreview = JSON.parse(JSON.stringify(this.datasource.slice(event.first, (event.first + event.rows))));      
           this.loading = false;
         },10);  */
    }

    resetDataTable(dt) {
        console.log('reset');
        dt.reset();
    }

    resetPreviewDataTable(Equipment) {

        var selPrev = this.dataService.getPreviewSelected();
        if (selPrev.length > 0) {
            var strEquipment = this.dataService.getPreviewSelected();
            var obj = { "filterName": strEquipment, "filterValue": [] };
            this.dataService.setPreviewList(obj);
            var filteredValue = this.eqSelectedPreviewList.filter(item => {
                var label = item["Model"] + ' SN:' + item["SerialNo"];
                // append "_" + item["EqSourceType"].toString() because in id field we are set model + SN +'_' + EqSourceType
                return label + "_" + item["EqSourceType"].toString() === strEquipment;
            });
            if (filteredValue.length > 0) {
                this.dataService.setTabModified('tab-preview', false);
                this.dataService.setSkipTabChange(false, 'tab-preview');
                this.getSelectedEquipment(filteredValue[0]['Id']);
                //reset in preview screen issue changes
                if (this.resetFilter) {
                    this.resetFilter = false;
                }
                else {
                    this.resetFilter = true;
                }
            }

            // add this 2 lines to set Enable Exclude button disable and initialise start range and end range
            this.toggleChecked = false;
            this.excludeRangeObj.startRange = this.excludeRangeObj.endRange = 0;
        }
    }

    getDynamicId(str, data) {
        var path = data['pth'].split(':');
        var id: string = str;
        path.forEach(item => {
            item = item.replace(/\s/g, '');
            item = item.replace('/', '')
            id = id.concat('X' + item.trim());
        });

        //id = id.replace('/', '');
        return id;
    }

    ngModelCheckBoxChange(value, field, rowData) {
        if (!value && this.toggleChecked) {
            if (this.excludeRangeObj.startRange == 0) {
                this.excludeRangeObj.startRange = rowData;
            } else {
                this.excludeRangeObj.endRange = rowData;
            }
        }
        rowData[field] = value;
        this.dataService.setTabModified('tab-preview', true);
        this.updatePrimaryDataSource(field, value, rowData['pth']);
    }

    updatePrimaryDataSource(field, value, key) {
        this.datasource.forEach(item => {

            if (item["pth"] === key) {
                item[field] = value;
                item['isModified'] = true;
            }
        });

        this.dataService.updatePreviewListValue(field, value, key);
    }

    updateCacheDataWithCurrent() {
        if (this.datasource.length > 0 && this.dataService.getPreviewSelected().length > 0) {
            var obj = { "filterName": this.dataService.getPreviewSelected(), "filterValue": this.datasource };
            this.dataService.setPreviewList(obj);
        }
    }

    savePreviewData(str) {

        var selectedEquipment = this.dataService.getPreviewSelected() || "";
        //this.fetchCurrentDataService.disableFlagSavePreview = true;
        //todo
        var filters = this.dataService.getData('activeFilters') || [];
        if (this.dataService.getPreviewSelectedEquipment().length > 0) {
            var filterdata = this.dataService.getPreviewList(selectedEquipment, false);
            if (filterdata.length > 0) {
                if (str === "manual") {
                    // need to set flag to true in case we need to reload the screen.
                    this.onOkUpdatePreviewClicked(filterdata[0]["filterValue"], true);
                } else {
                    this.onOkUpdatePreviewClicked(filterdata[0]["filterValue"], false);
                }
            }
        }
    }

    validateSave() {
        var flag = !this.dataService.getTabModified('tab-preview') || this.equippreview.length <= 0;
        if (this.filterModifiedFlag) {
            return false;
        } else {
            return flag;
        }

    }

    getDynamicWidth(col) {
        //console.log(col.width);
        //return { 'background-color': col.width };
        return col.width;
    }

    filterData(filters) {
        this.filterModifiedFlag = true;
        if (filters['type'] && filters['type'] === 'all') {
            this.filterAllData(false);
        } else {
            this.loadFlag = true;
            setTimeout(() => {
                this.equippreview.forEach(item => {
                    if (filters['activeFilter']['IsActive'] && filters['activeFilter']['Family_Code'].indexOf(item['CommCode']) >= 0) {
                        if (!this.validateMasterRules(filters, item)) {
                            this.includeExcludeItem('include', item);
                        }
                    } else if (!filters['activeFilter']['IsActive'] && filters['activeFilter']['Family_Code'].indexOf(item['CommCode']) >= 0) {
                        if (!this.validateMasterRules(filters, item)) {
                            this.includeExcludeItem('exclude', item);
                        }
                    }
                });
                this.loadFlag = false
            }, 1000);
        }
    }

    includeExcludeItem(action, item) {
        if (action === 'include') {
            var value: any = true;
            if (!item['IsInclude']) {
                this.dataService.setTabModified('tab-preview', true);
            }
            item['isModified'] = true;
            item['IsInclude'] = value;
            this.updatePrimaryDataSource('IsInclude', value, item['pth']);
        } else {
            var value: any = false;
            if (item['IsInclude']) {
                this.dataService.setTabModified('tab-preview', true);
            }
            item['isModified'] = false;
            item['IsInclude'] = value;
            this.updatePrimaryDataSource('IsInclude', value, item['pth']);
        }
    }

    filterAllData(skipModify) {
        var activeFilters = this.dataService.getData('activeFilters') || [];
        this.loadFlag = true;
        setTimeout(() => {
            this.equippreview.forEach(item => {
                var count = { 'isChecked': 0, 'isUnchecked': 0 };
                activeFilters.forEach(filter => {
                    if (filter['IsActive'] && filter['Family_Code'].indexOf(item['CommCode']) >= 0) {
                        if (!this.validateMasterRules(filter, item)) {
                            this.includeExcludeItem('include', item);
                        }
                        count.isChecked++;
                    } else if (!filter['IsActive'] && filter['Family_Code'].indexOf(item['CommCode']) >= 0) {
                        if (!this.validateMasterRules(filter, item)) {
                            this.includeExcludeItem('exclude', item);
                        }
                        count.isUnchecked++;
                    }
                });
                if (count.isChecked > 0 && count.isUnchecked > 0) {
                    this.includeExcludeItem('exclude', item);
                }
            });
            this.loadFlag = false;
        }, 1000);
    }

    validateMasterRules(filter, item) {


        var flag = false;

        //Added below obj as method called either from select All or single item checkbox
        var filterObj = null;
        if (filter.activeFilter) {
            filterObj = filter.activeFilter
        }
        else {
            filterObj = filter;
        }

        //WHERE ((Not ((NFW_definitions_180516.Family_Code) Like "*4412*" Or (NFW_definitions_180516.Family_Code) Like "*4307*")) AND ((NFW_definitions_180516.NFW_Group)="HOSES") AND (Not ((ITEM_MASTER.DESC_ENG) Like "*REFRIGE*" Or (ITEM_MASTER.DESC_ENG) Like "*fuel*")));
        if (!(filterObj.Family_Code.indexOf('4412') >= 0 || filterObj.Family_Code.indexOf('4307') >= 0) && filterObj.NFWGroupName === 'HOSES' && (item['Description'].indexOf('REFRIGE') >= 0 || item['Description'].indexOf('fuel') >= 0)) {
            flag = true;
        }
        //WHERE (((NFW_definitions_180516.NFW_Group) Like "*WINDOWS*") AND (Not ((ITEM_MASTER.DESC_ENG) Like "*LATH*" Or (ITEM_MASTER.DESC_ENG) Like "*SHADE*")));
        else if ((filterObj.NFWGroupName === 'WINDOWS') && ((item['Description'].indexOf('LATH') >= 0 || item['Description'].indexOf('SHADE') >= 0))) {
            flag = true;
        }
        //wHERE (((NFW_definitions_180516.NFW_Group) Like "*FENDERS*") AND (Not ((ITEM_MASTER.DESC_ENG) Like "*RUBBER*" And (ITEM_MASTER.DESC_ENG) Like "*MOUNT*")));
        else if ((filterObj.NFWGroupName === 'FENDERS') && ((item['Description'].indexOf('RUBBER') >= 0 || item['Description'].indexOf('MOUNT') >= 0))) {
            flag = true;
        }
        //wHERE (((NFW_definitions_180516.Family_Code) Not Like "*P8088*") AND ((NFW_definitions_180516.NFW_Group) Like "*GRILLS*")); 
        else if (filterObj.Family_Code.indexOf('P8088') < 0 && filterObj.NFWGroupName === 'GRILLS') {
            flag = true;
        }

        return flag;
    }

    excludeItems() {
        if (this.toggleChecked) {
            if (this.excludeRangeObj.startRange == 0 || this.excludeRangeObj.endRange == 0) {
                //Exclude items issue changes
                this.toggleChecked = false;
                this.excludeRangeObj.startRange = this.excludeRangeObj.endRange = 0;

                alert('select a valid range');
            } else {
                var flag = false;
                var count = 0;
                for (var i = 0; i < this.equippreview.length; i++) {
                    if (this.excludeRangeObj.startRange != 0 && this.equippreview[i]['pth'] === this.excludeRangeObj.startRange['pth']) {
                        this.dataService.setTabModified('tab-preview', true);
                        flag = true;
                    }
                    if (this.excludeRangeObj.endRange != 0 && this.equippreview[i]['pth'] === this.excludeRangeObj.endRange['pth']) {
                        var value: any = false;
                        flag = false;
                        this.equippreview[i]['isModified'] = true;
                        this.equippreview[i]['IsInclude'] = value;
                        this.updatePrimaryDataSource('IsInclude', false, this.equippreview[i]['pth']);
                        count++;
                        //console.log('Excluding' + this.equippreview[i]['Item']);
                        break;
                    }
                    if (flag) {
                        var value: any = false;
                        this.equippreview[i]['isModified'] = true;
                        this.equippreview[i]['IsInclude'] = value;
                        this.updatePrimaryDataSource('IsInclude', false, this.equippreview[i]['pth']);
                        //console.log('Excluding' + this.equippreview[i]['Item']);
                        count++;
                    }
                }
                //this.excludeRangeObj.startIndex = this.excludeRangeObj.endIndex = 0;
                //Exclude items issue changes
                this.excludeRangeObj.startRange = this.excludeRangeObj.endRange = 0;
                this.toggleChecked = false;
            }
        }
    }

    onButtonClick(field) {
        if (this.equippreview.length > 0) {
            this.skipAdditionalOnSortCall = false;
            setTimeout(() => {
                if (this.sortField.length > 0) {

                    this.equippreview.sort((data1, data2) => {
                        let value1 = data1[this.sortField];
                        let value2 = data2[this.sortField];
                        let result = null;

                        if (value1 == null && value2 != null)
                            result = -1;
                        else if (value1 != null && value2 == null)
                            result = 1;
                        else if (value1 == null && value2 == null)
                            result = 0;
                        else if (typeof value1 === 'string' && typeof value2 === 'string')
                            result = value1.trim().localeCompare(value2.trim());
                        else
                            result = (value1 < value2) ? -1 : (value1 > value2) ? 1 : 0;

                        return (this.sortOrder * result);
                    });
                }
                this.rearrangeRecords({ 'field': this.sortField });
            }, 100);
        }
    }

    rearrangeRecords(event) {
        if (event.field) {
            var that = this;
            if (that.equippreview.length > 0) {
                this.loadFlag = true;
                var indexCurrentRecord = [];
                var count = 0;
                var countTemp = 0;
                for (var i = 0; i < that.equippreview.length; i++) {
                    if (that.equippreview[i]['isHidden'] == true) {
                        count++;
                        indexCurrentRecord.push({ 'index': i, 'item': that.equippreview[i] });
                    }
                }
                that.equippreview = that.equippreview.filter(function (item) {
                    return item['isHidden'] != true;
                })
                indexCurrentRecord.forEach(item => {
                    that.equippreview.push(item['item']);
                });
                that.loadFlag = false;
                this.totalRecords = this.equippreview.length - indexCurrentRecord.length;
            }
        }
    }

    forcefulUpdatePage() {
        //Overriding Prime Ng Component here - for lazy load make changes here 
        this.dataTable.__proto__.updateTotalRecords = function () {
            this.totalRecords = true ? this.totalRecords : (this.equippreview ? this.equippreview.length : 0);
        };
    }

    refreshGrid() {
        this.rerender = false;
        setTimeout(() => {
            this.rerender = true;
            this.forcefulUpdatePage();
        }, 0);
    }

    customSort(event, tableInstance) {
        if (tableInstance) {
            this.dataTable = tableInstance;
            this.forcefulUpdatePage();
        }
        if (event['field']) {
            this.sortOrder = event['order'];
            this.sortField = event['field'];
        }
        console.log('custom sort for' + event['field']);
    }

    onPagechange(event, dataTable) {
        if (event.first >= 2800) {
            this.paginationEmpty = true;
        } else {
            this.paginationEmpty = false;
        }
        if (dataTable) {
            this.dataTable = dataTable;
            this.totalRecords = this.equippreview.length - this.getTotalCountForHiddenRecords();
            this.forcefulUpdatePage();
        }
        console.log('Start Index' + event.first);
        console.log('Number of Rows' + event.rows);
    }

    getRowData(rowData) {
        console.log(rowData);
    }

    getTotalCountForHiddenRecords() {
        if (this.equippreview.length > 0) {
            var count = 0;
            for (var i = 0; i < this.equippreview.length; i++) {
                if (this.equippreview[i]['isHidden'] == true) {
                    count++;
                }
            }
        }
        return count;
    }


}







