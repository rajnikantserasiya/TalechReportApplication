import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { MiddleContentHomeComponent } from './middle-content-home/middle-content-home.component';
import { SlideoutMenuComponent } from './slideout-menu/slideout-menu.component';
import { LoginDlgComponent, LoginDialogService} from './login-popup/login-popup.component';
import { LoadOldSessionPopupComponent } from './load-old-session-popup/load-old-session-popup.component';
import { HtmlResultPoupComponent } from './htmlview/html-result.component';
import { ContinueExistingSessionPopupComponent } from './continue-existing-session-popup/continue-existing-session-popup.component';
import {StartPopupService } from './start-popup.service';
import { NgModel } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { NgModule, Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Http, Headers, Response, Jsonp, RequestOptions, HttpModule } from '@angular/http';
import {MultiSelectModule} from 'primeng/primeng';
import {TabViewModule} from 'primeng/tabview';
import {AccordionModule} from 'primeng/accordion';

import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

import { SaveDataService } from './save-data.service';

import {LoginService } from './services/login.service';

import {LogoutService } from './services/logout.service';

import {SaveService } from './services/save.service';
import {ReportService } from './services/report.service';
import { StartNewSessionPopupComponent } from './start-new-session-popup/start-new-session-popup.component';
import { SaveExistingSessionPopupComponent } from './save-existing-session-popup/save-existing-session-popup.component';
import { ContSessionComponent } from './load-session-specification-tab/load-session-specification-tab.component';
import { SelectEquipmentExistSnComponent } from './select-equipment-exist-sn/select-equipment-exist-sn.component';
import { SelectEquipmentExistModelmastersComponent } from './select-equipment-exist-modelmasters/select-equipment-exist-modelmasters.component';
import { SelectEquipmentExistBOMComponent } from './select-equipment-exist-bom/select-equipment-exist-bom.component';
import { SelectEquipmentSelectedComponent } from './select-equipment-selected/select-equipment-selected.component';
import { AddPopupComponent } from './add-popup/add-popup.component';
import { GenerateReportsPopupComponent } from './generate-reports-popup/generate-reports-popup.component';
import { GenerateCostForecastReportsPopupComponent } from './generate-cost-forecast-reports-popup/generate-cost-forecast-reports-popup.component';
import { CustomerLocationPopupComponent } from './customer-location-popup/customer-location-popup.component';
import { ReportsComponent } from './reports/reports.component';
import { ReportsCostForecastComponent } from './reports-cost-forecast/reports-cost-forecast.component';
import { ReportsPartsconScheduleComponent } from './reports-partscon-schedule/reports-partscon-schedule.component';

import {SelectModelMasterService } from './services/select-model-master.service';
import { SelectEquipmentMasterService } from './services/select-equipment-master.service';
import { AddMasterModelComponent } from './add-master-model/add-master-model.component';

import { ExclusionsComponent } from './exclusions/exclusions.component';
import { OptionsComponent } from './options/options.component';
import { FactorsComponent } from './factors/factors.component';
import { PreviewComponent } from './preview/preview.component';
import {TreeModule, TreeNode, DataTableModule} from 'primeng/primeng';
import {TableModule} from 'primeng/table';
import { FilterPipe } from './filter.pipe';

import { DataService } from './services/data-component.service';
import { PaginationPipe } from './pipes/pagination.pipe';
import { PaginationService } from './services/pagination.service';
import { PaginationComponent } from './pagination/pagination.component';

import {EqExclusionsServiceService} from './services/eq-exclusions-service.service';

import { FetchCurrentDataService } from './services/fetch-current-data.service';
import { AppConstant } from './app.constant';
import { CommonUtil } from './common/common-util';
import { ExportUserLogComponent } from './export-user-log/export-user-log.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {CalendarModule} from 'primeng/calendar';
import { UpdateFleetPopupComponent } from './update-fleet-popup/update-fleet-popup.component';
import {ImportBomPopupComponent}  from './import-bom-popup/import-bom-popup.component';
import {LoadBomModalService} from './import-bom-popup/import-bom-popup.component'
import {PanelModule} from 'primeng/panel';
import {UpdateFleetService}  from './services/update-fleet.service';
import { MomentModule } from 'angular2-moment';
import {DialogModule} from 'primeng/dialog';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import { AddImportBomComponent } from './add-import-bom/add-import-bom.component';
import {ConfirmationService} from 'primeng/api';
import {TooltipModule} from 'primeng/tooltip';
import { UpdateBomsPopupComponent } from './update-boms-popup/update-boms-popup.component';
import { GenerateReportsCphPopupComponent } from './generate-reports-cph-popup/generate-reports-cph-popup.component';

import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthService } from './interceptor/auth.service';
import { InterceptorComponent } from './interceptor/interceptor.component';
import { CommonService } from './services/common.service';
import { ReportsPocBomSheetComponent } from './reports-poc-bom-sheet/reports-poc-bom-sheet.component';
import { AdvancedSearchComponent } from './advanced-search/advanced-search.component';
import { AdvancedSearchService } from './services/advanced-search.service';
import {AdminImportBomService}  from './services/admin-import-bom.service';
import { AdvacedRuleComponent } from './advaced-rule/advaced-rule.component';


import { AdvancedRuleDialogService} from './advaced-rule/advaced-rule.component';
import { EditSelectedEquipmentComponent } from './edit-selected-equipment/edit-selected-equipment.component';

import { EditSelectedBomService} from './edit-selected-equipment/edit-selected-equipment.component';
import { AdminUpdateFleetComponent } from './admin-update-fleet/admin-update-fleet.component';
import { AdminImportFleetPopupComponent } from './admin-import-fleet-popup/admin-import-fleet-popup.component';
import {LoadImportFleetModalService} from './admin-import-fleet-popup/admin-import-fleet-popup.component';

import { ToggleButtonModule } from 'primeng/togglebutton';

import {ContextMenuModule} from 'primeng/contextmenu';
import {MenuItem} from 'primeng/api';
import { CommonMessagePopupComponent } from './common-message-popup/common-message-popup.component';
import {OptionsComponentService} from './services/options-component.service';
import { NewUserMappingComponent } from './new-user-mapping/new-user-mapping.component';
import { NewUserMappingDialogService} from './new-user-mapping/new-user-mapping.component';
import {NewUserMappingService}  from './services/new-user-mapping.service';
import { UserLogTrackComponent } from './user-log-track/user-log-track.component';
import { UserLogTrackDialogService } from './user-log-track/user-log-track.component';
//import { LoaderComponent } from './loader/loader.component';
import { LoaderService } from './services/loader.service';
import { ReportMaintenancePartScheduleComponent } from './report-maintenance-part-schedule/report-maintenance-part-schedule.component';
import { CphReportHtmlformatComponent } from './cph-report-htmlformat/cph-report-htmlformat.component';
import { HtmlReportSelectedEquipmentModelComponent } from './html-report-selected-equipment-model/html-report-selected-equipment-model.component';
import { SelectedEquipmentModelService} from './html-report-selected-equipment-model/html-report-selected-equipment-model.component';
import { PartConsumptionReportHtmlFormatComponent } from './part-consumption-report-html-format/part-consumption-report-html-format.component';
import { CostForecastReportHtmlFormatComponent } from './cost-forecast-report-html-format/cost-forecast-report-html-format.component';


@NgModule({
    declarations: [
        AppComponent,
        LoginDlgComponent,
        HeaderComponent,
        FooterComponent,
        MiddleContentHomeComponent,
        SlideoutMenuComponent,
        LoadOldSessionPopupComponent,
        HtmlResultPoupComponent,
        ContinueExistingSessionPopupComponent,
        StartNewSessionPopupComponent,
        SaveExistingSessionPopupComponent,
        ContSessionComponent,
        SelectEquipmentExistSnComponent,
        SelectEquipmentExistModelmastersComponent,
        SelectEquipmentExistBOMComponent,
        SelectEquipmentSelectedComponent,
        AddPopupComponent,
        GenerateReportsPopupComponent,
        GenerateCostForecastReportsPopupComponent,
        ReportsComponent,
        ReportsCostForecastComponent,
        ReportsPartsconScheduleComponent,
        CustomerLocationPopupComponent,
        AddMasterModelComponent,
        ExclusionsComponent,
        OptionsComponent,
        FactorsComponent,
        PreviewComponent,
        FilterPipe,
        PaginationComponent,
        PaginationPipe,
        ExportUserLogComponent,
        ImportBomPopupComponent,
        AddImportBomComponent,
        UpdateFleetPopupComponent,
        UpdateBomsPopupComponent,
        GenerateReportsCphPopupComponent,
        ReportsPocBomSheetComponent,
        AdvancedSearchComponent,
        AdvacedRuleComponent,
        EditSelectedEquipmentComponent,
        AdminUpdateFleetComponent,
        AdminImportFleetPopupComponent,
        CommonMessagePopupComponent,
        NewUserMappingComponent,
        UserLogTrackComponent,
        ReportMaintenancePartScheduleComponent,
        CphReportHtmlformatComponent,
        HtmlReportSelectedEquipmentModelComponent,
        PartConsumptionReportHtmlFormatComponent,
        CostForecastReportHtmlFormatComponent,
        //LoaderComponent

    ],
    imports: [BrowserModule,
        HttpClientModule, HttpModule,
        NgbModule.forRoot(),
        FormsModule,
        AppRoutingModule,
        TreeModule,
        DataTableModule,
        TableModule,
        CalendarModule,
        BrowserAnimationsModule,
        PanelModule,
        MomentModule,
        ConfirmDialogModule,
        TooltipModule,
        DialogModule,
        ToggleButtonModule,
        ContextMenuModule,
        MultiSelectModule,
        TabViewModule,
        AccordionModule
    ],
    providers: [
        SaveDataService, StartPopupService, LoginService, LogoutService, SaveService, ReportService, SelectModelMasterService, SelectEquipmentMasterService, DataService, EqExclusionsServiceService, FetchCurrentDataService, AppConstant, CommonUtil, LoadBomModalService, UpdateFleetService, ConfirmationService,
        LoadImportFleetModalService,
        { provide: HTTP_INTERCEPTORS, useClass: InterceptorComponent, multi: true },
        AuthService, CommonService, AdvancedSearchService, AdvancedRuleDialogService, EditSelectedBomService, AdminImportBomService, OptionsComponentService, NewUserMappingDialogService, NewUserMappingService, UserLogTrackDialogService,
        SelectedEquipmentModelService, LoaderService
    ],
    entryComponents: [ExportUserLogComponent, AddPopupComponent, GenerateReportsPopupComponent, HtmlResultPoupComponent, GenerateCostForecastReportsPopupComponent, LoginDlgComponent, StartNewSessionPopupComponent, LoadOldSessionPopupComponent, ContinueExistingSessionPopupComponent, SaveExistingSessionPopupComponent, CustomerLocationPopupComponent, AddMasterModelComponent, ImportBomPopupComponent, UpdateFleetPopupComponent, AddImportBomComponent, UpdateBomsPopupComponent, GenerateReportsCphPopupComponent, AdvacedRuleComponent, EditSelectedEquipmentComponent, AdminImportFleetPopupComponent, CommonMessagePopupComponent, NewUserMappingComponent, UserLogTrackComponent, HtmlReportSelectedEquipmentModelComponent],
    bootstrap: [AppComponent]
})
export class AppModule { }
