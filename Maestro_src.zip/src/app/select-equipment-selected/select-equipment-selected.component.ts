//load-session
import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
//import { AddPopupService } from '../add-popup/add-popup.component';
import { SelectEquipmentMasterService } from './../services/select-equipment-master.service';
import { SaveService } from '../services/save.service';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { DataService } from './../services/data-component.service';
import { AppConstant } from './../app.constant';
import { CommonService } from '../services/common.service';
import {EqExclusionsServiceService} from '../services/eq-exclusions-service.service';
import { EditSelectedBomService } from '../edit-selected-equipment/edit-selected-equipment.component';
import {OptionsComponentService} from '../services/options-component.service';
import { ViewCompileResult } from '@angular/compiler/src/view_compiler/view_compiler';

@Component({
    selector: 'app-select-equipment-selected',
    templateUrl: './select-equipment-selected.component.html',
    styleUrls: ['./select-equipment-selected.component.css'],
    providers: [EditSelectedBomService]
})
export class SelectEquipmentSelectedComponent implements OnInit {

    eqsnHeadText = "Equipment SN";
    modHeadText = "Model";
    qtyHeadText = "Qty";
    agehrsHeadText = "Hrs.From";
    agemtrHeadText = "Hrs.To";
    addText = "Add >"; /*DEMOHACK*/
    clearText = "Clear";


    public equipmentsSelected: eqSelectedClass[] = [];

    private equipmentsClear: eqSelectedClass[] = [];

    checkedColumnCount: number = 0;

    selectAllVal: boolean = false;

    constructor(private eqExclusionsServiceService: EqExclusionsServiceService, private selectEquipmentMasterService: SelectEquipmentMasterService, private location: Location, private saveService: SaveService, private dataService: DataService, private appConstant: AppConstant, private fetchCurrentDataService: FetchCurrentDataService, private editSelectedBomService: EditSelectedBomService, private commonService: CommonService, private optionsComponentService: OptionsComponentService) {
        this.fetchCurrentDataService.screenDataStream$.subscribe(
            () => {
                if (!this.fetchCurrentDataService.disableFlagSaveSelectedEquip) {
                    var selectedEquipment = this.dataService.getData('selectedEquipment');
                    this.fetchCurrentDataService.disableFlagSaveSelectedEquip = true;
                    if (selectedEquipment && selectedEquipment.length > 0) {
                        this.fetchCurrentDataService.createJsonToSave(selectedEquipment, this.appConstant.selectedEquipemtRoot);
                    }
                }
            });
    }

    ngOnInit() {
        document.getElementById("slide-nav").style.width = "0";
        if (this.dataService.getData('selectedEquipment').length > 0) {
            this.processEquipResult(this.dataService.getData('selectedEquipment'));
        } else {
            this.addEquiptoSelectedList();
        }
        var price = this.dataService.getOptionsPriceType();
        var CountryCode2 = this.dataService.getOptions('glpDropdown');
        var CountryCode = this.dataService.getOptions('maplDropdown');
        //  if( (!price || price.length <=0) || (!CountryCode || CountryCode.length <=0) || (!CountryCode2 || CountryCode2.length <=0)) {
        this.getOptionsData();
        this.getCountryList();
        // }                    
    }

    getOptionsData() {

        this.optionsComponentService.getOptionsData().then(result => {
            if (result) {

                
                // Load JSON Changes
                if (this.fetchCurrentDataService.skipJsonCreationOnSave == true) {
                    debugger;

                    this.fetchCurrentDataService.skipJsonCreationOnSave = false;
                    var optionPriceType = this.dataService.getOptionsPriceType();
                    localStorage.setItem("PriceListType", optionPriceType);
                    localStorage.setItem("PriceListType_Report", optionPriceType);

                    var maplDropdown = this.dataService.getOptions('maplDropdown');
                    var glpDropdown = this.dataService.getOptions('glpDropdown');
                    if (optionPriceType === "GLP") {
                        localStorage.setItem("PriceList", glpDropdown.split('-')[2]);
                        localStorage.setItem("PriceList_Report", glpDropdown.split('-')[2]);
                    }
                    if (optionPriceType === "MAPL") {
                        localStorage.setItem("PriceList", maplDropdown.split('-')[2]);
                        localStorage.setItem("PriceList_Report", maplDropdown.split('-')[2]);
                    }
                }
                else {

                    var priceListGLP;
                    var priceListMAPL;
                    var countryList = this.dataService.getData('optionsCountryList');
                    if (!result[0]['GLPCountryCode'] && !result[0]['MAPLCountryCode']) {
                        this.dataService.setOptions('glpDropdown', 'GLP' + '-' + result[0]['DefaultCountry']);
                        this.dataService.setOptions('maplDropdown', 'MAPL' + '-' + result[0]['DefaultCountry']);
                        this.dataService.setOptionsPriceType('GLP');
                        localStorage.setItem("PriceListType", "GLP");
                        localStorage.setItem("PriceListType_Report", "GLP");
                        localStorage.setItem("PriceList", result[0]['GLPPriceList']);
                        localStorage.setItem("PriceList_Report", result[0]['GLPPriceList']);
                    }
                    else {
                        if (!this.dataService.getOptionsPriceType() || this.dataService.getOptionsPriceType().length == 0) {
                            this.dataService.setOptionsPriceType(result[0]['PriceType']);
                            if (result[0]['PriceType'] === "GLP" && result[0]['GLPPriceList']) {
                                localStorage.setItem("PriceListType", "GLP");
                                localStorage.setItem("PriceListType_Report", "GLP");
                                localStorage.setItem("PriceList", result[0]['GLPPriceList']);
                                localStorage.setItem("PriceList_Report", result[0]['GLPPriceList']);
                            } else if (result[0]['PriceType'] === "MAPL" && result[0]['MAPLPriceList']) {
                                localStorage.setItem("PriceListType", "MAPL");
                                localStorage.setItem("PriceListType_Report", "MAPL");
                                localStorage.setItem("PriceList", result[0]['MAPLPriceList']);
                                localStorage.setItem("PriceList_Report", result[0]['MAPLPriceList']);
                            }
                        }
                        if ((!this.dataService.getOptions('glpDropdown') && result[0]['GLPCountryCode']) || (this.dataService.getOptions('glpDropdown').length == 0 && result[0]['GLPCountryCode'])) {
                            this.dataService.setOptions('glpDropdown', 'GLP' + "-" + result[0]['GLPCountryCode'] + "-" + result[0]['GLPPriceList']);
                        }
                        if ((!this.dataService.getOptions('maplDropdown') && result[0]['MAPLCountryCode']) || (this.dataService.getOptions('maplDropdown').length == 0 && result[0]['MAPLCountryCode'])) {
                            this.dataService.setOptions('maplDropdown', 'MAPL' + "-" + result[0]['MAPLCountryCode'] + "-" + result[0]['MAPLPriceList']);
                        }
                    }
                }
            }
        })
            .catch(error => {
                console.log('Error');
            });
    }


    setPriceList(countryList) {
        setTimeout(() => {
            var priceListMapl: any;
            var priceListGLP: any;
            var maplValue;
            var glpValue = this.dataService.getOptions('glpDropdown');
            if (glpValue.indexOf('-') >= 0) {
                priceListGLP = glpValue.split('-');
                if (priceListGLP.length == 2) {
                    priceListGLP = this.dataService.getPriceListFromCountryAndPriceType(priceListGLP[0], priceListGLP[1]);
                    glpValue = glpValue + "-" + priceListGLP;
                    this.dataService.setOptions('glpDropdown', glpValue);
                }
            }
            maplValue = this.dataService.getOptions('maplDropdown');
            if (maplValue.indexOf('-') >= 0) {
                priceListMapl = maplValue.split('-');
                if (priceListMapl.length == 2) {
                    priceListMapl = this.dataService.getPriceListFromCountryAndPriceType(priceListMapl[0], priceListMapl[1]);
                    maplValue = maplValue + "-" + priceListMapl;
                    this.dataService.setOptions('maplDropdown', maplValue);
                }
            }
            if (this.dataService.getOptionsPriceType() === 'GLP') {
                localStorage.setItem("PriceList", priceListGLP);
                localStorage.setItem("PriceList_Report", priceListGLP);
            } else {
                localStorage.setItem("PriceList", priceListMapl);
                localStorage.setItem("PriceList_Report", priceListMapl);
            }
        }, 500);

    }

    getCountryList(): void {
        var price = this.dataService.getOptionsPriceType() || "";
        var CountryCodeGLP = this.dataService.getOptions('glpDropdown') || "";
        var CountryCodeMAPL = this.dataService.getOptions('maplDropdown') || "";
        this.eqExclusionsServiceService.getCountryList().then(result => {
            if (result) {
                this.dataService.setData('optionsCountryList', result, true);
                this.setPriceList(result);
            }
        })
            .catch(error => console.log(error));
    }

    addEquiptoSelectedList(): void {
        document.getElementById("slide-nav").style.width = "0";
        this.equipmentsClear = [];
        this.selectAllVal = false;
        setTimeout(() => {
            this.selectEquipmentMasterService.selectedEquipmentMaster().then(result => {
                this.processEquipResult(result);
            })
                .catch(error => console.log(error));

            console.log(this.equipmentsSelected);
        }, 1000);
    }

    processEquipResult(result) {
        if (result && result.length > 0) {
            this.equipmentsSelected = result;
            if (this.dataService.getData(this.appConstant.selectedEquipemtRoot).length == 0) {
                this.dataService.setData(this.appConstant.selectedEquipemtRoot, result, true);
            }
            this.checkedColumnCount = 0;
            this.equipmentsSelected.forEach(element => {
                if (element["checked"]) {
                    this.checkedColumnCount++;
                    this.equipmentsClear.push(element);
                }
            });
            this.selectEquipmentMasterService.selectEquipment((result.length.toString()));
        }
    }

    PopulateEquiptoSelectedList(): void {
        this.ngOnInit();
    }


    add(): void {
        console.log("add");
    }

    clear(): void {

        document.getElementById("slide-nav").style.width = "0";

        this.saveService.deleteMaestroSelectedEquipmentData(this.equipmentsClear).then()
            .catch(error => console.log(error));

        for (let entry of this.equipmentsClear) {
            this.equipmentsSelected.splice(this.equipmentsSelected.indexOf(entry), 1);
        };
        this.selectEquipmentMasterService.selectEquipment(this.equipmentsSelected.length.toString());
        this.equipmentsClear = [];

        this.dataService.clearReferenceForList(true);
        this.dataService.setData('selectedEquipment', this.equipmentsSelected, true);

        this.maintainCheckedCount();

        this.selectAllVal = false;

    }

    search(equipSel, event) {

        document.getElementById("slide-nav").style.width = "0";

        var index = this.equipmentsClear.indexOf(equipSel.SERIAL_NO);
        const index2: number = this.equipmentsClear.indexOf(equipSel.SERIAL_NO);

        if (event.target.checked) {
            this.equipmentsClear.push(equipSel);

        }
        else {
            this.equipmentsClear.splice(this.equipmentsClear.indexOf(equipSel), 1);
            this.selectAllVal = false;
        }

        if (this.equipmentsClear.length === 0) {
            this.selectAllVal = false;
        }

        if (this.equipmentsClear.length === this.equipmentsSelected.length) {
            this.selectAllVal = true;
        }

        this.maintainCheckedCount();
    }

    maintainCheckedCount() {
        this.checkedColumnCount = 0;
        this.equipmentsClear.forEach(element => {
            if (element["checked"]) {
                this.checkedColumnCount++;
            }
        });
    }

    selectAll(event) {
        if (this.equipmentsSelected.length > 0) {
            document.getElementById("slide-nav").style.width = "0";
            this.equipmentsClear = [];
            if (event.target.checked) {
                this.equipmentsSelected.forEach(element => {
                    element["checked"] = true;
                    this.equipmentsClear.push(element);
                });
            }
            else {
                this.equipmentsSelected.forEach(element => {
                    element["checked"] = false;
                    this.equipmentsClear.splice(this.equipmentsClear.indexOf(element), 1);
                });
            }
            this.maintainCheckedCount();

        } else {
            this.selectAllVal = false;
        }
    }

    enableDisableClear() {
        return this.checkedColumnCount > 0 || this.selectAllVal === true ? false : true;
    }

    onCheckBoxSelectEqupChange(data, value) {
        data['checked'] = value;
    }

    edit(equipmentsSelected): void {
        var data = [];
        equipmentsSelected.forEach(item => {
            if (item['checked']) {
                data.push(item);
            }
        });
        if (data.length > 0) {
            this.dataService.setEditSelectEquip(data);
        }
        document.getElementById("slide-nav").style.width = "0";
        this.maintainCheckedCount();
        this.editSelectedBomService.show();
    }

    maintainSelectedCheckedCount() {
        this.checkedColumnCount = 0;
        this.equipmentsSelected.forEach(element => {
            if (element["checked"]) {
                this.checkedColumnCount++;
            }
        });
    }




}


export class eqSelectedClass {

    UserName: string;
    EqSourceType: string;
    SerialNo: string;
    Model: string;
    Quantity: string;
    HourFrom: string;
    HourTo: string;
    MODELCATEGORY: string;
    EQ_LIFE: string;
    HR_TYPE: string;
    HrsYear1Boom: string;
}
