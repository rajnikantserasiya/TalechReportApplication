import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectEquipmentSelectedComponent } from './select-equipment-selected.component';

describe('SelectEquipmentSelectedComponent', () => {
  let component: SelectEquipmentSelectedComponent;
  let fixture: ComponentFixture<SelectEquipmentSelectedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectEquipmentSelectedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectEquipmentSelectedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
