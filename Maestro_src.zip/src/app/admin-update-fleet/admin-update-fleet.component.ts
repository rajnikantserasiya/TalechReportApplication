import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-update-fleet',
  templateUrl: './admin-update-fleet.component.html',
  styleUrls: ['./admin-update-fleet.component.css']
})
export class AdminUpdateFleetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
