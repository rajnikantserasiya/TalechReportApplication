import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminUpdateFleetComponent } from './admin-update-fleet.component';

describe('AdminUpdateFleetComponent', () => {
  let component: AdminUpdateFleetComponent;
  let fixture: ComponentFixture<AdminUpdateFleetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminUpdateFleetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminUpdateFleetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
