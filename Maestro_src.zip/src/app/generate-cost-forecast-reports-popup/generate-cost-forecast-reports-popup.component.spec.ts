import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateCostForecastReportsPopupComponent } from './generate-cost-forecast-reports-popup.component';

describe('GenerateCostForecastReportsPopupComponent', () => {
  let component: GenerateCostForecastReportsPopupComponent;
  let fixture: ComponentFixture<GenerateCostForecastReportsPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenerateCostForecastReportsPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerateCostForecastReportsPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
