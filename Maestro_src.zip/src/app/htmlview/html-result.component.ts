import {Component, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable } from '@angular/core';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { Http, Headers, Response, Jsonp, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { AppConstant } from './../app.constant';
import { DataService } from './../services/data-component.service';
import {EqSelectedPreviewList} from '../services/eq-exclusions-class';
import {ReportService} from '../services/report.service';

@Component({
    selector: 'html-result',
    templateUrl: './html-result.component.html',
    styleUrls: ['./html-result.component.css']
})


export class HtmlResultPoupComponent implements OnInit {

    constructor(private reportService: ReportService, public activeModal: NgbActiveModal, public changeRef: ChangeDetectorRef, private httpService: HttpClient, private http: Http, private fetchCurrentDataService: FetchCurrentDataService, private appConstant: AppConstant, private dataService: DataService) {
    }

    frozenCols: any = [
        { field: 'ModelCategory', header: 'Model Category', type: 'staticColumn', width: '12%' },
        { field: 'Equipment', header: 'Equipment', type: 'staticColumn', width: "8%" },
        { field: 'SectionId', header: 'Section Id', type: 'staticColumn', width: "12%" },
        { field: 'Item', header: 'Item', type: 'staticColumn', width: "5%" }
    ];


    cols: any = [
        { field: 'Section', header: 'Section', type: 'staticColumn', width: "8%" },
        { field: 'SectionClass', header: 'Section Class', type: 'staticColumn', width: "10%" },
        { field: 'Description', header: 'Description', type: 'staticColumn', width: "10%" },
        { field: 'ItemClass', header: 'ItemClass', type: 'staticColumn', width: "25%" },
        { field: 'REC', header: 'REC', type: 'staticColumn', width: "5%" },
        { field: 'UnitPrice', header: 'UnitPrice', type: 'staticColumn', width: "5%" },
        { field: 'TotalPriceDuring', header: 'Total Price', type: 'staticColumn', width: "5%" },
        { field: 'LifetimeHours', header: 'Lifetime Hours', type: 'staticColumn', width: "5%" },
        { field: 'Qty', header: 'Qty', type: 'staticColumn', width: "5%" },
        { field: 'TotalForecastQty', header: 'Total Forecast Qty', type: 'staticColumn', width: "5%" }
    ];

    eqSelectedPreviewList: EqSelectedPreviewList[] = [];

    htmlReport: string;
    htmlReport2: any = [];
    totalRecords: any;
    loadingFlag: boolean = false;
    equipmentData: any = [];
    selectedEquipLabel: string = "Select equipment";
    selectedrow: any;

    //constructor(private reportService: ReportService,public activeModal: NgbActiveModal, public changeRef: ChangeDetectorRef, private httpService: HttpClient, private http: Http , private fetchCurrentDataService : FetchCurrentDataService , private appConstant : AppConstant , private dataService : DataService) {
    //}

    ngOnInit() {
        if (this.dataService.getData('selectedEquipment').length > 0) {
            var selectedEquipmentList = this.dataService.getData('selectedEquipment');
            selectedEquipmentList.forEach(item => {

                //debugger;
                var label = '';//item["Model"] + ' SN:' + item["SerialNo"];
                if (item["EqSourceType"] == "1") {
                    label = item["Model"] + ' SN:' + item["SerialNo"];
                };
                if (item["EqSourceType"] == "2") {
                    label = item["Model"] + ' SN:' + item["SerialNo"];
                }
                if (item["EqSourceType"] == "3") {
                    label = item["Model"] + ' SN:' + item["SerialNo"] + "_Other";
                }

                item["label"] = label;
                this.equipmentData.push(item);
            });
        }
    }

    generateDyanamicColumns() {

        this.cols = [
            { field: 'Section', header: 'Section', type: 'staticColumn', width: "8%" },
            { field: 'SectionClass', header: 'Section Class', type: 'staticColumn', width: "10%" },
            { field: 'Description', header: 'Description', type: 'staticColumn', width: "10%" },
            { field: 'ItemClass', header: 'ItemClass', type: 'staticColumn', width: "25%" },
            { field: 'REC', header: 'REC', type: 'staticColumn', width: "5%" },
            { field: 'UnitPrice', header: 'UnitPrice', type: 'staticColumn', width: "5%" },
            { field: 'TotalPriceDuring', header: 'Total Price', type: 'staticColumn', width: "5%" },
            { field: 'LifetimeHours', header: 'Lifetime Hours', type: 'staticColumn', width: "5%" },
            { field: 'Qty', header: 'Qty', type: 'staticColumn', width: "5%" },
            { field: 'TotalForecastQty', header: 'Total Forecast Qty', type: 'staticColumn', width: "5%" }
        ];
        if (this.htmlReport2[0]["startRange"] >= 0 && this.htmlReport2[0]["endRange"] >= 500 && this.htmlReport2[0]["interval"] > 0) {
            for (let i = this.htmlReport2[0]["startRange"]; i <= this.htmlReport2[0]["endRange"]; i += this.htmlReport2[0]["interval"]) {
                this.cols.push({ field: i.toString(), header: i.toString(), type: 'dynamicRange', width: '5%' });
            }
        }
    }

    onEquipmentChange(equip) {
        if (equip != 'Select equipment') {
            this.loadingFlag = true;
            var selectedEquipmentList = this.dataService.getData('selectedEquipment');
            for (let entry of selectedEquipmentList.filter(s => s.Id == equip)) {
                let strModel: string = "";
                let strSerialNo: string = "";
                let strEqSourceType: string = "";
                let hourFrom: string = "";
                let hourTo: string = "";
                hourFrom = entry["HourFrom"];
                hourTo = entry["HourTo"];

                debugger;
                if (entry["EqSourceType"] == "1") {
                    strSerialNo = entry["SerialNo"];
                    localStorage.setItem("Model_SerialNo", strSerialNo);
                };
                if (entry["EqSourceType"] == "2") {
                    strModel = entry["Model"];
                    localStorage.setItem("Model_SerialNo", strModel);
                }
                if (entry["EqSourceType"] == "3") {
                    strModel = entry["Model"];
                    strSerialNo = entry["SerialNo"];
                    if (strModel != '' && strModel != null && strModel != "N/A") {
                        localStorage.setItem("Model_SerialNo", strModel);
                    }
                    if (strSerialNo != '' && strSerialNo != null && strSerialNo != "N/A") {
                        localStorage.setItem("Model_SerialNo", strSerialNo);
                    }
                }

                strEqSourceType = entry["EqSourceType"];

                this.cols = this.cols.filter(item => {
                    item["type"] != "dynamicRange";
                });

                this.getReportData(equip, strEqSourceType, hourFrom, hourTo)
            }
        }
    }


    getReportData(equip, EqSourceType, hourFrom, hourTo) {
        this.reportService.generatePartConsumptionCalendarInHtmlFormat(EqSourceType).then(
            value => {
                this.htmlReport2 = value;
                this.htmlReport2[0]["startRange"] = hourFrom;
                this.htmlReport2[0]["endRange"] = hourTo;
                this.htmlReport2[0]["interval"] = parseInt(localStorage.getItem("ReportIntervalTxt"));
                this.generateDyanamicColumns();
                this.loadingFlag = false;
            }
        );
    }

    openDialog(): void {
        var closeLoadOldSessionBtn = document.getElementById("closeLoadOldSessionBtn");
        var fileLoaderButton = document.getElementById("fileLoader");
        closeLoadOldSessionBtn.click();
        fileLoaderButton.click();
    }

    ngOnDestroy() {
        this.cols = [];
        this.htmlReport2 = [];
    }

    getStyle(col) {
        var style = "{'width':120px}";
        var width = 160;
        if (col['field'] === 'Description') {
            width = 270;
        }
        else if (col['field'] === 'Section') {
            width = 320;
        }
        return width + 'px';
    }
}

@Injectable() export class HtmlResultPoupservice {

    constructor(private modalService: NgbModal) { }

    public show() {
        const modalRef = this.modalService.open(HtmlResultPoupComponent, { windowClass: "hugeModal" });
        modalRef.componentInstance.name = "showlogindlg";
        modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }
}

