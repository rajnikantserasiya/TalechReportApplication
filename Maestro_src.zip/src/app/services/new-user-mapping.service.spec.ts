import { TestBed, inject } from '@angular/core/testing';

import { NewUserMappingService } from './new-user-mapping.service';

describe('NewUserMappingService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [NewUserMappingService]
    });
  });

  it('should be created', inject([NewUserMappingService], (service: NewUserMappingService) => {
    expect(service).toBeTruthy();
  }));
});
