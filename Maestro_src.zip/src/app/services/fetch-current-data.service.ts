import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {Http, Response, Headers, RequestOptions, Request, RequestMethod} from "@angular/http";
import { environment } from '../../environments/environment';
import { Subject }    from 'rxjs/Subject';
import { AppConstant } from './../app.constant';

@Injectable()
export class FetchCurrentDataService {

    //Screen -  SelectEquip- selected SN - 1
    screenDataSource = new Subject<string>();
    screenDataStream$ = this.screenDataSource.asObservable();
    refreshScreenSource = new Subject<string>();
    refreshScreenStream$ = this.refreshScreenSource.asObservable();
    addImportedBomSource = new Subject<string>();
    addImportedBomStream$ = this.addImportedBomSource.asObservable();
 
    jsonData : Array<Object> = [];
    screens = ["exclusions", "selectedSN" , "selectedEquipment"];
    allowApiForFileMode : boolean = false;
    dataSource = "new_session";  
    disableFlagSaveFactor = false;
    disableFlagSaveExclusion = false;
    disableFlagSavePreview = false;
    disableFlagSaveSelectedEquip = false;
    disableFlagSaveExistingSN = false;
    disableFlagSaveOptions = false;
    disableFlagSaveModelMaster = false;
    skipJsonCreationOnSave = false;
    disableFlagSaveReports = false;
    disableFlagSaveCostForcast = false;
    disableFlagSavePartscon = false;
    disableFlagSaveImportBom = false;
    disableFlagImportBomPopUp = false;
    
    //flag to avoid duplicate calls in reload handler of components
    reloadFlagExclusion = false;
    reloadFlagPreview = false;
    reloadFlagFactors = false;
    reloadFlagOptions = false;
    activeTab : string = "";

    constructor(private _http: Http , private appConstant : AppConstant) { }

    recordData() {
        this.setJsonAppData([]);
        var dataObject : any = {'filterName':'', 'filterValue':''}; 
        dataObject.filterName = this.appConstant.sessionDetailsRoot;
        dataObject.filterValue = [{'user':localStorage.getItem('UserName'),  'countryCode': localStorage.getItem('COUNTRY'), 'userSessionToken':localStorage.getItem('token')}];
        this.jsonData.push(dataObject);       
        this.screenDataSource.next('test');        
    }

    reloadCurrentTab() {
        this.refreshScreenSource.next('test');
    }

    addImportBomModel(data) {
        //this.disableFlagImportBomPopUp = true;
        this.addImportedBomSource.next(data);
    }
       
    setActiveTab(tab) {
        this.activeTab = tab;
    }

    getActiveTab() {
        return this.activeTab;
    }

    createJsonToSave(data , screenName) {
        console.log(screenName);
        var dataObject = {'filterName':'', "filterValue":''};
        dataObject.filterName = screenName;
        dataObject.filterValue = data;      
        this.insertUnique(screenName, dataObject);      
    }
    
    setDataSource(source : string ) {
        this.dataSource = source;
    }
 
    getDataSource() {
        return this.dataSource
    }

    setJsonAppData(content) : void {
        this.jsonData = content;
    }

    getJsonAppData() : any {               
        return this.jsonData;
    }

    extraDataBasedOnRoot(root) : any {
        var extractedData  : any = []; 
        extractedData = this.jsonData.filter(item =>{
            return item['filterName'] == root  && item['filterValue'].length >0;
        });
        if(extractedData.length > 0){
            extractedData = extractedData[0];
        }
        return extractedData; 
    }

    insertUnique(root , data ): boolean {
        var index : number = -1;
        this.jsonData.forEach(function(item , i ){
            if(item['filterName'] == root && item['filterValue'].length >= 0){
                index = i;
                return false;
            }             
        });   
        if(index > -1){
            this.jsonData.splice(index,1);                
        }
        this.jsonData.push(data);                
        return true;
    }

    setAllowApiForFileMode(value : boolean ) {
        this.allowApiForFileMode = value;
    }
 
    getAllowApiForFileMode() {
        return this.allowApiForFileMode;
    }    
}
