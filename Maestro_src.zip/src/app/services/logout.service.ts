import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {Http, Response, Headers, RequestOptions} from "@angular/http";
import { environment } from '../../environments/environment';
import { AuthService } from "../interceptor/auth.service";

@Injectable()
export class LogoutService {

    constructor(private _http: Http, private authService: AuthService) { }

    logoutUser(token: any): any {
        return this._http.post(environment.authenticationUrl + 'Logout?userSessionToken=' + token, token)
            .toPromise().then(this.extractData)
            .catch(this.handleError);

    }

    //Azure AD Changes
    public logoutUserFromAzureAD() {

        localStorage.setItem("token", "");
        localStorage.setItem("PriceListType", "");
        localStorage.setItem("PriceList", "");

        //window.location.href = "https://maestrowebappadauthentication.azurewebsites.net/.auth/logout";

        this._http.get('/.auth/logout')
            .toPromise().then((response) => {
            });

        setTimeout(item => {
            //window.close();
            //location.reload();            
            window.location.href = "https://login.microsoftonline.com/0166c58b-5ffe-4245-b610-931b438f7470/oauth2/logout";
        }, 2000)

        //window.location.href = "https://login.microsoftonline.com/0166c58b-5ffe-4245-b610-931b438f7470/oauth2/logout?post_logout_redirect_uri='https://maestrowebappadauthentication.azurewebsites.net'";
    }

    public azureADTokenRequestMethod(isRequestFromLogin: boolean) {
        this._http.get('/.auth/me')
            .toPromise().then((response) => {

                //debugger;
                //console.log(response);

                let tokenVal = response.json()[0]["id_token"];
                this.authService.setAuthToken(tokenVal);

                let tokenExpiryTime = response.json()[0]["expires_on"];
                this.authService.setTokenExpiryTime(tokenExpiryTime);

                // only first time it need to set
                if (isRequestFromLogin) {
                    // User Maestro Application AD Group object id
                    let adminGroupObjectId = "72506c0d-6cb7-4703-a3dd-1093f44d1450";
                    let normalUserGroupObjectId = "4c277dbe-03df-4a52-a95a-da4d4db01796";

                    //let tokenVal = response.json()[0]["id_token"];
                    let userClaimsObject = response.json()[0]["user_claims"];

                    //this.authService.setAuthToken(tokenVal);
                    localStorage.setItem("UserName", response.json()[0]["user_id"]);

                    // display admin panel or not based on user group
                    var adminSlide = (<HTMLInputElement>document.getElementById("adminSlideId"));
                    var slideOutDiv = (<HTMLInputElement>document.getElementById("slide-nav"));
                    var openslideBtn = (<HTMLInputElement>document.getElementById("openslideBtn"));

                    var userRole = '';
                    userClaimsObject.forEach(item => {

                        var strtype = item["typ"];
                        if (strtype == "groups") {

                            var strVal = item["val"];
                            if (strVal == adminGroupObjectId) {
                                // admin                                                  
                                slideOutDiv.style.display = 'block';
                                openslideBtn.style.display = 'block';
                                adminSlide.style.display = 'block';

                                userRole = "Admin";
                            }
                            else if (userRole == '' && strVal == normalUserGroupObjectId) {
                                // normal user
                                slideOutDiv.style.display = 'none';
                                openslideBtn.style.display = 'none';
                                adminSlide.style.display = 'none';
                                userRole = "User";
                            }
                        }

                        if (strtype == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname") {
                            localStorage.setItem("userId", item["val"]);
                        }

                    });

                    //debugger;
                    if (userRole == '') {
                        alert("You are not assigned to any maestro application group. Please contact your administrator.")
                        // user is not assigned to maestro application groups
                        var btnopenStartNewSession = (<HTMLInputElement>document.getElementById("btnopenStartNewSession"));
                        var btnopenDialog = (<HTMLInputElement>document.getElementById("btnopenDialog"));
                        var btnopenContinueExistingSession = (<HTMLInputElement>document.getElementById("btnopenContinueExistingSession"));

                        btnopenStartNewSession.disabled = true;
                        btnopenDialog.disabled = true;
                        btnopenContinueExistingSession.disabled = true;
                    }
                    else {
                        //debugger;
                        localStorage.setItem("userRole", userRole);

                        // Just for testing purpose
                        //if (localStorage.getItem("UserName") == "ashwini.dhanuche_c@sandvik.com") {
                        //    localStorage.setItem("UserName", "ashwini");

                        //}
                        //// Just for testing purpose
                        //if (localStorage.getItem("UserName") == "anup.gandhamwar_c@sandvik.com") {
                        //    localStorage.setItem("UserName", "AnupG");
                        //}
                    }

                    this.LoadDataInAzureADLoginModel();
                }
            }).catch(this.handleError);
    }

    //Azure AD Changes
    public LoadDataInAzureADLoginModel() {

        var welcomeUsrTxt = (<HTMLInputElement>document.getElementById("welcomeUsr"));
        welcomeUsrTxt.childNodes[1].textContent = localStorage.getItem("userId");
        welcomeUsrTxt.hidden = false;
        //debugger;
        localStorage.setItem("IsGenerateReportActive", "false");
        if (this.authService.getAuthToken() == "" || this.authService.getAuthToken() == null) {
            var slideOutDiv = (<HTMLInputElement>document.getElementById("slide-nav"));
            var openslideBtn = (<HTMLInputElement>document.getElementById("openslideBtn"));
            slideOutDiv.style.display = 'none';
            openslideBtn.style.display = 'none';
        }

        if (localStorage.getItem("PriceListType") == "" || localStorage.getItem("PriceListType") == null) {
            localStorage.setItem("PriceListType", "N/A");
        }
        if (localStorage.getItem("PriceList") == "" || localStorage.getItem("PriceList") == null) {
            localStorage.setItem("PriceList", "N/A");
        }
    }

    //Azure AD Changes
    public refreshToken() {
        this._http.get('/.auth/refresh')
            .toPromise().then((response) => {
                //debugger;
                console.log("Refresh Token Response: " + response);
                this.azureADTokenRequestMethod(false);
            }
            ).catch(this.handleError);
    }

    private extractData(res: Response) {
        let body = res.json();
        return body || {};
    }

    private handleError(error: any): any {
        console.error('An error occurred', error);
    }
}
