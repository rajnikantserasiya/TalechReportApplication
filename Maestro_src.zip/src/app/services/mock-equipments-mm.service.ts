import { Equipments_mm } from './equipments-mm.service';

export const EQUIPMENTS_MM: Equipments_mm[] = [

  //{cc: 'AU', cust: 'BHP', site: 'Billabong Mi', sn: '112D12345-1', model: 'CH660M', modelcat: 'ROCK PROCESSING'},
  //{cc: 'AU', cust: 'BHP', site: 'Billabong Mi', sn: '112D12345-2', model: 'CS 430', modelcat: 'ROCK PROCESSING'},
  //{cc: 'AU', cust: 'BHP', site: 'Billabong Mi', sn: '112D12345-5', model: 'CH420M', modelcat: 'ROCK PROCESSING'},
  //{cc: 'AU', cust: 'BHP', site: 'Billabong Mi', sn: '112D12345-4', model: 'CJ815',  modelcat: 'ROCK PROCESSING'},
  //{cc: 'AU', cust: 'BHP', site: 'Billabong Mi', sn: '112D12345-5', model: 'CH420M', modelcat: 'ROCK PROCESSING'},
  //{cc: 'AU', cust: 'BHP', site: 'Billabong Mi', sn: '112D12345-5', model: 'DU311-TK (ORION U)', modelcat: 'CUBEX'}
          
];
          
