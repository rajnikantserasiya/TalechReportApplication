import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import * as FileSaver from 'file-saver';
import { Observable } from 'rxjs/Observable';
import {Http, Response, Headers, RequestOptions, Request, RequestMethod} from "@angular/http";
import { SelectEquipmentMasterService } from './../services/select-equipment-master.service';
import { environment } from '../../environments/environment';
import { AuthService } from "../interceptor/auth.service";
import { CommonService } from '../services/common.service';
import {EqSelectedList} from '../services/eq-exclusions-class';
import { DataService } from './../services/data-component.service';
import { LogoutService } from '../services/logout.service';

declare var PNotify: any;
@Injectable()
export class ReportService {

    private equipmentsSelected: eqSelectedClass[] = [];
    private downloadInProgress: boolean = false;
    //private IsAzureADRelease: boolean = false;



    constructor(private _http: Http, private selectEquipmentMasterService: SelectEquipmentMasterService,
        private authService: AuthService, private commonService: CommonService, private dataService: DataService,
        private logoutService: LogoutService) { }

    setDownloadInProgress(flag: boolean): void {
        this.downloadInProgress = flag;
    }

    getDownloadInProgress(): boolean {
        return this.downloadInProgress;
    }


    generatePartConsumptionCalendarInExcelFormat(): Observable<Object[]> {
        return Observable.create(observer => {

            var fromHrs = this.commonService.getReportInterval('from');
            var toHrs = this.commonService.getReportInterval('to');
            var maintenancePartsForeCostsReportParameters = this.commonService.getMaintenancePartsForeCostsReportParameters();

            let reportOption: string = '{"UserName":"' + localStorage.getItem("UserName") + '","HoursFrom":"' + fromHrs + '","HoursTo":"' + toHrs + '","Interval":"' + localStorage.getItem("ReportIntervalTxt") + '","ReportHrsType":"' + localStorage.getItem("ReportHrsType") + '","ApplyAlignment":"' + localStorage.getItem("ApplyAlignment") + '","ApplySuppression":"' + localStorage.getItem("ApplySuppression") + '","FilterType":"' + localStorage.getItem("ReportFilter") + '","PriceType":"' + localStorage.getItem("PriceListType") + '","PriceList":"' + localStorage.getItem("PriceList") +
                '","reportCostPerStrategy":"' + maintenancePartsForeCostsReportParameters.reportCostPerStrategy +
                '","reportExecutiveSummary":"' + maintenancePartsForeCostsReportParameters.reportExecutiveSummary +
                '","reportIntervalSummary":"' + maintenancePartsForeCostsReportParameters.reportIntervalSummary +
                '","reportBOMDetails":"' + maintenancePartsForeCostsReportParameters.reportBOMDetails +
                '","reportInterest":"' + maintenancePartsForeCostsReportParameters.reportInterest +
                '","reportFormat":"' + maintenancePartsForeCostsReportParameters.reportFormat + '"}';

            let xhr1 = new XMLHttpRequest();

            var that = this;

            xhr1.open('POST', environment.apiUrl + 'MaestroReport/PcalReportInExcelFormat');

            xhr1.setRequestHeader("UserSessionToken", localStorage.getItem("token"));

            //Azure AD Changes (comment above 2 line to work for Azure AD)
            if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                xhr1.setRequestHeader("Authorization", 'Bearer ' + this.authService.getAuthToken());
            }

            xhr1.setRequestHeader('Content-type', 'application/json');

            xhr1.responseType = 'blob';

            xhr1.onload = function () {
                if (xhr1.status === 200) {
                    if (xhr1.response === "Part Consumption Calendar Generation is in progress") {
                        alert(xhr1.response);
                        PNotify.text = xhr1.response
                    } else if (xhr1.response != null) {

                        //Azure AD Changes
                        if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                            that.refreshToken();
                        }
                        var browser = that.getBrowserInfo() || "chrome";
                        if (browser.toLowerCase().indexOf("chrome") >= 0) {
                            var contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
                            var blob = new Blob([xhr1.response], { type: contentType });
                            observer.next(blob);
                            observer.complete();
                            FileSaver.saveAs(blob, 'Parts Consumption Schedule' + '');
                        } else {
                            var contentType = 'application/xml';
                            var textFileAsBlob = new Blob([xhr1.response], { type: contentType });
                            window.navigator.msSaveBlob(textFileAsBlob, "Parts Consumption Schedule.xlsx");
                            observer.next(textFileAsBlob);
                            observer.complete();
                        }
                        PNotify.removeAll();
                    }
                }
                else if (xhr1.status === 100) {
                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        that.refreshToken();
                    }

                    alert(xhr1.response);
                    PNotify.text = xhr1.response
                }
                else if (xhr1.status === 400) {
                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        that.refreshToken();
                    }

                    alert("Data is not available for provided Serial Number or Model Number");
                    PNotify.removeAll();
                    observer.complete();
                }
                else if (xhr1.status === 401) {
                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        alert("Your session has been expired. Please logout and log in again.");
                        that.logoutService.logoutUserFromAzureAD();
                    }

                }
                else {
                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        that.refreshToken();
                    }

                    observer.error(xhr1.response);
                }
            }
            xhr1.send(reportOption);


        });
    }

    generatePartConsumptionCalendarInExcelFormatCPH(): Observable<Object[]> {
        //todo-country
        var priceType = this.dataService.getOptionsPriceType();
        var country = this.dataService.getActiveCountry();
        var priceList = this.dataService.getActivePriceList();
        return Observable.create(observer => {

            var fromHrs = this.commonService.getReportInterval('from');
            var toHrs = this.commonService.getReportInterval('to');
            var maintenancePartsForeCostsReportParameters = this.commonService.getMaintenancePartsForeCostsReportParameters();

            let reportOption: string = '{"UserName":"' + localStorage.getItem("UserName") +
                '","HoursFrom":"' + fromHrs +
                '","HoursTo":"' + toHrs +
                '","Interval":"' + localStorage.getItem("ReportIntervalTxt") +
                '","ReportHrsType":"' + localStorage.getItem("ReportHrsType") +
                '","ApplyAlignment":"' + localStorage.getItem("ApplyAlignment") +
                '","ApplySuppression":"' + localStorage.getItem("ApplySuppression") +
                '","FilterType":"' + localStorage.getItem("ReportFilter") +
                '","PriceType":"' + priceType +
                '","PriceList":"' + priceList +
                '","PriceListCountry":"' + country +
                '","reportCostPerStrategy":"' + maintenancePartsForeCostsReportParameters.reportCostPerStrategy +
                '","reportExecutiveSummary":"' + maintenancePartsForeCostsReportParameters.reportExecutiveSummary +
                '","reportIntervalSummary":"' + maintenancePartsForeCostsReportParameters.reportIntervalSummary +
                '","reportBOMDetails":"' + maintenancePartsForeCostsReportParameters.reportBOMDetails +
                '","reportInterest":"' + maintenancePartsForeCostsReportParameters.reportInterest +
                '","reportFormat":"' + maintenancePartsForeCostsReportParameters.reportFormat + '"}';

            let xhr1 = new XMLHttpRequest();

            var that = this;

            xhr1.open('POST', environment.apiUrl + 'MaestroReport/PcalReportInExcelFormatCPH');

            xhr1.setRequestHeader("UserSessionToken", localStorage.getItem("token"));

            //Azure AD Changes
            if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                xhr1.setRequestHeader("Authorization", 'Bearer ' + this.authService.getAuthToken());
            }


            xhr1.setRequestHeader('Content-type', 'application/json');

            xhr1.responseType = 'blob';

            xhr1.onload = function () {
                if (xhr1.status === 200) {
                    if (xhr1.response === "Part Consumption Calendar Generation is in progress") {
                        alert(xhr1.response);
                        PNotify.text = xhr1.response
                    } else if (xhr1.response != null) {

                        //Azure AD Changes
                        if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                            that.refreshToken();
                        }

                        var browser = that.getBrowserInfo() || "chrome";
                        if (browser.toLowerCase().indexOf("chrome") >= 0) {
                            var contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
                            var blob = new Blob([xhr1.response], { type: contentType });
                            observer.next(blob);
                            observer.complete();
                            FileSaver.saveAs(blob, 'Parts Consumption Cost Per Hour' + '');
                        } else {
                            var contentType = 'application/xml';
                            var textFileAsBlob = new Blob([xhr1.response], { type: contentType });
                            window.navigator.msSaveBlob(textFileAsBlob, "Parts Consumption Cost Per Hour.xlsx");
                            observer.next(textFileAsBlob);
                            observer.complete();
                        }
                        PNotify.removeAll();
                    }
                }
                else if (xhr1.status === 100) {
                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        that.refreshToken();
                    }

                    alert(xhr1.response);
                    PNotify.text = xhr1.response
                }
                else if (xhr1.status === 400) {
                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        that.refreshToken();
                    }

                    alert("Data is not available for provided Serial Number or Model Number");
                    PNotify.removeAll();
                    observer.complete();
                }
                else if (xhr1.status === 401) {

                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        alert("Your session has been expired. Please logout and log in again.");
                        that.logoutService.logoutUserFromAzureAD();
                    }
                }
                else {
                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        that.refreshToken();
                    }

                    observer.error(xhr1.response);
                }
            }
            xhr1.send(reportOption);
        });
    }

    costForecastInExcelFormat(): Observable<Object[]> {

        var priceType = this.dataService.getOptionsPriceType();
        var country = this.dataService.getActiveCountry();
        var priceList = this.dataService.getActivePriceList();

        return Observable.create(observer => {

            var fromHrs = this.commonService.getReportInterval('from');
            var toHrs = this.commonService.getReportInterval('to');
            var maintenancePartsForeCostsReportParameters = this.commonService.getMaintenancePartsForeCostsReportParameters();

            let reportOption: string = '{"UserName":"' + localStorage.getItem("UserName") +
                '","HoursFrom":"' + fromHrs +
                '","HoursTo":"' + toHrs +
                '","Interval":"' + localStorage.getItem("ReportIntervalTxt") +
                '","ReportHrsType":"' + localStorage.getItem("ReportHrsType") +
                '","ApplyAlignment":"' + localStorage.getItem("ApplyAlignment") +
                '","ApplySuppression":"' + localStorage.getItem("ApplySuppression") +
                '","FilterType":"' + localStorage.getItem("ReportFilter") +
                '","PriceType":"' + priceType +
                '","PriceList":"' + priceList +
                '","PriceListCountry":"' + country +
                '","reportCostPerStrategy":"' + maintenancePartsForeCostsReportParameters.reportCostPerStrategy +
                '","reportExecutiveSummary":"' + maintenancePartsForeCostsReportParameters.reportExecutiveSummary +
                '","reportIntervalSummary":"' + maintenancePartsForeCostsReportParameters.reportIntervalSummary +
                '","reportBOMDetails":"' + maintenancePartsForeCostsReportParameters.reportBOMDetails +
                '","reportInterest":"' + maintenancePartsForeCostsReportParameters.reportInterest +
                '","reportFormat":"' + maintenancePartsForeCostsReportParameters.reportFormat + '"}';

            let xhr1 = new XMLHttpRequest();

            var that = this;

            xhr1.open('POST', environment.apiUrl + 'MaestroReport/CostForecastInExcelFormat');

            xhr1.setRequestHeader("UserSessionToken", localStorage.getItem("token"));

            //Azure AD Changes
            if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                xhr1.setRequestHeader("Authorization", 'Bearer ' + this.authService.getAuthToken());
            }

            xhr1.setRequestHeader('Content-type', 'application/json');

            xhr1.responseType = 'blob';

            xhr1.onload = function () {
                if (xhr1.status === 200) {
                    if (xhr1.response === "Part Consumption Calendar Generation is in progress") {
                        alert(xhr1.response);
                        PNotify.text = xhr1.response
                    } else if (xhr1.response != null) {

                        //Azure AD Changes
                        if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                            that.refreshToken();
                        }

                        var browser = that.getBrowserInfo() || "chrome";
                        if (browser.toLowerCase().indexOf("chrome") >= 0) {
                            var contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
                            var blob = new Blob([xhr1.response], { type: contentType });
                            observer.next(blob);
                            observer.complete();
                            FileSaver.saveAs(blob, 'Cost Forecast Report' + '');
                        } else {
                            var contentType = 'application/xml';
                            var textFileAsBlob = new Blob([xhr1.response], { type: contentType });
                            window.navigator.msSaveBlob(textFileAsBlob, "Cost Forecast Report.xlsx");
                            observer.next(textFileAsBlob);
                            observer.complete();
                        }
                        PNotify.removeAll();
                    }
                }
                else if (xhr1.status === 100) {
                    alert(xhr1.response);

                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        that.refreshToken();
                    }

                    PNotify.text = xhr1.response
                }
                else if (xhr1.status === 400) {
                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        that.refreshToken();
                    }

                    alert("Data is not available for provided Serial Number or Model Number");
                    PNotify.removeAll();
                    observer.complete();
                }
                else if (xhr1.status === 401) {

                    //Azure AD Changes
                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        alert("Your session has been expired. Please logout and log in again.");
                        that.logoutService.logoutUserFromAzureAD();
                    }

                }
                else {
                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        that.refreshToken();
                    }

                    observer.error(xhr1.response);
                }
            }
            xhr1.send(reportOption);


        });
    }

    pocBOMSheetInExcelFormat(selectedItemsValues: EqSelectedList): Observable<Object[]> {

        var priceType = this.dataService.getOptionsPriceType();
        var country = this.dataService.getActiveCountry();
        var priceList = this.dataService.getActivePriceList();

        return Observable.create(observer => {

            //debugger;

            // as discussed POC Bom sheet should show all items (No filter should be applied on it)
            let filterType = "0";

            //let reportOption: string = '{"UserName":"' + localStorage.getItem("UserName") + '","EqSourceType":"' + selectedItemsValues[0].EqSourceType + '","SerialNo":"' + selectedItemsValues[0].SerialNo + '","Model":"' + selectedItemsValues[0].mod + '","FilterType":"' + localStorage.getItem("ReportFilter") + '","PriceType":"' + priceType + '","PriceList":"' + priceList + '","PriceListCountry":"' + country + '"}';
            let reportOption: string =
                '{"UserName":"' + localStorage.getItem("UserName") +
                '","EqSourceType":"' + selectedItemsValues[0].EqSourceType +
                '","SerialNo":"' + selectedItemsValues[0].SerialNo +
                '","Model":"' + selectedItemsValues[0].mod +
                '","FilterType":"' + filterType +
                '","PriceType":"' + priceType +
                '","PriceList":"' + priceList +
                '","PriceListCountry":"' + country + '"}';

            let xhr1 = new XMLHttpRequest();

            var that = this;

            xhr1.open('POST', environment.apiUrl + 'MaestroReport/DownloadExcelForSelectedEquipmentBOM');

            //Azure AD Changes
            if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                xhr1.setRequestHeader("Authorization", 'Bearer ' + this.authService.getAuthToken());
            }

            xhr1.setRequestHeader('Content-type', 'application/json');

            xhr1.responseType = 'blob';

            xhr1.onload = function () {
                if (xhr1.status === 200) {
                    if (xhr1.response === "POC BOM Sheet Generation is in progress") {
                        alert(xhr1.response);
                        PNotify.text = xhr1.response
                    } else if (xhr1.response != null) {

                        //Azure AD Changes
                        if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                            that.refreshToken();
                        }
                        var browser = that.getBrowserInfo() || "chrome";
                        if (browser.toLowerCase().indexOf("chrome") >= 0) {
                            var contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
                            var blob = new Blob([xhr1.response], { type: contentType });
                            observer.next(blob);
                            observer.complete();
                            FileSaver.saveAs(blob, 'POC BOM Sheet Report' + '');
                        } else {
                            var contentType = 'application/xml';
                            var textFileAsBlob = new Blob([xhr1.response], { type: contentType });
                            window.navigator.msSaveBlob(textFileAsBlob, "POC BOM Sheet.xlsx");
                            observer.next(textFileAsBlob);
                            observer.complete();
                        }
                        PNotify.removeAll();
                    }
                }
                else if (xhr1.status === 100) {
                    alert(xhr1.response);

                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        that.refreshToken();
                    }

                    PNotify.text = xhr1.response
                }
                else if (xhr1.status === 400) {
                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        that.refreshToken();
                    }

                    alert("Data is not available for provided Serial Number or Model Number");
                    PNotify.removeAll();
                    observer.complete();
                }
                else if (xhr1.status === 401) {

                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        alert("Your session has been expired. Please logout and log in again.");
                        that.logoutService.logoutUserFromAzureAD();
                    }
                }
                else {
                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        that.refreshToken();
                    }

                    observer.error(xhr1.response);
                }
            }
            xhr1.send(reportOption);


        });
    }

    generatePartConsumptionCalendarInHtmlFormat(EqSourceType): any {

        var fromHrs = this.commonService.getReportInterval('from');
        var toHrs = this.commonService.getReportInterval('to');

        let strReportInput: string = '{"UserName":"' + localStorage.getItem("UserName") + '","HoursFrom":"' + fromHrs + '","HoursTo":"' + toHrs + '","Interval":"' + localStorage.getItem("ReportIntervalTxt") + '","ReportHrsType":"' + localStorage.getItem("ReportHrsType") + '","ApplyAlignment":"' + localStorage.getItem("ApplyAlignment") + '","ApplySuppression":"' + localStorage.getItem("ApplySuppression") + '","FilterType":"' + localStorage.getItem("ReportFilter") + '","Model_SerialNo":"' + localStorage.getItem("Model_SerialNo") + '","PriceType":"' + localStorage.getItem("PriceListType") + '","PriceList":"' + localStorage.getItem("PriceList") + '","EqSourceType":"' + EqSourceType + '"}';

        var _headers = new Headers();
        _headers.append("Content-Type", 'application/json');
        _headers.append("charset", 'utf-8');
        _headers.append("UserSessionToken", localStorage.getItem("token"));

        //Azure AD Changes
        if (this.commonService.getAzureADAuthenticationEnableFlagValue()) {
            _headers.append("Authorization", 'Bearer ' + this.authService.getAuthToken());
        }

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: _headers,
            body: strReportInput
        })



        return this._http.post(environment.apiUrl + 'MaestroReport/PcalReportInHTMLFormat', null, requestoptions)
            .toPromise().then(this.extractData)
            .catch(this.handleError);
    }

    exportUserLog(frmdate, todate): Observable<Object[]> {


        return Observable.create(observer => {

            let reportOption: string = '{"fromDate":"' + frmdate + '","toDate":"' + todate + '"}';

            let xhr1 = new XMLHttpRequest();

            var that = this;

            xhr1.open('POST', environment.apiUrl + 'MaestroEquipment/ExcusionItemsHistoryInExcelFormat');

            //Azure AD Changes
            if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                xhr1.setRequestHeader("Authorization", 'Bearer ' + this.authService.getAuthToken());
            }

            xhr1.setRequestHeader('Content-type', 'application/json');

            xhr1.responseType = 'blob';

            xhr1.onload = function () {
                if (xhr1.status === 200) {
                    if (xhr1.response === "Export User Log Generation is in progress") {
                        alert(xhr1.response);
                        PNotify.text = xhr1.response
                    } else if (xhr1.response != null) {

                        //Azure AD Changes
                        if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                            that.refreshToken();
                        }

                        var browser = that.getBrowserInfo() || "chrome";
                        if (browser.toLowerCase().indexOf("chrome") >= 0) {
                            var contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
                            var blob = new Blob([xhr1.response], { type: contentType });
                            observer.next(blob);
                            observer.complete();
                            FileSaver.saveAs(blob, 'Preview Item History' + '');
                        } else {
                            var contentType = 'application/xml';
                            var textFileAsBlob = new Blob([xhr1.response], { type: contentType });
                            window.navigator.msSaveBlob(textFileAsBlob, "Preview Item History.xlsx");
                            observer.next(textFileAsBlob);
                            observer.complete();
                        }
                        PNotify.removeAll();
                    }
                }
                else if (xhr1.status === 100) {
                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        that.refreshToken();
                    }

                    alert(xhr1.response);
                    PNotify.text = xhr1.response
                }
                else if (xhr1.status === 400) {
                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        that.refreshToken();
                    }

                    alert("Data is not available for provided date range");
                    PNotify.removeAll();
                    observer.complete();
                }
                else if (xhr1.status === 401) {

                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        alert("Your session has been expired. Please logout and log in again.");
                        that.logoutService.logoutUserFromAzureAD();
                    }
                }
                else {
                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        that.refreshToken();
                    }

                    observer.error(xhr1.response);
                }
            }
            xhr1.send(reportOption);


        });
    }

    exportUserLogActivityInExcelFormat(frmdate, todate): Observable<Object[]> {


        return Observable.create(observer => {

            let reportOption: string = '{"fromDate":"' + frmdate + '","toDate":"' + todate + '"}';

            let xhr1 = new XMLHttpRequest();

            var that = this;

            xhr1.open('POST', environment.apiUrl + 'MaestroEquipment/UserLoggingHistoryInExcelFormat');

            //Azure AD Changes
            if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                xhr1.setRequestHeader("Authorization", 'Bearer ' + this.authService.getAuthToken());
            }

            xhr1.setRequestHeader('Content-type', 'application/json');

            xhr1.responseType = 'blob';

            xhr1.onload = function () {
                if (xhr1.status === 200) {
                    if (xhr1.response === "Export User Logging Activity Generation is in progress") {
                        alert(xhr1.response);
                        PNotify.text = xhr1.response
                    } else if (xhr1.response != null) {

                        //Azure AD Changes
                        if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                            that.refreshToken();
                        }

                        var browser = that.getBrowserInfo() || "chrome";
                        if (browser.toLowerCase().indexOf("chrome") >= 0) {
                            var contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
                            var blob = new Blob([xhr1.response], { type: contentType });
                            observer.next(blob);
                            observer.complete();
                            FileSaver.saveAs(blob, 'User Log Activity History' + '');
                        } else {
                            var contentType = 'application/xml';
                            var textFileAsBlob = new Blob([xhr1.response], { type: contentType });
                            window.navigator.msSaveBlob(textFileAsBlob, "User Log Activity History.xlsx");
                            observer.next(textFileAsBlob);
                            observer.complete();
                        }
                        PNotify.removeAll();
                    }
                }
                else if (xhr1.status === 100) {
                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        that.refreshToken();
                    }

                    alert(xhr1.response);
                    PNotify.text = xhr1.response
                }
                else if (xhr1.status === 400) {
                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        that.refreshToken();
                    }

                    alert("Data is not available for provided date range");
                    PNotify.removeAll();
                    observer.complete();
                }
                else if (xhr1.status === 401) {

                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        alert("Your session has been expired. Please logout and log in again.");
                        that.logoutService.logoutUserFromAzureAD();
                    }
                }
                else {
                    //Azure AD Changes
                    if (that.commonService.getAzureADAuthenticationEnableFlagValue()) {
                        that.refreshToken();
                    }

                    observer.error(xhr1.response);
                }
            }
            xhr1.send(reportOption);


        });
    }

    SaveUserLoginTrack(Action): any {

        // let inputparameters: string = "{'userName':'" + localStorage.getItem("UserName") + '","action":"' + Action + '"}';
        let inputparameters: string = '{"userName":"' + localStorage.getItem("UserName") + '","action":"' + Action + '"}';

        var _headers = new Headers();
        _headers.append("Content-Type", 'application/json');
        _headers.append("charset", 'utf-8');

        //Azure AD Changes
        if (this.commonService.getAzureADAuthenticationEnableFlagValue()) {
            _headers.append("Authorization", 'Bearer ' + this.authService.getAuthToken());
        }

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: _headers,
            body: inputparameters
        })



        return this._http.post(environment.apiUrl + 'MaestroEquipment/SaveUserLoginTrack', null, requestoptions)
            .toPromise().then(this.extractData)
            .catch(this.handleError);
    }

    reportDurationService(): any {

        let strReportInput: string = '{"UserName":"' + localStorage.getItem("UserName") + '","ReportHrType":"' + localStorage.getItem("ReportHrsType") + '"}';

        var _headers = new Headers();
        _headers.append("Content-Type", 'application/json');
        _headers.append("charset", 'utf-8');
        _headers.append("UserSessionToken", localStorage.getItem("token"));

        //Azure AD Changes
        if (this.commonService.getAzureADAuthenticationEnableFlagValue()) {
            _headers.append("Authorization", 'Bearer ' + this.authService.getAuthToken());
        }

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: _headers,
            body: strReportInput
        })

        return this._http.post(environment.apiUrl + 'MaestroEquipment/GetPopupFromToHours', requestoptions)
            .toPromise().then(this.extractData)
            .catch(this.handleError);

    }

    private extractData(res: Response) {

        let body = res.json();
        return body || {};
    }

    private handleError(error: any): any {
        //let token = xhr1.getResponseHeader("RefreshToken");
        //this.authService.setAuthToken(token);
        console.error('An error occurred', error);
    }

    createReportRequest(tokenarray: any) {

    }

    getBrowserInfo() {
        var ua = navigator.userAgent, tem,
            M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
        if (/trident/i.test(M[1])) {
            tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
            return 'IE ' + (tem[1] || '');
        }
        if (M[1] === 'Chrome') {
            tem = ua.match(/\b(OPR|Edge)\/(\d+)/);
            if (tem != null) return tem.slice(1).join(' ').replace('OPR', 'Opera');
        }
        M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
        if ((tem = ua.match(/version\/(\d+)/i)) != null)
            M.splice(1, 1, tem[1]);
        return M.join(' ');
    }

    public refreshToken() {
        this._http.get('/.auth/refresh')
            .toPromise().then((response) => {
                //var test = response1
                console.log("Refresh Token Response: " + response);
            }
            ).catch(this.handleError);
    }
}


export class eqSelectedClass {

    UserName: string;
    InputSelectedEquipmentMasterId: string;
    SerialNo: string;
    Model: string;
    Quantity: string;
    HourFrom: string;
    HourTo: string;


}