import { TestBed, inject } from '@angular/core/testing';

import { MockEquipmentsService } from './mock-equipments.service';

describe('MockEquipmentsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MockEquipmentsService]
    });
  });

  it('should be created', inject([MockEquipmentsService], (service: MockEquipmentsService) => {
    expect(service).toBeTruthy();
  }));
});
