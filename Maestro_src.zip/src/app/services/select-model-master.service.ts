import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {Http, Response, Headers, RequestOptions, Request, RequestMethod} from "@angular/http";
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class SelectModelMasterService {

    constructor(private _http: HttpClient) {
    }

    selectModelMasterData(): any {        

        return this._http.get(environment.apiUrl + 'MaestroEquipment/GetAllEquipmentModelAPI')
            .toPromise().then(this.extractData).catch(this.handleError);
    }


    private extractData(res: Response) {
        return res;
    }

    private handleError(error: any): any {
        console.error('An error occurred', error);
    }

}
