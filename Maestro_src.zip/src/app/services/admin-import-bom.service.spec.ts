import { TestBed, inject } from '@angular/core/testing';

import { AdminImportBomService } from './admin-import-bom.service';

describe('AdminImportBomService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AdminImportBomService]
    });
  });

  it('should be created', inject([AdminImportBomService], (service: AdminImportBomService) => {
    expect(service).toBeTruthy();
  }));
});
