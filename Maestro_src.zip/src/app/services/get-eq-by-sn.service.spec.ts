import { TestBed, inject } from '@angular/core/testing';

import { GetEqBySnService } from './get-eq-by-sn.service';

describe('GetEqBySnService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GetEqBySnService]
    });
  });

  it('should be created', inject([GetEqBySnService], (service: GetEqBySnService) => {
    expect(service).toBeTruthy();
  }));
});
