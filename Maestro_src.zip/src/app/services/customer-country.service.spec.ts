import { TestBed, inject } from '@angular/core/testing';

import { CustomerCountryService } from './customer-country.service';

describe('CustomerCountryService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CustomerCountryService]
    });
  });

  it('should be created', inject([CustomerCountryService], (service: CustomerCountryService) => {
    expect(service).toBeTruthy();
  }));
});
