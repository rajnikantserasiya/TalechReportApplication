import { TestBed, inject } from '@angular/core/testing';

import { SelectEquipmentMasterService } from './select-equipment-master.service';

describe('SelectEquipmentMasterService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SelectEquipmentMasterService]
    });
  });

  it('should be created', inject([SelectEquipmentMasterService], (service: SelectEquipmentMasterService) => {
    expect(service).toBeTruthy();
  }));
});
