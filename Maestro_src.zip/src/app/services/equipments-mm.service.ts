export class Equipments_mm {

    COUNTRY: string;
    CUSTOMER_ID: string;
    SALES_AREA: string;
    SERIAL_NO: string;
    MODEL: string;
    MODELCATEGORY: string;   
}
           
