import { SelectEquipmentMasterService } from './select-equipment-master.service';

export const EQUIPMENTS_SN: SelectEquipmentMasterService[] = [
  
  //{cc: 'AU', cust: 'BHP', site: 'Billabong Mi', sn: '112D12345-1', model: 'LH410', modelcat: 'Loader'},
  //{cc: 'AU', cust: 'BHP', site: 'Billabong Mi', sn: '112D12345-2', model: 'LH517', modelcat: 'Loader'},
  //{cc: 'AU', cust: 'BHP', site: 'Billabong Mi', sn: '112D12345-3', model: 'LH410', modelcat: 'Loader'},
  //{cc: 'AU', cust: 'BHP', site: 'Billabong Mi', sn: '112D12345-4', model: 'LH410', modelcat: 'Loader'},
  //{cc: 'AU', cust: 'BHP', site: 'Billabong Mi', sn: '112D12345-5', model: 'LH410', modelcat: 'Loader'}

];