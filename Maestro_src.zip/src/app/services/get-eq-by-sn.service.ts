import { Injectable } from '@angular/core';

import { SelectEquipmentMasterService } from './select-equipment-master.service';
import { EQUIPMENTS_SN } from './mock-equipments.service';


@Injectable()
export class GetEqBySnService {

  constructor() {}
  
  getEquipmentsBySN(): SelectEquipmentMasterService[] {
    return EQUIPMENTS_SN;
  }

}