import { TestBed, inject } from '@angular/core/testing';

import { DataComponentService } from './data-component.service';

describe('DataComponentService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DataComponentService]
    });
  });

  it('should be created', inject([DataComponentService], (service: DataComponentService) => {
    expect(service).toBeTruthy();
  }));
});
