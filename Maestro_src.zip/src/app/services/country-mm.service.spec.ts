import { TestBed, inject } from '@angular/core/testing';

import { CountryMmService } from './country-mm.service';

describe('CountryMmService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CountryMmService]
    });
  });

  it('should be created', inject([CountryMmService], (service: CountryMmService) => {
    expect(service).toBeTruthy();
  }));
});
