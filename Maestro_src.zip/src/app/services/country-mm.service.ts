export class Country_mm {
    COUNTRY: string;
}  