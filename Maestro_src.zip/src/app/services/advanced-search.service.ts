import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {Http, Response, Headers, RequestOptions, Request, RequestMethod, URLSearchParams} from "@angular/http";
import { environment } from '../../environments/environment';
import { Subject }    from 'rxjs/Subject';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class AdvancedSearchService {

    constructor(private _http: HttpClient) { }

    private activeFilters : any = [];

    setActiveFilters(activeFilters) {
        this.activeFilters = activeFilters;
    }
  
    getActiveFilters() {
        return this.activeFilters;        
    }
      
    getMappedData(): any {    

        var headers = new Headers();
        let data: any = "{'UserName':'" + localStorage.getItem("UserName") + "'}";
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');
        var requestoptions = new RequestOptions({
            method: RequestMethod.Get,
            headers: headers,
            body: data
        });
        var obj = [];
        return this._http.post(environment.apiUrl + 'MaestroEquipment/GetExclustionCommMapList', requestoptions)
            .toPromise().then(this.extractData).catch(this.handleError);
		
    }

    private extractData(res: Response) {	         
		return res;
    }

    private handleError(error: any): any {
        console.error('An error occurred', error);
    }
      
    fetchRules(): any {       
        var headers = new Headers();
        let data: any = "{'UserName':'" +localStorage.getItem("UserName")+"'}";
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');
        var requestoptions = new RequestOptions({
            method: RequestMethod.Get,
            headers: headers,
            body: data
        });
        var obj = [];
        return this._http.post(environment.apiUrl + 'MaestroEquipment/GetMaestroRules' , requestoptions )
            .toPromise().then(this.extractData).catch(this.handleError);
    }
    
    saveRules(rules): any {       
        var headers = new Headers();
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');
        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: rules
        });
        var obj = [];
        return this._http.post(environment.apiUrl + 'MaestroEquipment/SaveMaestroRules', requestoptions)
            .toPromise().then(this.extractData).catch(this.handleError);
    }

    deleteRules(data): any {       
        var headers = new Headers();
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');
        var inputJSON = {'UserName' :  localStorage.getItem('UserName')};
        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: data
        });              
        return this._http.post(environment.apiUrl + 'MaestroEquipment/SaveMaestroRules', requestoptions)
            .toPromise().then(this.extractData).catch(this.handleError);
    }
}

