//load-session
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {Http, Response, Headers, RequestOptions, Request, RequestMethod} from "@angular/http";
import { environment } from '../../environments/environment';
import {EqSelectedList} from '../services/eq-exclusions-class';
import {EqPreviewList} from '../services/eq-exclusions-class';
import {EqFactorsList} from '../services/eq-exclusions-class';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { AppConstant } from './../app.constant';
import { Observable } from 'rxjs/Observable';
import { CountryList } from '../services/eq-exclusions-class';
import { CommonUtil }  from './../common/common-util';
import { HttpClient } from '@angular/common/http';


@Injectable()
export class EqExclusionsServiceService {

    constructor(private _http: HttpClient , private fetchCurrentDataService : FetchCurrentDataService , private appConstant : AppConstant , private commonUtil : CommonUtil ) {
    }   

    selectedExclusionsEquipment(selectedItemsValues: EqSelectedList): any {       

        let selectedItemsValues2: string = '[{"UserName":"' + selectedItemsValues.UserName + '","EqSourceType":"' + selectedItemsValues.EqSourceType + '","SerialNo":"' + selectedItemsValues.SerialNo + '","Model":"' + selectedItemsValues.Model + '","PriceType":"' + localStorage.getItem("PriceListType") + '","PriceList":"' + localStorage.getItem("PriceList") + '"}]';        
        let selectedEquipments: string = JSON.stringify(selectedItemsValues2);

        var headers = new Headers();
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: selectedItemsValues2
        })

        var obj = [];

        return this._http.post(environment.apiUrl + 'MaestroEquipment/GetExclusionBOM', requestoptions)
            .toPromise().then(this.extractData).catch(this.handleError);

    }

    selectedEquipmentFoctorsMaster(): any {     
        
        let userName: string = "{'UserId':'" + localStorage.getItem("UserName") + "'}"; 
		       
        return this._http.get(environment.apiUrl + 'MaestroEquipment/GetSelectedEquipmentsFoctorsByUserName?strUserName=' + userName)
            .toPromise().then(this.extractData).catch(this.handleError);                        
                
    }


    selectedPreviewEquipment(selectedItemsValues: EqSelectedList ,  priceType : string , priceList : string): any {        
       
        let selectedItemsValues2: string = '[{"UserName":"' + selectedItemsValues[0].UserName + '","EqSourceType":"' + selectedItemsValues[0].EqSourceType + '","SerialNo":"' + selectedItemsValues[0].SerialNo + '","Model":"' + selectedItemsValues[0].Model + '","PriceType":"' + priceType + '","PriceList":"' + priceList + '"}]';
       
        var headers = new Headers();
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: selectedItemsValues2
        })

        return this._http.post(environment.apiUrl + 'MaestroEquipment/GetPreviewBOM', requestoptions)
            .toPromise().then(this.extractData).catch(this.handleError);
    }


    updateGLPMAPLPrice(strPriceType : string, strPriceList : string): any {

        let selectedItemsValues: string = '{"UserName":"' + localStorage.getItem("UserName") + '","PriceType":"' + strPriceType + '","PriceList":"' + strPriceList + '"}';
        
        var headers = new Headers();
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: selectedItemsValues
        })

        return this._http.post(environment.apiUrl + 'MaestroEquipment/UpdateGLPMAPLPrice', requestoptions)
            .toPromise().then(this.extractData).catch(this.handleError);
    }

    getCountryList(): any {
		
        let userName: string = "{'UserId':'" + localStorage.getItem("UserName") + "'}"; 
		
        return this._http.get(environment.apiUrl + 'MaestroEquipment/GetCountryList?strUserName=' + userName)
            .toPromise().then(this.extractData).catch(this.handleError);
    }


    saveMaestroPreviewData(selectedItemsValues: EqPreviewList[], activeFilters: any): any {
	      
        this.commonUtil.displayNotification('Preview', 'saving', '');

        var previewDataForSaveObject = [];

        var activeFiltersArray = [];


        selectedItemsValues.forEach(item => {
            if (item["isModified"]) {
                previewDataForSaveObject.push(item);
            }
        });

        activeFilters.forEach(item => {

            activeFiltersArray.push({ "UserName": localStorage.getItem("UserName"), "NFWGroupName": item["NFWGroupName"], "IsActive": item["IsActive"] });

        });

        var previewDataForSave = { "isModified": previewDataForSaveObject, "UserNFWGroupMap": activeFiltersArray };

        let previewDataForSaveJson: string = JSON.stringify(previewDataForSave);
       
        var headers = new Headers();
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: previewDataForSaveJson
        })
        return this._http.post(environment.apiUrl + 'MaestroEquipment/UpdatePreviewItem', requestoptions)
            .toPromise().then( () => {
                this.extractData;
                this.hideNotification();
            }).catch(this.handleError);
    }
    
    saveRowMaestroPreviewData(selectedItemsValues: EqPreviewList): any {
        this.commonUtil.displayNotification('Preview' , 'saving' , '');
        var temp = [];
        temp.push(selectedItemsValues);

        let customer: string = JSON.stringify(temp);
        var headers = new Headers();
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: customer
        })
        return this._http.post(environment.apiUrl + 'MaestroEquipment/UpdatePreviewItemCheck', requestoptions)
            .toPromise().then( () => {
                this.extractData;
                this.hideNotification();
            }).catch(this.handleError);
    }

    saveMaestroFactoreData(equipfactors: EqFactorsList[]): any {
        this.commonUtil.displayNotification('Factors' , 'saving' , '');
        let customer: string = JSON.stringify(equipfactors);
        var headers = new Headers();
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: customer
        })
        return this._http.post(environment.apiUrl + 'MaestroEquipment/UpdateFactorsItem', requestoptions)
            .toPromise().then( (res) => {
                this.extractData;
                this.hideNotification();
            }).catch(this.handleError);
    }


    saveMaestroExclusionData(selectedItemsValues: any, activeFilters:any): any {
        this.commonUtil.displayNotification('Exclusions' , 'saving' , '');
        var tempArray = [];
        var activeFiltersArray = [];


        selectedItemsValues.forEach(item => {
            if(item['IsModified']) {
                tempArray.push({ "Path": item["Path"], "Qty": item["Qty"], "Description": item["Description"], "EqSourceType": item["EqSourceType"], "Equipment": item["Equipment"], "IsInclude": item["IsInclude"], "Item": item["Item"], "LifetimeHours": item["LifetimeHours"], "ModelCategory": item["ModelCategory"], "Section": item["Section"], "SectionClass": item["SectionClass"], "SectionId": item["SectionId"], "Sn_Qty": item["Sn_Qty"], "TotalPriceDuring": item["TotalPriceDuring"], "UnitPrice": item["UnitPrice"], "UserName": item["UserName"], "label": item["label"], "level": item["level"], "index": item["index"] ,"IsModified": item["IsModified"] });
            }            
        });

        activeFilters.forEach(item => {
          
            activeFiltersArray.push({ "UserName": localStorage.getItem("UserName"), "NFWGroupName": item["NFWGroupName"], "IsActive": item["IsActive"]});
        
        });
           
        var exclusionDataForSave = { "isModified": tempArray, "UserNFWGroupMap": activeFiltersArray };

        let exclusionDataForSaveJson: string = JSON.stringify(exclusionDataForSave);
        
        var headers = new Headers();
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: exclusionDataForSaveJson
        })
        return this._http.post(environment.apiUrl + 'MaestroEquipment/UpdateExclusionItem', requestoptions)
            .toPromise().then( () => {
                this.extractData;
                this.hideNotification();
            }).catch(this.handleError);
    }

    ReSetPreview(selectedItemsValues: any): any {

        let selectedItemsValues1: string = '';
        
        var tempArray = [];
        selectedItemsValues.forEach(item => {            
            selectedItemsValues1 = '{"UserName":"' + item["UserName"]  + '","EqSourceType":"' + item["EqSourceType"] + '","SerialNo":"' + item["SerialNo"]  + '","Model":"' + item["Model"] + '"}';
        });

        var headers = new Headers();
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: selectedItemsValues1
        })
        return this._http.post(environment.apiUrl + 'MaestroEquipment/ReSetPreviewItems', requestoptions)
            .toPromise().then(this.extractData).catch(this.handleError);
    }


    private extractData(res: Response) {
       
        return res;
    }

    hideNotification() {
        this.commonUtil.hideNotification();
        this.commonUtil.displayNotification('' , 'success' , '');       
    }

    private handleError(error: any): any {
        
        console.error('An error occurred', error);
    }
      

}

