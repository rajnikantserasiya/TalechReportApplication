import { Injectable } from '@angular/core';

import { Equipments_mm } from './equipments-mm.service';
import { EQUIPMENTS_MM } from './mock-equipments-mm.service';

@Injectable()
export class GetEqByMmService {

  constructor() { }
  
  getEquipmentsByMM(): Equipments_mm[] {

   return EQUIPMENTS_MM;

  }

}
