import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {Http, Response, Headers, RequestOptions, Request, RequestMethod} from "@angular/http";
import { environment } from '../../environments/environment';
import { Subject }    from 'rxjs/Subject';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { AppConstant } from './../app.constant';
import { Observable } from 'rxjs/Observable';
import { DataService } from './../services/data-component.service';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class SelectEquipmentMasterService {

    // Observable string sources
    private equipmentSelectedSource = new Subject<string>();

    // Observable string streams
    equipmentSelected$ = this.equipmentSelectedSource.asObservable();
    private selectedEquipNos: any;


    constructor(private _http: HttpClient , private fetchCurrentDataService : FetchCurrentDataService , private appConstant : AppConstant , private dataService : DataService) {
    }   

    // Service message commands
    selectEquipment(numberOfEquipments: string) {
        this.selectedEquipNos = numberOfEquipments;
        this.equipmentSelectedSource.next(numberOfEquipments);
    }

    getSelectedEquipment(): any {
        return this.selectedEquipNos;
    }


    selectEquipmentMasterData(): any {
       		
		let countryCodeValue: string = "{'CountryCode':'" + localStorage.getItem("COUNTRY") + "'}"

        return this._http.get(environment.apiUrl + 'MaestroEquipment/GetAllEquipmentSNByCountryAPI?strCountryCode=' + countryCodeValue)
            .toPromise().then(this.extractData).catch(this.handleError);
    }

    selectedEquipmentMaster(): any {
        if(this.fetchCurrentDataService.getDataSource() === "file" &&  !this.fetchCurrentDataService.getAllowApiForFileMode()){
            let data = this.fetchCurrentDataService.extraDataBasedOnRoot(this.appConstant.selectedEquipemtRoot);
            if(data && data.length > 0){
                data =  data[0][this.appConstant.selectedEquipemtRoot];
                let sessionData = this.fetchCurrentDataService.extraDataBasedOnRoot(this.appConstant.sessionDetailsRoot);
                if(sessionData && sessionData.length > 0){
                    sessionData =  sessionData[0][this.appConstant.sessionDetailsRoot];
                    if(sessionData[0][this.appConstant.countryCode]){
                            localStorage.setItem(this.appConstant.country, sessionData[0][this.appConstant.countryCode]);
                    }                    
                }                                 
                return Observable.of(data).toPromise().then(this.extractData).catch(this.handleError);
            } else {
                return this.getSelectedEquipFromServer();
                }            
        } else {
            var filterdata =  this.dataService.getData(this.appConstant.selectedEquipemtRoot);
            if(filterdata.length > 0 ){
                return Observable.of(filterdata).toPromise().then().catch(this.handleError);
            } else {
                return this.getSelectedEquipFromServer();                           
            }
        }        
    }

    private getSelectedEquipFromServer() : any {        
				
		let userName: string = "{'UserId':'" + localStorage.getItem("UserName") + "'}";

        return this._http.get(environment.apiUrl + 'MaestroEquipment/GetSelectedEquipmentsByUserName?strUserName=' + userName)
            .toPromise().then(this.extractData).catch(this.handleError);
    }

    private extractData(res: Response) {
	        
		return res;
    }

    private handleError(error: any): any {
        console.error('An error occurred', error);
    }

}
