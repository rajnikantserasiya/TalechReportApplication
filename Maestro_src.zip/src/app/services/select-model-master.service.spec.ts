import { TestBed, inject } from '@angular/core/testing';

import { SelectModelMasterService } from './select-model-master.service';

describe('SelectModelMasterService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SelectModelMasterService]
    });
  });

  it('should be created', inject([SelectModelMasterService], (service: SelectModelMasterService) => {
    expect(service).toBeTruthy();
  }));
});
