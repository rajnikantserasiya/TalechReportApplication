import { TestBed, inject } from '@angular/core/testing';

import { EquipmentsMmService } from './equipments-mm.service';

describe('EquipmentsMmService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EquipmentsMmService]
    });
  });

  it('should be created', inject([EquipmentsMmService], (service: EquipmentsMmService) => {
    expect(service).toBeTruthy();
  }));
});
