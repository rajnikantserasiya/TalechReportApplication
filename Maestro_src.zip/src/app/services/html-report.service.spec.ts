import { TestBed, inject } from '@angular/core/testing';

import { HtmlReportService } from './html-report.service';

describe('HtmlReportService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HtmlReportService]
    });
  });

  it('should be created', inject([HtmlReportService], (service: HtmlReportService) => {
    expect(service).toBeTruthy();
  }));
});
