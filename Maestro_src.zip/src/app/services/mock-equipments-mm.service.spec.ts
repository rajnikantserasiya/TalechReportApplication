import { TestBed, inject } from '@angular/core/testing';

import { MockEquipmentsMmService } from './mock-equipments-mm.service';

describe('MockEquipmentsMmService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MockEquipmentsMmService]
    });
  });

  it('should be created', inject([MockEquipmentsMmService], (service: MockEquipmentsMmService) => {
    expect(service).toBeTruthy();
  }));
});
