import { TestBed, inject } from '@angular/core/testing';

import { GetEqByMmService } from './get-eq-by-mm.service';

describe('GetEqByMmService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GetEqByMmService]
    });
  });

  it('should be created', inject([GetEqByMmService], (service: GetEqByMmService) => {
    expect(service).toBeTruthy();
  }));
});
