import { TestBed, inject } from '@angular/core/testing';

import { EqExclusionsServiceService } from './eq-exclusions-service.service';

describe('EqExclusionsServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EqExclusionsServiceService]
    });
  });

  it('should be created', inject([EqExclusionsServiceService], (service: EqExclusionsServiceService) => {
    expect(service).toBeTruthy();
  }));
});
