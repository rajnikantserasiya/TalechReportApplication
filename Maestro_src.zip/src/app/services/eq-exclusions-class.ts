export class EqExclusionsClass {
    Equipment: string;
    EquipmentData: EqExclusionsList[];   
}

export class EqSelectedList {
    SerialNo: string;
    Model: string;
    Quantity: string;
    HourFrom: string;
    HourTo: string;
    EqSourceType: string;
    UserName: string;
    MODELCATEGORY: string;
    EQ_LIFE: string;
    HR_TYPE: string;
    HrsYear1Boom: string;
}

export class EqExclusionsList {
    Equipment: string;
    EqSourceType:string;
    ModelCategory: string;
    SectionId: string;
    Section: string;
    Item: string;
    Description: string;
    REC: string;
    LifetimeHours: string;
    Qty: string;
    Sn_Qty: string;
    level: string;
    Path: string;
    UserName:string;
    IsInclude:string;
    
    SectionClass:string;
    CommCode:string;
    UnitPrice:string;
    TotalPriceDuring:string;
}

export class EqFactorsList {
    ModelCategory: string;
    SerialNo: string;
    Model: string;
    Quantity: string;
    HourFrom: string;
    HourTo: string;
    EqSourceType: string;
    UserName: string;
    EQ_LIFE: string;
    HR_TYPE: string;
    ENGINE: string;
    PERCUSSION: string;
    COMPRESSOR: string;
    POWERPACK: string;
    GearBox: string;
    HrsYear1Boom: string;
}

export class EqPreviewList {
    Equipment: string;
    EqSourceType:string;
    ModelCategory: string;
    SectionId: string;
    Section: string;
    Item: string;
    Description: string;
    REC: string;
    LifetimeHours: string;
    Qty: string;
    Sn_Qty: string;
    level: string;
    Path: string;
    UserName:string;
    IsInclude:string;
    
    SectionClass:string;
    CommCode:string;
    UnitPrice:string;
    TotalPriceDuring:string;
}

export class EqSelectedPreviewList {
    Id:string;
    Equipment: string;
    EqSourceType:string; 
    SerialNo: string;
    Model: string; 
    UserName: string;  
}

export class Country_mm {
    COUNTRY: string;
} 

export class CountryList {
    CountryCode: string; 
	CountryName: string; 
	ListType: string; 
	PriceList: string; 
	Currency: string;
} 

export class EqImportBom {
    ModelCategory: string;    
    Model: string;
    Quantity: string;
    HourFrom: string;
    HourTo: string;
    EqSourceType: string;
    UserName: string;    
}
