//load-session
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {Http, Response, Headers, RequestOptions, Request, RequestMethod} from "@angular/http";
import { environment } from '../../environments/environment';
import { CommonUtil }  from './../common/common-util';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class SaveService {

    constructor(private _http: HttpClient , private commonUtil : CommonUtil) {
    }

    saveMaestroSessionData(): any {

        this.commonUtil.displayNotification('Equipments' , 'saving' , '');        

        let customer: string = '{"ListMaestroSessionMetadata":[{"UserId":"' + localStorage.getItem("UserName") + '","SessionId":"Session","CurrentDate":"","ItemId":"Item"},{"UserId":"' + localStorage.getItem("UserName") + '","SessionId":"Session1","CurrentDate":"","ItemId":"Item1"}]}';

        return this._http.post(environment.apiUrl + 'MaestroSession/SaveMaestroSessionMetadata?objMaestroSessionMetadata=' + customer, customer)
            .toPromise().then( () => {
                this.extractData;
                this.hideNotification('save');
            }).catch(this.handleError);
    }


    deleteMaestroSessionData(userId: any): any {      

        let userIdValue: string = "{'UserName':'" + localStorage.getItem("UserName") + "'}";
        
        return this._http.post(environment.apiUrl  + 'MaestroEquipment/DeleteUserInput?strUserName=' + userIdValue,userIdValue)
            .toPromise().then().catch(this.handleError);
    }

    saveMaestroSelectedEquipmentData(selectedItemsValues: eqSelectedSaveClass[]): any {
        this.commonUtil.displayNotification('Equipments' , 'saving' , '');
        let customer: string = '{' + "ListSelectedEquipmentsFromUser" + ":" + JSON.stringify(selectedItemsValues) + '}';
        var headers = new Headers();
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: customer
        })


        return this._http.post(environment.apiUrl + 'MaestroEquipment/SaveSelectedEquipmentsFromUserInput', requestoptions)
            .toPromise().then( () => {
               this.extractData;
               this.hideNotification('save');
            }).catch(this.handleError);

    }

    editMaestroSelectedEquipmentData(selectedItemsValues: eqSelectedSaveClass[]): any {
        this.commonUtil.displayNotification('Equipments' , 'saving' , '');
        let customer: string = '{' + "ListSelectedEquipmentsFromUser" + ":" + JSON.stringify(selectedItemsValues) + '}';
        var headers = new Headers();
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: customer
        })


        return this._http.post(environment.apiUrl + 'MaestroEquipment/EditSelectedEquipmentsFromUserInput', requestoptions)
            .toPromise().then( () => {
               this.extractData;
               this.hideNotification('save');
            }).catch(this.handleError);



    }
   

    deleteMaestroSelectedEquipmentData(equipmentsClear: eqSelectedSaveClass[]): any {        

        let customer: string = '{' + "ListSelectedEquipmentsFromUser" + ":" + JSON.stringify(equipmentsClear) + '}';
        var headers = new Headers();
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: customer
        })

        return this._http.post(environment.apiUrl + 'MaestroEquipment/DeleteSelectedEquipmentsByEquipmentList', requestoptions)
            .toPromise().then( () => {
                this.extractData;            
            }).catch(this.handleError);
    }

    private extractData(res: Response) {        

		return res;
    }

    private handleError(error: any): any {		
        console.error('An error occurred', error);
    }

    hideNotification(str) {
        this.commonUtil.hideNotification();
        if(str === "delete"){
            this.commonUtil.displayNotification('' , 'deleteSuccess' , '');            
        } else {
            this.commonUtil.displayNotification('' , 'success' , '');            
        }               
    }

    reportDurationService(): any {

        let strReportInput: string = '{"UserName":"' + localStorage.getItem("UserName") + '","ReportHrType":"' + localStorage.getItem("ReportHrsType") + '"}';

        var _headers = new Headers();
        _headers.append("Content-Type", 'application/json');
        _headers.append("charset", 'utf-8');
        //_headers.append("UserSessionToken", localStorage.getItem("token"));

        //Azure AD Changes (comment above 1 line to work for Azure AD)
        //_headers.append("Authorization", 'Bearer ' + this.authService.getAuthToken());

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: _headers,
            body: strReportInput
        })

        return this._http.post(environment.apiUrl + 'MaestroEquipment/GetPopupFromToHours', requestoptions)
            .toPromise().then(this.extractData)
            .catch(this.handleError);

    }
}

export class eqSelectedSaveClass {
    SerialNo: string;
    Model: string;
    Quantity: string;
    HourFrom: string;
    HourTo: string;
    EqSourceType: string;
    UserName: string;
    MODELCATEGORY: string;
    EQ_LIFE: string;
    HR_TYPE: string;
}
