//load-session
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {Http, Response, Headers, RequestOptions, Request, RequestMethod} from "@angular/http";
import { environment } from '../../environments/environment';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { AppConstant } from './../app.constant';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class SelectEquipmentOtherService {

    constructor(private _http: HttpClient, private fetchCurrentDataService: FetchCurrentDataService, private appConstant: AppConstant) {
    }

    saveManuallyImportedMachine(data, mapping, popUpData): any {

        var dataToSend = [{ 'mappedData': data, 'mapping': mapping, 'popUpData': popUpData }];
        let customer: string = JSON.stringify(dataToSend);

        var headers = new Headers();
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: customer
        })

        return this._http.post(environment.apiUrl + 'MaestroEquipment/SaveManuallyImportedMachine', requestoptions)
            .toPromise().then(this.extractData).catch(this.handleError);
    }

    getModelCategory(): any {
        var headers = new Headers(), authtoken = localStorage.getItem('token');
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');

        var requestoptions = new RequestOptions({
            method: RequestMethod.Get,
            headers: headers
        });

        return this._http.get(environment.apiUrl + 'MaestroEquipment/GetModelcategoryMasterList')
            .toPromise().then(this.extractData).catch(this.handleError);
    }

    getModel(data): any {
        var dataToSend: any = { 'modelCategory': data };
        dataToSend = JSON.stringify(dataToSend);

        let userName: string = "{'modelCategory':'" + data + "'}";

        var headers = new Headers(), authtoken = localStorage.getItem('token');
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');

        var requestoptions = new RequestOptions({
            headers: headers
        });
        return this._http.get(environment.apiUrl + 'MaestroEquipment/GetModelmasterByModelCategory?strModelCategory=' + userName)
            .toPromise().then(this.extractData).catch(this.handleError);
    }

    getLifeHrsFromModel(model): any {

        var dataToSend: any = { 'Model': model };
        dataToSend = JSON.stringify(dataToSend);          
        
        return this._http.get(environment.apiUrl + 'MaestroEquipment/GetModelMasterByModel?Model=' + dataToSend)
            .toPromise().then(this.extractData).catch(this.handleError);

    }

    private extractData(res: Response) {
        return res;
    }

    private handleError(error: any): any {
        console.error('An error occurred', error);
    }


}

