import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {Http, Response, Headers, RequestOptions, Request, RequestMethod} from "@angular/http";
import { environment } from '../../environments/environment';
import { CommonUtil }  from './../common/common-util';
import { HttpClient } from '@angular/common/http';
import { AuthService } from "../interceptor/auth.service";

@Injectable()
export class OptionsComponentService {

    constructor(private _http: HttpClient, private commonUtil: CommonUtil, private authService: AuthService,) {
    }

    saveOptionsData(data): any {
       // data.push()              
        var headers = new Headers();
        this.commonUtil.displayNotification('Options' , 'saving' , '');  
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');
        headers.append("Authorization", 'Bearer ' + this.authService.getAuthToken());

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: data
        })      
       //  let customer: string = '{"ListMaestroSessionMetadata":[{"UserId":"' + localStorage.getItem("UserName") + '","SessionId":"Session","CurrentDate":"","ItemId":"Item"},{"UserId":"' + localStorage.getItem("UserName") + '","SessionId":"Session1","CurrentDate":"","ItemId":"Item1"}]}';
        return this._http.post(environment.apiUrl + 'MaestroEquipment/UpdateOptionCountry', requestoptions)
            .toPromise().then( () => {
                this.extractData;
                this.hideNotification('save');
            }).catch(this.handleError);
    }

    
    getOptionsData(): any {
        // data.push()              
         var headers = new Headers();
        // this.commonUtil.displayNotification('Options Data' , 'saving' , '');  
         headers.append("Content-Type", 'application/json');
         headers.append("charset", 'utf-8');
         headers.append("Authorization", 'Bearer ' + this.authService.getAuthToken());
         var data : any = {
            "UserName": localStorage.getItem("UserName") 
         };
         data = JSON.stringify(data);
 
         var requestoptions = new RequestOptions({
             method: RequestMethod.Post,
             headers: headers,
             body: data
         })      
        //  let customer: string = '{"ListMaestroSessionMetadata":[{"UserId":"' + localStorage.getItem("UserName") + '","SessionId":"Session","CurrentDate":"","ItemId":"Item"},{"UserId":"' + localStorage.getItem("UserName") + '","SessionId":"Session1","CurrentDate":"","ItemId":"Item1"}]}';
         return this._http.post(environment.apiUrl + 'MaestroEquipment/GetMaestroUserDetails', requestoptions)
             .toPromise().then(this.extractData).catch(this.handleError);
     }

    private extractData(res: Response) {        
		return res;
    }

    private handleError(error: any): any {		
        console.error('An error occurred', error);
    }

    hideNotification(str) {
        this.commonUtil.hideNotification();
        if(str === "delete"){
            this.commonUtil.displayNotification('' , 'deleteSuccess' , '');            
        } else {
            this.commonUtil.displayNotification('' , 'success' , '');            
        }               
    }
}

 