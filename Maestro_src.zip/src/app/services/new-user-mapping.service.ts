import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {Http, Response, Headers, RequestOptions, Request, RequestMethod} from "@angular/http";
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class NewUserMappingService {

    constructor(private _http: HttpClient) {
    }

    saveMaestroUsers(data: any): any {

        var headers = new Headers();
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');
        let dataToSave: string = '{' + JSON.stringify(data) + '}';

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: data
        })

        return this._http.post(environment.apiUrl + 'MaestroEquipment/SaveMaestroUsers', requestoptions)
            .toPromise().then(this.extractData).catch(this.handleError);
    }

    private extractData(res: Response) {

        return res;
    }

    private handleError(error: any): any {
        console.error('An error occurred', error);
    }

}
