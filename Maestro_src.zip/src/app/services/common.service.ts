import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { DataService } from './../services/data-component.service';
import { EqSelectedList } from './../services/eq-exclusions-class';
import { AppConstant } from './../app.constant';

@Injectable()
export class CommonService {

    private reportType = "";
    private reportFromInterval = "0";
    private reportToInterval = "0";
    private PriceListPriceType = "";


    // new report template related changes    
    private objMaintenancePartsForeCostsReportParameters = null;
    private selectedEquipment: EqSelectedList[];

    private generateReport = new BehaviorSubject<string>("default message");
    generateReportObservable$ = this.generateReport.asObservable();

    constructor(private dataService: DataService, private appConstant: AppConstant) {

    }

    getAzureADAuthenticationEnableFlagValue() {
        return this.appConstant.IsAzureADAuthenticationEnabled;
    }

    setReportType(type) {
        this.reportType = type;
    }

    getReportType() {
        return this.reportType;
    }

    setReportInterval(value, type) {
        if (type == 'to') {
            this.reportToInterval = value;
        } else {
            this.reportFromInterval = value;
        }
    }

    getReportInterval(type) {
        if (type == 'to') {
            return this.reportToInterval;
        } else {
            return this.reportFromInterval;
        }
    }

    generateReportHandler(type) {
        this.generateReport.next(type);
    }

    setPriceTypePriceListLabel() {
        //todo-country
        var price = this.dataService.getOptionsPriceType();
        var country = this.dataService.getActiveCountry();

        if (price != "N/A" && country != "N/A" &&
            price != "" && country != "" &&
            price != null && country != null) {
            /* if(price === 'MAPL') {
                 country = this.dataService.getOptions('maplDropdown');
             } else if(price === 'GLP') {
                 country = this.dataService.getOptions('glpDropdown');
             }     
             country = country.split('-')[2];*/
            this.PriceListPriceType = "Report will be generated for PriceType: " + price + " and PriceList: " + country;
        }
        else {
            this.PriceListPriceType = "";
        }

        return this.PriceListPriceType;
    }

    setMaintenancePartsForeCostsReportParameters(reportCostPerStrategy, reportExecutiveSummary, reportIntervalSummary,
        reportBOMDetails, reportInterest, reportFormat) {

        this.objMaintenancePartsForeCostsReportParameters = new MaintenancePartsForeCostsReportParameters(reportCostPerStrategy, reportExecutiveSummary, reportIntervalSummary,
            reportBOMDetails, reportInterest, reportFormat);
    }

    getMaintenancePartsForeCostsReportParameters() {
        return this.objMaintenancePartsForeCostsReportParameters;
    }

    setHTMLReportEquipmentDetails(sourceType, SerialNo, Model, priceType, country, priceList, fromHrs, toHrs,
        reportCostPerStrategy, reportExecutiveSummary, reportIntervalSummary, reportBOMDetails, reportInterest, reportFormat) {

        localStorage.setItem("htmlReportSelectedEquipment_SourceType", sourceType);
        localStorage.setItem("htmlReportSelectedEquipment_SerialNo", SerialNo);
        localStorage.setItem("htmlReportSelectedEquipment_Model", Model);
        localStorage.setItem("htmlReportSelectedEquipment_PriceType", priceType);
        localStorage.setItem("htmlReportSelectedEquipment_Country", country);
        localStorage.setItem("htmlReportSelectedEquipment_PriceList", priceList);
        localStorage.setItem("htmlReportSelectedEquipment_FromHrs", fromHrs);
        localStorage.setItem("htmlReportSelectedEquipment_ToHrs", toHrs);
        localStorage.setItem("htmlReportSelectedEquipment_ReportCostPerStrategy", reportCostPerStrategy);
        localStorage.setItem("htmlReportSelectedEquipment_ReportExecutiveSummary", reportExecutiveSummary);
        localStorage.setItem("htmlReportSelectedEquipment_ReportIntervalSummary", reportIntervalSummary);
        localStorage.setItem("htmlReportSelectedEquipment_ReportBOMDetails", reportBOMDetails);
        localStorage.setItem("htmlReportSelectedEquipment_ReportInterest", reportInterest);
        localStorage.setItem("htmlReportSelectedEquipment_ReportFormat", reportFormat);

    }

}

export class MaintenancePartsForeCostsReportParameters {
    reportCostPerStrategy: boolean;
    reportExecutiveSummary: boolean;
    reportIntervalSummary: boolean;
    reportBOMDetails: boolean;
    reportInterest: string;
    reportFormat: boolean;

    constructor(reportCostPerStrategy, reportExecutiveSummary, reportIntervalSummary,
        reportBOMDetails, reportInterest, reportFormat) {

        this.reportCostPerStrategy = reportCostPerStrategy;
        this.reportExecutiveSummary = reportExecutiveSummary;
        this.reportIntervalSummary = reportIntervalSummary;
        this.reportBOMDetails = reportBOMDetails;
        this.reportInterest = reportInterest;
        this.reportFormat = reportFormat;

        if (!reportExecutiveSummary && !reportIntervalSummary && !reportBOMDetails) {
            this.reportExecutiveSummary = true;
        }
    }
}
