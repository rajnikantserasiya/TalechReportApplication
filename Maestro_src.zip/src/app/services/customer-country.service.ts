import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {Http, Response, Headers, RequestOptions, Request, RequestMethod, URLSearchParams} from "@angular/http";
import { environment } from '../../environments/environment';
import { Subject }    from 'rxjs/Subject';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class CustomerCountryService {

  constructor(private _http: HttpClient) { }

    // Observable string sources
    private equipmentCountrySource = new Subject<string>();

    // Observable string streams
    equipmentCountry$ = this.equipmentCountrySource.asObservable();
    private selectedCountryNos: any;

    
  customerCountryData(): any {
  				
		let userCodeValue: string = "{'UserId':'" + localStorage.getItem("UserName") + "'}";
		
        return this._http.get(environment.apiUrl + 'MaestroEquipment/GetAllCustomerAndCountry?strUserName='+userCodeValue)
            .toPromise().then(this.extractData).catch(this.handleError);
    }
    
    // Service message commands
    selectCountry(numberOfEquipments: string) {
        this.selectedCountryNos = numberOfEquipments;
        this.equipmentCountrySource.next(numberOfEquipments);
    }

    getCountry(): any {
        return this.selectedCountryNos;
    }


	getCountryData(): any {        
		
		let userCodeValue: string =  "{'UserId':'" + localStorage.getItem("UserName") + "'}";

        return this._http.get(environment.apiUrl + 'MaestroEquipment/GetAllCustomerAndCountry?strUserName='+userCodeValue)
            .toPromise().then(this.extractData).catch(this.handleError);
    }

	 private extractData(res: Response) {
	         
		return res;
    }

    private handleError(error: any): any {
        console.error('An error occurred', error);
    }
}

