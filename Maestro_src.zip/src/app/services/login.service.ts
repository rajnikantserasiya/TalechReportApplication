import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {Http, Response, Headers, RequestOptions} from "@angular/http";
import { environment } from '../../environments/environment';
import { AuthService } from "../interceptor/auth.service";

@Injectable()
export class LoginService {

    constructor(private _http: Http, private authService: AuthService) {
    }

    authenticateUser(username: any, password: any): any {
        localStorage.setItem("UserName", username);        
        let usercreden: string = (username + ':' + password).toString();

        let headers = new Headers({ 'Authorization': 'Basic ' + usercreden });

        let options = new RequestOptions();
        options.headers = headers;

        return this._http.post(environment.authenticationUrl + 'Login', null, options)
            .toPromise().then( 	(res)  => 
								{
								this.extractData(res)
								}			
							 ).catch(this.handleError);

    }

	
    private extractData(res: Response ) {
		
        let body = res.json();        

        var beforeLoginTxt = (<HTMLInputElement>document.getElementById("beforeLogin"));

        beforeLoginTxt.style.display = 'none';
		
		this.authService.setAuthToken(body["UserSessionToken"]);        

        localStorage.setItem("userRole", body["UserRole"]);

        localStorage.setItem("userId", body["UserId"]);

        var closeLoginBtn = document.getElementById("closeLoginBtn");
        closeLoginBtn.click();
        
        var logoutBtn = (<HTMLInputElement>document.getElementById("logout-btn"));
        logoutBtn.style.display = 'block';

        var logInBtn = (<HTMLInputElement>document.getElementById("login-btn"));
        logInBtn.style.display = 'none';

        var welcomeUsrTxt = (<HTMLInputElement>document.getElementById("welcomeUsr"));

        welcomeUsrTxt.childNodes[1].textContent = localStorage.getItem("userId");

        welcomeUsrTxt.hidden = false;

        var slideOutDiv = (<HTMLInputElement>document.getElementById("slide-nav"));
        slideOutDiv.style.display = 'block';

        var openslideBtn = (<HTMLInputElement>document.getElementById("openslideBtn"));
        openslideBtn.style.display = 'block';

        var btnopenStartNewSession = (<HTMLInputElement>document.getElementById("btnopenStartNewSession"));
        var btnopenDialog = (<HTMLInputElement>document.getElementById("btnopenDialog"));
        var btnopenContinueExistingSession = (<HTMLInputElement>document.getElementById("btnopenContinueExistingSession"));

        btnopenStartNewSession.disabled = false;
        btnopenDialog.disabled = false;
        btnopenContinueExistingSession.disabled = false;

        var adminSlide = (<HTMLInputElement>document.getElementById("adminSlideId"));

        if (body["UserRole"] === "Admin") {
            adminSlide.style.display = 'block';
        }
        else
        {
            adminSlide.style.display = 'none';
        }


        return body || {};
    }

    private handleError(error: any): any {

        var slideOutDiv = (<HTMLInputElement>document.getElementById("error_login"));
        slideOutDiv.style.display = 'block';

        let body = error.json();
    }
}
