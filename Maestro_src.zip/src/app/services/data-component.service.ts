import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import {EqExclusionsList} from '../services/eq-exclusions-class';
import {EqSelectedList} from '../services/eq-exclusions-class';
import {EqFactorsList} from '../services/eq-exclusions-class';
import { Country_mm } from '../services/eq-exclusions-class';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import {SaveService } from '../services/save.service';
import {EqExclusionsServiceService} from '../services/eq-exclusions-service.service';
import { AdvancedSearchService } from './../services/advanced-search.service';
import {OptionsComponentService} from '../services/options-component.service';

@Injectable()
export class DataService {
    private messageSource = new BehaviorSubject<string>("default message");
    currentMessage = this.messageSource.asObservable();

    private eqSelectedSource = new BehaviorSubject<EqSelectedList[]>([]);
    currentEqSelectedMessage = this.eqSelectedSource.asObservable();

    private previewTabCachingSource = new BehaviorSubject<any>([]);
    previewTabCachingStream$ = this.previewTabCachingSource.asObservable();

    private selectedEquipment: EqSelectedList[] = [];
    private exclusionParentList: any = [];
    private exclusionParentListCopy: any = [];
    private exclusionList: any = [];
    private countryList: Country_mm[] = [];
    private euipmentsClicked: any = [];
    private factorsList: any = [];
    private previewList: any = [];
    private optionsCountryList: any = [];
    private previewSelectedEquipment: string = "";
    private previewSelected: string = "";
    private optionsPriceType: string = null;
    private equipSN: any = { "filterName": "", "filterValue": "" };
    private reports: any = { "partscon_reportInterval": 500, "partscon_colDropdown": "Engine Hours", "partscon_repFormat": "XLS", "contentRestrictionValue": "None", "costForcastSubTotalValue": "", "costForcastReportFormat": "", "engineHrsValue": "" };
    exclusionDataToSave: any = [];
    private importBomPreview: any = [];
    private adminimportBomPreview: any = [];
    private importedBomFileName: any = "";
    private AdminimportedBomFileName: any = "";
    private isTabDirty: boolean = false;
    private isModifiedModel: Object = { "tab-exclusion": false, "tab-preview": false, "tab-factors": false, "tab-options": false };
    private skipTabModel: Object = { "tab-exclusion": false, "tab-preview": false, "tab-factors": false, "tab-options": false };
    private skipTabChange: boolean = false;
    private options: any = { 'glpDropdown': null, 'maplDropdown': null, 'priceCountry': null, 'priceType': null };
    private importedBomModel: any = [];
    private viewImportModel: any = [];
    private adminviewImportModel: any = [];
    private activeTab: string = "";
    private editedSelectEquip: any = [];
    private activeFilters: any = [];
    private activeFiltersExclusion: any = [];
    private activeFiltersPreview: any = [];

    private ImportBOMmodifiedDataSet: any = [];

    constructor(private advancedSearchService: AdvancedSearchService, private fetchCurrentDataService: FetchCurrentDataService, private saveService: SaveService, private eqExclusionsServiceService: EqExclusionsServiceService, private optionsComponentService: OptionsComponentService) { }

    setEditSelectEquip(data) {
        this.editedSelectEquip = data;
    }

    getEditSelecEquip() {
        return this.editedSelectEquip;
    }
    setData(list: string, data: any, reset: boolean): void {
        let refererceToList = this.getReferenceForList(list, "", []);
        if (data instanceof Array) {
            if (reset) {
                refererceToList = data;
            } else {
                data.forEach(element => {
                    refererceToList.push(element);
                });
            }
        } else {
            if (reset) {
                refererceToList = [];
            } else {
                refererceToList.push(data);
            }
        }
        this.getReferenceForList(list, "setList", refererceToList);
    }

    getData(list: string): any {
        return this.getReferenceForList(list, "", []);
    }

    getReferenceForList(listName, action, data): any {
        let refererceToList: any = [];
        switch (listName) {
            case 'selectedEquipment':
                if (action === "setList") {
                    this.selectedEquipment = data;
                } else {
                    refererceToList = this.selectedEquipment;
                }
                break;

            case 'exclusionParentList':
                if (action === "setList") {
                    this.exclusionParentList = data;
                    this.exclusionParentListCopy = data;
                } else {
                    refererceToList = this.exclusionParentList;
                }
                break;

            case 'factorsRoot':
                if (action === "setList") {
                    this.factorsList = data;
                } else {
                    refererceToList = this.factorsList;
                }
                break;

            case 'countryList':
                if (action === "setList") {
                    this.countryList = data;
                } else {
                    refererceToList = this.countryList;
                }
                break;

            case 'euipmentsClicked':
                if (action === "setList") {
                    this.euipmentsClicked = data;
                } else {
                    refererceToList = this.euipmentsClicked;
                }
                break;

            case 'importBomPreview':
                if (action === "setList") {
                    this.importBomPreview = data;
                } else {
                    refererceToList = this.importBomPreview;
                }
                break;
            case 'adminimportBomPreview':
                if (action === "setList") {
                    this.adminimportBomPreview = data;
                } else {
                    refererceToList = this.adminimportBomPreview;
                }
                break;
            case 'activeFilters':
                if (action === "setList") {
                    this.activeFilters = data;
                } else {
                    refererceToList = this.activeFilters;
                }
                break;

            case 'optionsCountryList':
                if (action === "setList") {
                    this.optionsCountryList = data;
                } else {
                    refererceToList = this.optionsCountryList;
                }
                break;
        }
        return refererceToList;
    }

    clearReferenceForList(clearSelectEquip) {
        if (clearSelectEquip) {
            this.selectedEquipment = [];
            this.factorsList = [];
        }
        this.exclusionParentList = [];
        this.exclusionList = [];
        this.countryList = [];
        this.euipmentsClicked = [];
        //this.factorsList = [];
        this.previewList = [];
        this.previewSelectedEquipment = "";
        //this.optionsPriceType  = "GLP";
        this.previewSelected = "";
        this.reports['partscon_reportInterval'] = 500;
        this.reports['partscon_colDropdown'] = 'Engine Hours';
        this.reports['partscon_repFormat'] = 'XLS';
        this.reports['contentRestrictionValue'] = 'None';
        this.reports['costForcastSubTotalValue'] = '';
        this.reports['costForcastReportFormat'] = 'XLS';
        this.reports['engineHrsValue'] = '';
        this.importBomPreview = [];
        this.importedBomFileName = "";
        this.isModifiedModel['tab-exclusion'] = false;
        this.isModifiedModel['tab-preview'] = false;
        this.isModifiedModel['tab-factors'] = false;
        this.isModifiedModel['tab-options'] = false;
        this.skipTabModel['tab-exclusion'] = false;
        this.skipTabModel['tab-preview'] = false;
        this.skipTabModel['tab-factors'] = false;
        this.skipTabModel['tab-options'] = false;
        /*this.options['glpDropdown'] = null;
        this.options['maplDropdown'] = null;     */
        this.activeTab = "";
        this.activeFiltersExclusion = [];
        this.activeFiltersPreview = [];
        this.activeFilters = [];
    }

    clearOptionReferenceForList() {
        this.options['glpDropdown'] = null;
        this.options['maplDropdown'] = null;
    }

    clearScreenList(screenName: string) {
        switch (screenName) {
            case 'PreviewList':
                this.previewList = [];
                this.previewSelectedEquipment = "";
                this.previewSelected = "";
                this.isModifiedModel['tab-preview'] = false;
                this.activeFiltersPreview = [];
                break;

            case 'ExclusionList':
                this.exclusionParentList = [];
                this.exclusionList = [];
                this.activeFiltersExclusion = [];
                break;

            case 'All':
                this.clearReferenceForList(true);
                break;

            default: this.clearReferenceForList(true);
                break;
        }
    }

    changeMessage(message: string) {
        this.messageSource.next(message)
    }

    changeEqSelectedMessage(messageEqSelected: EqSelectedList[]) {
        this.eqSelectedSource.next(messageEqSelected);
    }

    updatePreviewCache(updateData: boolean) {
        this.previewTabCachingSource.next(updateData);
    }

    setEqExclusionsMaster(list) {
        var filteredTemp = this.exclusionList.filter(s => {
            return s["filterName"] === list["filterName"];
        });
        if (filteredTemp.length >= 1 && filteredTemp["filterValue"].length > 0) {
            this.exclusionList = this.exclusionList.filter(s => {
                return s["filterName"] != list["filterName"];
            });
        }
        this.exclusionList.push(list)
    }

    getEqExclusionsMaster(filterName, getAll) {
        if (getAll) {
            return this.exclusionList;
        } else {
            return this.exclusionList.filter(item => {
                return (item["filterName"] == filterName);
            });
        }
    }

    setPreviewList(list) {
        var filteredTemp = this.previewList.filter(s => {
            return s["filterName"] === list["filterName"];
        });
        if (filteredTemp.length >= 1 && filteredTemp[0]["filterValue"].length > 0) {
            this.previewList = this.previewList.filter(s => {
                return s["filterName"] != list["filterName"];
            });
        }
        else { // provide else condition to handle save after reset button issue
            this.previewList.push(list);
        }
    }

    getPreviewList(filterName, getAll) {
        if (getAll) {
            return this.previewList;
        } else {
            return this.previewList.filter(item => {
                return (item["filterName"] == filterName);
            });
        }
    }

    updatePreviewListValue(field, value, pth) {
        var selectedEquip = this.getPreviewSelected();
        this.previewList.forEach(item => {
            if (item["filterName"] === selectedEquip) {
                item["filterValue"].forEach(innerItem => {
                    if (innerItem["pth"] === pth) {
                        innerItem[field] = value;
                        // if(field != 'IsInclude'){
                        innerItem['isModified'] = true;
                        //}            
                    }
                });
            }
        });
    }

    setPreviewSelectedEquipment(str): void {
        this.previewSelectedEquipment = str;
    }

    getPreviewSelectedEquipment(): string {
        return this.previewSelectedEquipment;
    }

    setOptionsPriceType(str): void {
        this.optionsPriceType = str;
    }

    getOptionsPriceType(): string {
        return this.optionsPriceType;
    }

    setPreviewSelected(str): void {
        this.previewSelected = str;
    }

    getPreviewSelected(): string {
        return this.previewSelected;
    }


    updateCacheReference(data) {
        var previewObj = [{ filterName: "", filterValue: [] }];
        this.clearReferenceForList(true);
        data.forEach(item => {
            switch (item['filterName']) {
                case 'selectedEquipment':
                    this.selectedEquipment = item["filterValue"];
                    console.log(item['filterName']);
                    break;

                case 'options':
                    this.optionsPriceType = item["filterValue"][0]["price"];
                    this.setOptionsPriceType(this.optionsPriceType);
                    this.setOptions('glpDropdown', item["filterValue"][0]["glpDropdown"]);
                    this.setOptions('maplDropdown', item["filterValue"][0]["maplDrodown"]);

                    console.log(item['filterName']);
                    break;

                case 'exclusions':
                    this.exclusionParentList = item["filterValue"][0]["exclusionParentList"];
                    this.exclusionList = item["filterValue"][0]["exclusionList"];
                    console.log(item['filterName']);
                    break;

                case 'factorsRoot':
                    this.factorsList = item["filterValue"];
                    console.log(item['filterName']);
                    break;

                case 'previewRoot':
                    previewObj[0].filterValue = item["filterValue"];
                    console.log(item['filterName']);
                    break;

                case 'selectedSN':
                    console.log(item['filterName']);
                    break;

                case 'sessionDetails':
                    localStorage.setItem('token', item['filterValue'][0]['userSessionToken']);
                    localStorage.setItem('UserName', item['filterValue'][0]['user']);
                    localStorage.setItem('COUNTRY', item['filterValue'][0]['countryCode']);
                    console.log(item['filterName']);
                    break;

                case 'countryList':
                    this.countryList = item["filterValue"];
                    console.log(item['filterName']);
                    break;

                case 'previewSelectedEquipment':
                    this.previewSelectedEquipment = item["filterValue"];
                    console.log(item['filterName']);
                    break;

                case 'previewSelected':
                    previewObj[0].filterName = item["filterValue"];
                    this.previewSelected = item["filterValue"];
                    console.log(item['filterName']);
                    break;

                case 'reports':
                    this.reports = item["filterValue"];
                    break;

                case 'sessionDetails':
                    localStorage.setItem('token', item['filterValue'][0]['userSessionToken']);
                    localStorage.setItem('UserName', item['filterValue'][0]['user']);
                    localStorage.setItem('COUNTRY', item['filterValue'][0]['countryCode']);
                    console.log(item['filterName']);
                    break;

                case 'countryList':
                    this.countryList = item["filterValue"];
                    console.log(item['filterName']);
                    break;

                case 'previewSelectedEquipment':
                    this.previewSelectedEquipment = item["filterValue"];
                    console.log(item['filterName']);
                    break;

                case 'previewSelected':
                    previewObj[0].filterName = item["filterValue"];
                    this.previewSelected = item["filterValue"];
                    console.log(item['filterName']);
                    break;

                case 'partscon_reportInterval':
                    this.setReportsValue(item['filterName'], item['filterValue']);
                    console.log(item['filterName']);
                    break;

                case 'partscon_colDropdown':
                    this.setReportsValue(item['filterName'], item['filterValue']);
                    console.log(item['filterName']);
                    break;

                case 'partscon_repFormat':
                    this.setReportsValue(item['filterName'], item['filterValue']);
                    console.log(item['filterName']);
                    break;

                case 'contentRestrictionValue':
                    this.setReportsValue(item['filterName'], item['filterValue']);
                    console.log(item['filterName']);
                    break;

                case 'costForcastSubTotalValue':
                    this.setReportsValue(item['filterName'], item['filterValue']);
                    console.log(item['filterName']);
                    break;

                case 'costForcastReportFormat':
                    this.setReportsValue(item['filterName'], item['filterValue']);
                    console.log(item['filterName']);
                    break;

                case 'importBomPreview':
                    this.factorsList = item["filterValue"];
                    console.log(item['filterName']);
                    break;

                case 'activeFilters':
                    this.activeFilters = item["filterValue"];
                    console.log(item['filterName']);
                    break;

                default: break;
            }
        });
        this.previewList = previewObj;
    }

    saveSessionDetails(): void {
        var that = this;
        var cachedData = [];

        var activeFilters = this.getData('activeFilters') || [];

        if (this.selectedEquipment.length > 0) {
            var dataToSend = [];
            this.selectedEquipment.forEach(item => {
                dataToSend.push({ 'UserName': item['UserName'], 'EqSourceType': item['EqSourceType'], 'SerialNo': item['SerialNo'], 'Model': item['Model'], 'Quantity': item['Quantity'], 'HourFrom': item['HourFrom'], 'HourTo': item['HourTo'], 'MODELCATEGORY': item['MODELCATEGORY'], 'EQ_LIFE': item['EQ_LIFE'], 'HR_TYPE': item['HR_TYPE'], 'HrsYear1Boom': item['HrsYear1Boom'] });
            });
            this.saveService.saveMaestroSelectedEquipmentData(dataToSend).then(
                result => {
                    console.log('saved selected equipments');
                }
            )
                .catch(error => console.log(error));
        }

        if (this.previewList.length > 0) {
            var data = this.getPreviewList(this.getPreviewSelected(), false);
            if (data.length > 0) {
                this.eqExclusionsServiceService.saveMaestroPreviewData(data[0]["filterValue"], activeFilters).then(
                    result => {
                        console.log('saved preview data');
                    }
                )
                    .catch(error => console.log(error));
            }
        }

        if (this.factorsList.length > 0) {
            this.eqExclusionsServiceService.saveMaestroFactoreData(this.factorsList).then(
                result => {
                    console.log('saved factors data');
                })
                .catch(error => console.log(error));
        }

        if (this.exclusionList.length > 0) {
            this.exclusionDataToSave = [];
            this.exclusionList.forEach(item => {
                if (item["filterValue"] && item["filterValue"].length > 0) {
                    item["filterValue"].forEach(innerItem => {
                        if (innerItem.children && innerItem.children.length > 0) {
                            this.getExclusionDataInList(innerItem, false);
                        } else {
                            if (innerItem["IsInclude"] === "False" || !innerItem["IsInclude"]) {
                                this.exclusionList.push(innerItem);
                            }

                        }
                    });
                }
            });
            if (this.exclusionDataToSave.length > 0) {
                this.eqExclusionsServiceService.saveMaestroExclusionData(this.exclusionDataToSave, activeFilters).then(
                    result => {
                        console.log('saved exclusion data');
                    }
                )
                    .catch(error => console.log(error));
            }
        }

        if (this.getOptionsPriceType().length > 0) {
            var maplDropdown = this.getOptions('maplDropdown');
            var glpDropdown = this.getOptions('glpDropdown');
            var mapl;
            var glp;
            var maplPriceList;
            var glpPriceList;
            if (maplDropdown.indexOf('-') > 0) {
                mapl = maplDropdown.split('-')[1];
                maplPriceList = maplDropdown.split('-')[2];
            }
            if (glpDropdown.indexOf('-') > 0) {
                glp = glpDropdown.split('-')[1];
                glpPriceList = glpDropdown.split('-')[2];
            }

            var obj = [{ 'PriceType': this.getOptionsPriceType(), 'MAPLCountryCode': mapl, 'GLPCountryCode': glp, 'UserName': localStorage.getItem('UserName'), 'GLPPriceList': glpPriceList, 'MAPLPriceList': maplPriceList }];
            this.optionsComponentService.saveOptionsData(JSON.stringify(obj)).then(
                (response) => {
                    console.log('data saved');
                },
                (error) => {
                    console.log(error);
                },
                () => {
                    console.log('request completed');
                }
            )
        }
    }

    getExclusionDataInList(parent, flag) {
        var that = this;
        if (parent && parent.children) {
            for (var i = 0, l = parent.children.length; i < l; ++i) {
                var child = parent.children[i];
                child.index = i;
                if (child["IsInclude"] && child["IsInclude"] === "False") {
                    var indexNode = [];
                    var filteredTemp = this.exclusionDataToSave.filter(s => {
                        return s["Path"] === child["Path"];
                    });
                    if (filteredTemp.length >= 1) {
                        this.exclusionDataToSave = this.exclusionDataToSave.filter(s => {
                            return s["Path"] != child["Path"];
                        });
                    }
                    this.exclusionDataToSave.push(child);
                }
                this.getExclusionDataInList(child, flag);
            }
        }
    }

    setReportsValue(field, value) {
        this.reports[field] = value;
    }

    getReportsValue(field) {
        return this.reports[field];
    }


    setImportedBomFileName(value) {
        this.importedBomFileName = value;
    }

    getImportedBomFileName() {
        return this.importedBomFileName;
    }

    setAdminImportedBomFileName(value) {
        this.AdminimportedBomFileName = value;
    }

    getAdminImportedBomFileName() {
        return this.AdminimportedBomFileName;
    }

    getExclusionParentListCached() {
        return this.exclusionParentListCopy;
    }

    resetExclusionCacheList() {
        this.exclusionParentListCopy = [];
    }

    setIsTabDirty(flag) {
        this.isTabDirty = flag;
    }

    getIsTabDirty() {
        return this.isTabDirty;
    }

    setTabModified(tab, value) {
        this.isModifiedModel[tab] = value;
    }

    getTabModified(tab) {
        return this.isModifiedModel[tab];
    }

    setSkipTabChange(flag, screen) {
        if (screen === "all") {
            this.skipTabModel['tab-exclusion'] = flag;
            this.skipTabModel['tab-preview'] = flag;
            this.skipTabModel['tab-factors'] = flag;
            this.skipTabModel['tab-options'] = flag;
        } else {
            this.skipTabModel[screen] = flag;
            if (screen === "tab-exclusion" || screen === "tab-preview") {
                //this.setData("activeFilters", [], true);
            }
        }
    }

    getSkipTabChange(screen) {
        return this.skipTabModel[screen];
    }

    setOptions(field, value) {
        this.options[field] = value;
    }

    getOptions(field) {
        return this.options[field];
    }

    setImportedBomModel(data) {
        this.importedBomModel = data;
    }

    getImportedBomModel() {
        return this.importedBomModel;
    }

    setViewBomModel(data) {
        this.viewImportModel = data;
    }

    getViewBomModel() {
        return this.viewImportModel;
    }

    setAdminViewBomModel(data) {
        this.adminviewImportModel = data;
    }

    getAdminViewBomModel() {
        return this.adminviewImportModel;
    }

    setActiveTab(tab) {
        this.activeTab = tab;
    }

    getActiveTab() {
        return this.activeTab;
    }


    getCountryFromCode(countryCode) {
        var countryList = this.getData('optionsCountryList');
        var country = "";
        countryList.forEach(item => {
            if (item['CountryCode'] === countryCode) {
                country = item['CountryName'];
                console.log(country);
            }
        });
        return country;
    }


    getActiveCountry() {
        var price = this.getOptionsPriceType();
        var CountryCode;
        var selectedValue;
        if (price === 'GLP') {
            selectedValue = this.getOptions('glpDropdown');
            CountryCode = selectedValue.split('-')[1];
        }
        else {
            selectedValue = this.getOptions('maplDropdown');
            CountryCode = selectedValue.split('-')[1];
        }
        return this.getCountryFromCode(CountryCode);
    }


    getActivePriceList() {
        var price = this.getOptionsPriceType();
        var priceList;
        var selectedValue;
        if (price === 'GLP') {
            selectedValue = this.getOptions('glpDropdown');
            priceList = selectedValue.split('-')[2];
        }
        else {
            selectedValue = this.getOptions('maplDropdown');
            priceList = selectedValue.split('-')[2];
        }
        return priceList;
    }

    getPriceListFromCountryAndPriceType(priceType, countryCode) {
        var countryList = this.getData('optionsCountryList');
        var priceList = "";
        countryList.forEach(item => {
            if (item['ListType'] + '-' + item['CountryCode'] === priceType + '-' + countryCode) {
                priceList = item['PriceList'];
                console.log(priceList);
            }
        });
        return priceList;
    }

    clearOptionsData() {
        this.options = { 'glpDropdown': null, 'maplDropdown': null, 'priceCountry': null, 'priceType': null };
        this.optionsPriceType = "";
    }


    setImportedBomModifiedDataset(value) {
        this.ImportBOMmodifiedDataSet = value;
    }

    getImportedBomModifiedDataset() {
        return this.ImportBOMmodifiedDataSet;
    }

}



