import { Injectable } from '@angular/core';

@Injectable()
export class PaginationService {
    private currentPage = 1;
    private totalCount = 0;
    private recordsPerPage = 25;
    private totalNumberOfPages = 0;
    private pagesToDisplay = 5;
   
    setCurrentPage(pageNumber): void {
        this.currentPage = pageNumber;
    }

    getCurrentPage(): number {
        return this.currentPage; 
    }

    setTotalNumberOfPages():void {
        this.totalNumberOfPages  = Math.ceil(this.totalCount/this.recordsPerPage);
    }

    setTotalCount(count) : void {
        this.totalCount = count;      
    }

    getTotalCount() : number {
        return this.totalCount;
    }

    getTotalNumberOfPages():number {
        return this.totalNumberOfPages;
    }

    setRecordsPerPage(recordLimit) : void {
        this.recordsPerPage = recordLimit;
    }
    
    getRecordsPerPage() : number {
        return this.recordsPerPage;
    }

    getPagesToDisplay() : number {
        return this.pagesToDisplay;
    }
}
