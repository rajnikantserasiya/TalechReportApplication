import { Component, OnInit } from '@angular/core';
import {AccordionModule} from 'primeng/accordion';
import { AuthService } from "../interceptor/auth.service";
import { HttpClient } from '@angular/common/http';
import {Http, Response, Headers, RequestOptions, Request, RequestMethod} from "@angular/http";
import { environment } from '../../environments/environment';
import { LoaderService } from '../services/loader.service';
declare var jquery: any;
declare var $: any;

@Component({
    selector: 'app-cost-forecast-report-html-format',
    templateUrl: './cost-forecast-report-html-format.component.html',
    styleUrls: ['./cost-forecast-report-html-format.component.css'],
    providers: [AccordionModule]
})
export class CostForecastReportHtmlFormatComponent implements OnInit {

    IsPrintClicked = false;
    toggleChecked: boolean = false;
    ModelCategory: string = '';
    Model: string = '';
    Equipment: string = '';
    dtBOMDetails = [];
    BOMDetailsHTMLStructure = '';

    //Executive summary section
    DateField = '';
    Author = '';
    Pricing = '';
    FromHrs = '';
    ToHrs = '';
    TotalItems = '';
    TotalPrice = '';
    Equipment_SN = '';
    Equipment_Model = '';
    Qty = '';
    Excludes = '';

    //Excluded
    dtExcludedItems = [];

    // visible tab properties
    tabBOMDetails = false;
    tabExecutiveSummary = false;

    constructor(private _http: HttpClient, private loaderService: LoaderService) { }

    ngOnInit() {
        this.costForecastInHTMLFormat();
    }

    trackByIndex(index: number, value: number) {
        return index;
    }

    PrintPreviewmodeMethod() {
        //alert("Preview mode called");
        this.IsPrintClicked = !this.IsPrintClicked;
        //this.toggleChecked = !this.toggleChecked;
    }

    costForecastInHTMLFormat() {

        this.loaderService.display(true);

        var username = localStorage.getItem("UserName");
        var eqSourceType = localStorage.getItem("htmlReportSelectedEquipment_SourceType");
        var SerialNo = localStorage.getItem("htmlReportSelectedEquipment_SerialNo");
        var Model = localStorage.getItem("htmlReportSelectedEquipment_Model");
        var FromHrs = localStorage.getItem("htmlReportSelectedEquipment_FromHrs");
        var ToHrs = localStorage.getItem("htmlReportSelectedEquipment_ToHrs");
        var ReportIntervalTxt = localStorage.getItem("ReportIntervalTxt");
        var ReportHrsType = localStorage.getItem("ReportHrsType");
        var ApplyAlignment = localStorage.getItem("ApplyAlignment");
        var ApplySuppression = localStorage.getItem("ApplySuppression");
        var ReportFilter = localStorage.getItem("ReportFilter");
        var PriceListType = localStorage.getItem("PriceListType");
        var PriceList = localStorage.getItem("PriceList");
        var reportCostPerStrategy = localStorage.getItem("htmlReportSelectedEquipment_ReportCostPerStrategy");
        var reportExecutiveSummary = localStorage.getItem("htmlReportSelectedEquipment_ReportExecutiveSummary");
        var reportIntervalSummary = localStorage.getItem("htmlReportSelectedEquipment_ReportIntervalSummary");
        var reportBOMDetails = localStorage.getItem("htmlReportSelectedEquipment_ReportBOMDetails");
        var reportInterest = localStorage.getItem("htmlReportSelectedEquipment_ReportInterest");
        var reportFormat = localStorage.getItem("htmlReportSelectedEquipment_ReportFormat");
        var PriceListCountry = localStorage.getItem("htmlReportSelectedEquipment_Country");

        if (reportExecutiveSummary == "true") {
            this.tabExecutiveSummary = true
        }

        if (reportBOMDetails == "true") {
            this.tabBOMDetails = true
        }

        let reportOption: string =
            '{"UserName":"' + username +
            '","EqSourceType":"' + eqSourceType +
            //'","SerialNo":"' + SerialNo +
            //'","Model":"' + Model +
            '","Model_SerialNo":"' + Model + SerialNo +
            '","HoursFrom":"' + FromHrs +
            '","HoursTo":"' + ToHrs +
            '","Interval":"' + ReportIntervalTxt +
            '","ReportHrsType":"' + ReportHrsType +
            '","ApplyAlignment":"' + ApplyAlignment +
            '","ApplySuppression":"' + ApplySuppression +
            '","FilterType":"' + ReportFilter +
            '","PriceType":"' + PriceListType +
            '","PriceList":"' + PriceList +
            '","PriceListCountry":"' + PriceListCountry +
            '","reportCostPerStrategy":"' + reportCostPerStrategy +
            '","reportExecutiveSummary":"' + reportExecutiveSummary +
            '","reportIntervalSummary":"' + reportIntervalSummary +
            '","reportBOMDetails":"' + reportBOMDetails +
            '","reportInterest":"' + reportInterest +
            '","reportFormat":"' + reportFormat +
            '"}';

        //let dataTosend: string = JSON.stringify(reportOption);

        var headers = new Headers();
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: reportOption
        });

        return this._http.post(environment.apiUrl + 'MaestroReport/CostForecastInHTMLFormat', requestoptions)
            .toPromise().then(result => {

                var CPHReportdata = JSON.parse(JSON.stringify(result));

                // Executive Summary section
                this.DateField = CPHReportdata.objExecutiveSummary.Date;
                this.Author = CPHReportdata.objExecutiveSummary.Author;
                this.Pricing = CPHReportdata.objExecutiveSummary.Pricing;
                this.FromHrs = CPHReportdata.objExecutiveSummary.From;
                this.ToHrs = CPHReportdata.objExecutiveSummary.To;
                this.TotalItems = CPHReportdata.objExecutiveSummary.TotalItems;
                this.TotalPrice = CPHReportdata.objExecutiveSummary.TotalPrice;
                this.Equipment_SN = CPHReportdata.objExecutiveSummary.Equipment;
                this.Equipment_Model = CPHReportdata.objExecutiveSummary.Model;
                this.Qty = CPHReportdata.objExecutiveSummary.Qty;
                this.Excludes = CPHReportdata.objExecutiveSummary.Excludes;

                //Excluded section
                this.dtExcludedItems = CPHReportdata.objExcludeItemsSummary.dtExcludedItems;

                //BOM Details section
                var dtBOMDetails = CPHReportdata.objBOMDetailsSummary.dtBOMDetails;
                this.ModelCategory = CPHReportdata.objBOMDetailsSummary.modelCategory;
                this.Model = CPHReportdata.objBOMDetailsSummary.model;
                this.Equipment = CPHReportdata.objBOMDetailsSummary.equipment;
                var colNames = CPHReportdata.objBOMDetailsSummary.lstIntervalCols;
                var classname = '';

                if (dtBOMDetails != null && dtBOMDetails.length > 0) {

                    for (let i = 0; i < dtBOMDetails.length; i++) {

                        var Item = dtBOMDetails[i].PartId;
                        var Description = dtBOMDetails[i].Description;
                        var UnitPrice = (dtBOMDetails[i].UnitPrice == null) ? "" : this.Customround(dtBOMDetails[i].UnitPrice.toFixed(2));
                        var DuringQty = (dtBOMDetails[i].DuringQty == null) ? "" : this.Customround(dtBOMDetails[i].DuringQty.toFixed(2));
                        var DuringTotalPrice = (dtBOMDetails[i].DuringTotalPrice == null) ? "" : this.Customround(dtBOMDetails[i].DuringTotalPrice.toFixed(2));
                        var GrandTotal = (dtBOMDetails[i].GrandTotal == null) ? "" : this.Customround(dtBOMDetails[i].GrandTotal.toFixed(2));
                        var REC = dtBOMDetails[i].REC;

                        if (i == 0) {
                            classname = '';
                        }
                        else if (i == 1) {
                            classname = 'trBackGround';
                        }
                        else if (i % 2 == 0) {
                            classname = '';
                        }
                        else {
                            classname = 'trBackGround';
                        }

                        this.BOMDetailsHTMLStructure +=
                            ' <tr class="' + classname + '">' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + Item + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + Description + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + UnitPrice + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + DuringQty + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + DuringTotalPrice + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + GrandTotal + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + REC + ' </td>' +
                            ' </tr>';
                    }

                    $(".tabRow").append(this.BOMDetailsHTMLStructure);
                    this.BOMDetailsHTMLStructure = "";
                    //console.log(this.BOMDetailsHTMLStructure);

                }
                else {
                    this.BOMDetailsHTMLStructure =
                        ' <tr>' +
                        ' <td class="noRecordFound" align= "center" colspan="7"> No record found for specific equipment. </td>' +
                        ' </tr>';
                    $(".tabRow").append(this.BOMDetailsHTMLStructure);
                    this.BOMDetailsHTMLStructure = "";
                }

                this.loaderService.display(false);

            }).catch(this.handleError);


    }

    Customround(num) {
        var arrNum = num.toString().split('.');
        if (arrNum != null && arrNum.length == 2) {            
            if (arrNum[1] == "00" || arrNum[1] == "0") {
                return arrNum[0];
            }
        }

        return num;
    }

    private extractData(res: Response) {
        return res;
    }

    private handleError(error: any): any {
        console.error('An error occurred', error);
    }

}
