import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CostForecastReportHtmlFormatComponent } from './cost-forecast-report-html-format.component';

describe('CostForecastReportHtmlFormatComponent', () => {
  let component: CostForecastReportHtmlFormatComponent;
  let fixture: ComponentFixture<CostForecastReportHtmlFormatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CostForecastReportHtmlFormatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CostForecastReportHtmlFormatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
