import { Component, OnInit, Injectable } from '@angular/core';
import { NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

@Component({
    selector: 'app-common-message-popup',
    templateUrl: './common-message-popup.component.html',
    styleUrls: ['./common-message-popup.component.css']
})
export class CommonMessagePopupComponent implements OnInit {

    constructor(public activeModal: NgbActiveModal) { }

    ngOnInit() {
    }

    close() {
        this.activeModal.dismiss(true);
    }

}

@Injectable() export class CommonMessagePopupService {

    constructor(private modalService: NgbModal) { }

    public show() {
        const modalRef = this.modalService.open(CommonMessagePopupComponent);
        modalRef.componentInstance.name = "showcommonmessagepopup";
        modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }
}
