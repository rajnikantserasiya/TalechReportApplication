import { Injectable } from '@angular/core';
declare var PNotify: any;

@Injectable()
export class CommonUtil{
      
    checkSpecialRegex(str , isDecimalAllowed , isAlphanumericAllowed){
        var format : RegExp = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
        if(isDecimalAllowed){
            format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,<>\/?]+/;  
        }                 
        if(!isAlphanumericAllowed && isNaN(str)){
            return true;
        }
        else {
            return format.test(str);
        }                    
    }

    displayNotification(screen, type, message) {
        //debugger;
        var text = 'Saving &nbsp;Data';
        var type;
        var  delay = 60000;
        if(type == 'saving') {
            text = 'Saving&nbsp;'+screen+'&nbsp;Data';
        } else if( type == 'deleting') {
            text = 'Deleting&nbsp'+screen+'&nbsp;Data';
        } else if( type == 'success') {
            text = 'Data Saved Successfully',
            type = 'success';
            delay = 1000;
        } else if( type == 'deleteSuccess') {
            text = 'Data Deleted Successfully',
            type = 'success';
            delay = 1000;
        }
        else if( type == 'error') {
            text = 'Error in Saving Data',
            type = 'error';
            delay = 1000;
        } 
        PNotify.prototype.options.styling = "fontawesome";
        PNotify.prototype.options.stack.firstpos2 = 250;
        // UI Changes (Changed width to 500 from 300
        new PNotify({
            text: text,
            delay: delay,
            width: 500,
            type : type
        });      
    }

    hideNotification() {
        PNotify.removeAll();        
    }
}
