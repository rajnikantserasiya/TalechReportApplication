import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';
import {LoadBomModalService} from '../import-bom-popup/import-bom-popup.component';
import {PaginationPipe} from '../pipes/pagination.pipe';
import {SelectEquipmentOtherService}  from '../services/select-equipment-other.service';
import { DataService } from './../services/data-component.service';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { AppConstant } from './../app.constant';
import { AddImportBomService } from '../add-import-bom/add-import-bom.component';
import { LoaderService } from './../services/loader.service';
declare var PNotify: any;

@Component({
    selector: 'app-select-equipment-exist-bom',
    templateUrl: './select-equipment-exist-bom.component.html',
    providers: [SelectEquipmentOtherService, AddImportBomService]
})
export class SelectEquipmentExistBOMComponent implements OnInit {

    data: any;
    columns: any = [];
    modifiedDataSet: any = [];
    mappedJson: any = [];
    modelCategory: string = "";
    formModel: any = { 'modelCategory': 'select', 'model': 'select', 'serialNumber': 'select', 'level': 'select', 'parentId': 'select', 'parentDescription': 'select', 'item': 'select', 'itemDescription': 'select', 'quantity': 'select', 'lifeHours': 'select' };
    displayData: boolean = false;
    fileName: "";
    displayFileName: boolean = false;
    pagingConfig = { "startIndex": 1, "endIndex": 5, "itemsPerPage": 10, "action": "refresh" };
    totalCount: number = 0;
    mappedJsonOriginal: any = [];
    viewData: any = [];

    constructor(private loadBomModalService: LoadBomModalService, private selectEquipmentOtherService: SelectEquipmentOtherService, private dataService: DataService, private appConstant: AppConstant, private fetchCurrentDataService: FetchCurrentDataService, private addImportBomService: AddImportBomService, private loaderService: LoaderService) {
        this.fetchCurrentDataService.screenDataStream$.subscribe(
            () => {               
                if (!this.fetchCurrentDataService.disableFlagSaveImportBom) {                    
                    var importBomPreviewData: any = [];
                    var fileName = this.dataService.getImportedBomFileName();
                    this.fetchCurrentDataService.disableFlagSaveImportBom = true;
                    if (this.dataService.getData(this.appConstant.importBomPreview).length > 0) {
                        importBomPreviewData = this.dataService.getData(this.appConstant.importBomPreview);
                    }
                    if (importBomPreviewData && importBomPreviewData.length > 0) {
                        this.mappedJson = importBomPreviewData;
                        this.fetchCurrentDataService.createJsonToSave(importBomPreviewData, this.appConstant.importBomPreview);
                        this.fetchCurrentDataService.createJsonToSave(fileName, this.appConstant.importBomPreviewFileName);
                        // this.saveData();
                    }
                }
            });

        this.loadBomModalService.onOkClickStream$.subscribe(
            (data) => {
                if (data) {
                    this.formModel = data;
                    this.onOkClick();
                }
            });
        this.fetchCurrentDataService.addImportedBomStream$.subscribe(
            (data) => {
                if (!this.fetchCurrentDataService.disableFlagImportBomPopUp && data) {
                    this.fetchCurrentDataService.disableFlagImportBomPopUp = true;
                    this.saveData(data);
                }
            });


    }

    ngOnInit() {
        
        // UI Changes
        document.getElementById("slide-nav").style.width = "0";
        var viewBomData = [];
        if (this.dataService.getImportedBomFileName().length > 0) {
            debugger;        
            this.fileName = this.dataService.getImportedBomFileName();
            this.mappedJsonOriginal = this.dataService.getData('importBomPreview');
            this.mappedJson = JSON.parse(JSON.stringify(this.mappedJsonOriginal));
            this.totalCount = this.mappedJson.length;
            this.displayFileName = true;
        }
        viewBomData = this.dataService.getViewBomModel();
        if (viewBomData.length > 0) {
            this.viewData = this.dataService.getViewBomModel();
        }
    }

    ngOnDestroy() {
        this.mappedJson = [];
        this.data = [];
    }

    onFileChange(evt: any) {       

        /* wire up file reader */
        const target: DataTransfer = <DataTransfer>(evt.target);
        var fileName = "";
        if (evt.target.files[0]["name"]) {
            this.fileName = evt.target.files[0]["name"];
            fileName = this.fileName;
            this.dataService.setImportedBomFileName(this.fileName);
        }
        if (fileName.indexOf('xls') > 0 || fileName.indexOf('xlsx') > 0) {
            if (target.files.length !== 1) throw new Error('Cannot use multiple files');
            const reader: FileReader = new FileReader();
            reader.onload = (e: any) => {
                /* read workbook */
                const bstr: string = e.target.result;
                const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

                /* grab first sheet -  considering single sheet scenario currently*/
                const wsname: string = wb.SheetNames[0];
                const ws: XLSX.WorkSheet = wb.Sheets[wsname];
            
                /* save data */
                this.data = (XLSX.utils.sheet_to_json(ws, { header: 1 }));
                this.updateData();
            };
            reader.readAsBinaryString(target.files[0]);
        } else {
            alert('Please Select valid file format');
        }
    }

    updateData() {

       
        this.clearPreviousData();
        this.loadBomModalService.setColumns([]);
        var obj = [];
        var intervalStartIndex = -1;
        let json = [];
        var array = [];
        this.columns = [];

        this.data[0].forEach(item => {
            if (isNaN(item)) {
                this.columns.push(item);
                obj.push({ "filterName": item, "filterValue": [] });
            }
        });
        intervalStartIndex = obj.length;
        for (var i = 1; i < this.data.length; i++) {
            var tempArray = this.data[i];
            var objTemp = {};
            for (var j = 0; j < intervalStartIndex; j++) {
                objTemp[obj[j]["filterName"]] = tempArray[j];
            }
            json.push(objTemp);
        }
        array = this.columns;
        this.columns = array.filter(function (item, pos) {
            return array.indexOf(item) == pos;
        })       

        debugger;
        //this.modifiedDataSet = [];
        this.dataService.setImportedBomModifiedDataset(json);
        //this.modifiedDataSet = json;
        this.loadBomModalService.setColumns(this.columns);
        this.loadBomModalService.show();
    }

    onCheckBoxModelChange(data, value) {
        data['checked'] = value;
    }

    onOkClick() {
        debugger;        
        var obj = [];
        var dsModified = this.dataService.getImportedBomModifiedDataset();

        //obj = this.modifiedDataSet.map(item => <any>{
        obj = dsModified.map(item => <any>{
            'UserName': localStorage.getItem("UserName"),
            'IsInclude': true,
            'modelCategory': this.formModel['modelCategory'],
            'model': this.formModel['model'],
            'serialNumber': item[this.formModel['serialNumber']],
            'level': item[this.formModel['level']],
            'parentId': item[this.formModel['parentId']],
            'parentDescription': item[this.formModel['parentDescription']],
            'item': item[this.formModel['item']],
            'itemDescription': item[this.formModel['itemDescription']],
            'quantity': item[this.formModel['quantity']],
            'lifeHours': item[this.formModel['lifeHours']]
        });
        this.mappedJson = [];
        this.mappedJson = obj;
        this.mappedJsonOriginal = JSON.parse(JSON.stringify(obj));
        this.dataService.setData('importBomPreview', obj, true);
        this.loadBomModalService.setColumns(this.columns);
        this.displayFileName = true;
        this.totalCount = obj.length;
        
        if (this.mappedJson.length > 0) {
            this.viewData.push(this.mappedJson[0]);
            this.viewData.forEach(item => {
                item['checked'] = false;
            });
        }
        this.dataService.setViewBomModel(this.viewData);
    }

    onReset() {
        this.loadBomModalService.setColumns(this.columns);
        this.loadBomModalService.show();
        this.formModel = { 'modelCategory': 'select', 'model': 'select', 'serialNumber': 'select', 'level': 'select', 'parentId': 'select', 'parentDescription': 'select', 'item': 'select', 'itemDescription': 'select', 'quantity': 'select', 'lifeHours': 'select' };
        this.mappedJson = [];
    }

    refreshData(configData): void {
        console.log("Recieved Data from  paging component" + JSON.stringify(configData));
        this.pagingConfig = configData;
    }

    saveData(data) {
        //http call starts
       
        //http call ends
        //this.loaderService.display(true);

        PNotify.prototype.options.styling = "fontawesome";
        PNotify.prototype.options.stack.firstpos2 = 250;
        // UI Changes (Changed width to 500 from 300
        new PNotify({
            text: 'Saving Data',
            delay: 50000,
            width: 500
        });

        debugger;
        //var popUpModelData = this.dataService.getImportedBomModel();
        if (this.mappedJson.length > 0) {
            this.selectEquipmentOtherService.saveManuallyImportedMachine(this.mappedJson, this.formModel, data)            
                .then(result => {
                    //this.loaderService.display(false);

                    if (result == "False") {
                        this.saveSuccessHandler("Error while saving data into database", "error");
                    }
                    else {                         
                        var addSelectedEpqBtn = document.getElementById("addSelectedEpqBtn");
                        //console.log(result);
                        this.data = [];                       
                        this.clearPreviousData();
                        this.loadBomModalService.setColumns([]);
                        this.dataService.clearReferenceForList(true);
                        this.dataService.setImportedBomModel([]);
                        this.viewData = [];
                        addSelectedEpqBtn.click();
                        this.fetchCurrentDataService.disableFlagImportBomPopUp = false;
                        this.saveSuccessHandler("Data Saved Successfully", "success");

                    }
                })
                .catch(error => console.log(error));
        }
    }

    saveSuccessHandler(msg, messageType) {
        PNotify.removeAll();
        PNotify.prototype.options.styling = "fontawesome";
        PNotify.prototype.options.stack.firstpos2 = 250;

        new PNotify({
            //text: 'Data Saved Successfully',
            text: msg,
            delay: 3000,
            width: 2000,
            //type: 'success'
            type: messageType
        });
    }

    showPopUp() {      
        //extract model values from the list
        var model = [];
        this.viewData.forEach(item => {
            item['checked'] = false;
        });
        this.mappedJson.forEach(item => {
            model.push(item['model']);
        });
        this.dataService.setImportedBomModel(model);
        
        if (this.mappedJson != '' || this.mappedJson.length > 0) {
            localStorage.setItem("SelectedMODELValue_Import", this.mappedJson[0]['model']);
            localStorage.setItem("selectedMODELCATEGORY_Import", this.mappedJson[0]['modelCategory']);
            this.addImportBomService.show();
        }
    }

    onModelChange(equip, value) {
        equip['checked'] = value;
        if (value) {
            console.log('add');
        }
    }

    disableAdd() {
        var count: number = 0;
        this.viewData.forEach(item => {
            if (item['checked']) {
                count++;
            }
        })
        return count == 0;
    }

    clearPreviousData() {
        this.viewData = [];
        this.mappedJson = [];
        this.mappedJsonOriginal = [];
        this.dataService.setData('importBomPreview', [], true);
        this.dataService.setViewBomModel([]);        
    }

}
