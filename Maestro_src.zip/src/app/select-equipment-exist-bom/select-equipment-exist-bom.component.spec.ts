import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectEquipmentExistBOMComponent } from './select-equipment-exist-bom.component';

describe('SelectEquipmentExistBOMComponent', () => {
  let component: SelectEquipmentExistBOMComponent;
  let fixture: ComponentFixture<SelectEquipmentExistBOMComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectEquipmentExistBOMComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectEquipmentExistBOMComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
