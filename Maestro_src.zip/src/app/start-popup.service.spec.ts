import { TestBed, inject } from '@angular/core/testing';

import { StartPopupService } from './start-popup.service';

describe('StartPopupService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [StartPopupService]
    });
  });

  it('should be created', inject([StartPopupService], (service: StartPopupService) => {
    expect(service).toBeTruthy();
  }));
});
