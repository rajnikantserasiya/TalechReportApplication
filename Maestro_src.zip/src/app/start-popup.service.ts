import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {Http, Response, Headers, RequestOptions} from "@angular/http";
import {Observable} from "rxjs/Rx";

@Injectable()
export class StartPopupService {
    public test: string = "";

    constructor(private _http:Http){ 
    }
    
    saveProfile():any{
	    let customer:string='{"ListMaestroSessionMetadata":[{"UserId":"Test","SessionId":"Session","CurrentDate":"","ItemId":"Item"},{"UserId":"Test","SessionId":"Session1","CurrentDate":"","ItemId":"Item1"}]}';
        return this._http.post('https://maestroapi23012018test.azurewebsites.net/api/v1.0/MaestroSession/SaveMaestroSessionMetadata?objMaestroSessionMetadata=' + customer, customer)
            .toPromise().then(this.extractData).catch(this.handleError);	
    }

    private extractData(res: Response) {
      let body = res.json();
      return body || {};
    }

    private handleError(error: any): any {
      console.error('An error occurred', error);
    }
}