import { Component,HostListener, HostBinding, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable,ElementRef } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import { SaveService } from '../services/save.service';
import { NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { SelectEquipmentSelectedComponent } from '../select-equipment-selected/select-equipment-selected.component';
import { DataService } from './../services/data-component.service';
import { AppConstant } from './../app.constant';
import { CommonUtil }  from './../common/common-util';

@Component({
  selector: 'app-add-popup',
  templateUrl: './add-popup.component.html',
  styleUrls: ['./add-popup.component.css'],
  providers: [SelectEquipmentSelectedComponent]
})
export class AddPopupComponent implements OnInit {
    selectedItemsValues: eqSelectedClass[] = [];
    max: Number = 7;
    maxQty: Number = 2;

    constructor(public eRef : ElementRef , public activeModal: NgbActiveModal, public changeRef: ChangeDetectorRef, private saveService: SaveService, private selectEquipmentSelectedComponent: SelectEquipmentSelectedComponent , private dataService : DataService , private appConstant : AppConstant , public commonUtil : CommonUtil) {
    }

    @HostListener('document:paste', ['$event'])
   
    onGlobalPaste(event) {
        console.log('global', event);
    }
    
    onLocalPaste(event  , str , data ) {
        switch(str){
            case 'addQuantity':
            if(this.commonUtil.checkSpecialRegex(event.target.value , true , false)){
              
            }  
            break;
        }
        console.log('local', event);
    }

    public restrictNumeric(e) {
        var key = e.keyCode ? e.keyCode : e.which;
        if (!([8, 9, 13, 27, 110, 190].indexOf(key) !== -1 ||
            (key == 65 && (e.ctrlKey || e.metaKey)) ||
            (key >= 35 && key <= 40) ||
            (key == 43 && key == 45) ||
            (key >= 48 && key <= 57 && !(e.shiftKey || e.altKey)) ||
            (key >= 96 && key <= 105)
        )) e.preventDefault();

        if (e.target.value.length >= this.max) e.preventDefault();
    }

    public restrictQtyNumeric(e) {
        var key = e.keyCode ? e.keyCode : e.which;
        if (!([8, 9, 13, 27, 110, 190].indexOf(key) !== -1 ||
            (key == 65 && (e.ctrlKey || e.metaKey)) ||
            (key >= 35 && key <= 40) ||
            (key == 43 && key == 45) ||
            (key >= 48 && key <= 57 && !(e.shiftKey || e.altKey)) ||
            (key >= 96 && key <= 105)
        )) e.preventDefault();

        if (e.target.value.length >= this.maxQty) e.preventDefault();
    }

    public restrictZero(e) {
        var key = e.keyCode ? e.keyCode : e.which;
        if (e.target.value == '' || e.target.value == "0" || e.target.value.length > this.max)
        { e.target.value = 1 };
    }

    public restrictQty(e) {       
        var key = e.keyCode ? e.keyCode : e.which;
        if (e.target.value == '' || e.target.value == "0" || e.target.value.length > this.maxQty)
        { e.target.value = 1 };
    }

    

    ngOnInit() {        
        let selectedSNValues: string = localStorage.getItem("SelectedSN");
        let selectedMODELValues: string = localStorage.getItem("SelectedMODEL");
        let selectedMODELLifeValues: string = localStorage.getItem("selectedMODELLife");
        let selectedMODELCATEGORYValues: string = localStorage.getItem("selectedMODELCATEGORY");
        let selectedHR_TYPEValues: string = localStorage.getItem("selectedMODELHR_TYPE");
        let selectedHrsYear1Boom: string = localStorage.getItem("HrsYear1Boom");
        if (selectedSNValues != "" && selectedSNValues !=null)
        {            
            let selectedSNValueArr: any = [];
            let selectedMODELValueArr: any = [];
            let selectedMODELLifeValuesArr: any = [];
            let selectedMODELCATEGORYValueArr: any = [];
            let selectedHR_TYPEValuesArr: any = [];
            let selectedHrsYear1BoomArr: any = [];
            selectedSNValueArr = selectedSNValues.split(",");
            selectedMODELValueArr = selectedMODELValues.split(",");
            selectedMODELLifeValuesArr = selectedMODELLifeValues.split(",");
            selectedMODELCATEGORYValueArr = selectedMODELCATEGORYValues.split(",");
            selectedHR_TYPEValuesArr = selectedHR_TYPEValues.split(",");
            selectedHrsYear1BoomArr =  selectedHrsYear1Boom.split(",");
            for (let i = 0; i < selectedSNValueArr.length; i++) {
                let newName = {
                    UserName: localStorage.getItem("UserName"),
                    EqSourceType: "1",
                    SerialNo: selectedSNValueArr[i],
                    Model: selectedMODELValueArr[i],
                    Quantity: 1,
                    HourFrom: 0,
                    HourTo: selectedMODELLifeValuesArr[i],
                    MODELCATEGORY: selectedMODELCATEGORYValueArr[i],
                    EQ_LIFE: selectedMODELLifeValuesArr[i],
                    HR_TYPE: selectedHR_TYPEValuesArr[i],
                    HrsYear1Boom: selectedHrsYear1BoomArr[i],
                };
                this.selectedItemsValues.push(newName);
            }
        }
        
    }

    trackByIndex(index: number, value: number) {
        return index;
    }

    onOkAddMasterClicked(selectedItemsValues: any): any {
        var closeLoginBtn = document.getElementById("add-model-popupCloseBtn");
        var addSelectedEpqBtn = document.getElementById("addSelectedEpqBtn");
        this.dataService.setData(this.appConstant.selectedEquipemtRoot, [], true);
        this.dataService.clearReferenceForList(true);        
        closeLoginBtn.click();        
        this.saveService.saveMaestroSelectedEquipmentData(selectedItemsValues).then()
            .catch(error => console.log(error));        
        addSelectedEpqBtn.click();
        localStorage.removeItem("SelectedSN");
        localStorage.removeItem("SelectedMODEL");
        localStorage.removeItem("selectedMODELLife");        
        localStorage.removeItem("selectedMODELCATEGORY");
        localStorage.removeItem("selectedMODELHR_TYPE");
        localStorage.removeItem("HrsYear1Boom");
    }
    
    close() {
        this.activeModal.dismiss(true);
        localStorage.removeItem("SelectedSN");
        localStorage.removeItem("SelectedMODEL");
        localStorage.removeItem("selectedMODELLife");
        localStorage.removeItem("selectedMODELCATEGORY");
        localStorage.removeItem("selectedMODELHR_TYPE");
        localStorage.removeItem("HrsYear1Boom");
    }

    onModelChange(value , field , data) {       
        var ngNativeEl = this.eRef.nativeElement.querySelector('#' + field + data.SerialNo.split(' ').join(''));
        if(value){
            var temp  = value.toString() || "";          
            switch(field){
                case 'Quantity':              
                    if(this.commonUtil.checkSpecialRegex(temp , false , false) || temp.length > this.maxQty){                        
                        value  = data[field];                     
                        ngNativeEl.value = data[field];                   
                    } else {                     
                        data[field] = value; 
                    }  
                    break;
    
                case 'HourFrom' :
                    if(this.commonUtil.checkSpecialRegex(temp , false , false) || temp.toString().length > this.max ){                        
                        value  = data[field];   
                        ngNativeEl.value = data[field];   
                    }  else {
                        data[field] = value; 
                    } 
                    break;

                case 'HourTo' :
                    if(this.commonUtil.checkSpecialRegex(temp , false , false) || temp.toString().length > this.max ){                        
                        value  = data[field];   
                        ngNativeEl.value = data[field];   
                    }  else {
                        data[field] = value; 
                    } 
                    break;
    
                default : break;
            }       
        }                      
    }

    setDynamicId(field, data) {
        var id: string = "";
        if (data['SerialNo'] && data['SerialNo'].toLowerCase() === "n/a") {
            id = field + (data['Model']);
        } else if (data['Model'] && data['Model'].toLowerCase() === "n/a") {
            id = field + (data['SerialNo']);
        } else {
            id = field + (data['SerialNo']);
        }
        id = id.replace(/\s/g, "");        
        return id;
    }
}

@Injectable() export class AddPopupService {

    constructor(private modalService: NgbModal) { }

    public show() {
        const modalRef = this.modalService.open(AddPopupComponent);
        modalRef.componentInstance.name = "showaddpopup";
        modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }
}

export class eqSelectedClass {    
    UserName: string;
    EqSourceType: string;
    SerialNo: string;
    Model: string;
    Quantity: number=0;
    HourFrom: number = 0;
    HourTo: number = 0;
    MODELCATEGORY: string;
    EQ_LIFE: string;
    HR_TYPE: string;
    HrsYear1Boom: string;
}
  

    
