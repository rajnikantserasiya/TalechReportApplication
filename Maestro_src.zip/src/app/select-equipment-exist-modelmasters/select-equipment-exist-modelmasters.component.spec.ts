import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectEquipmentExistModelmastersComponent } from './select-equipment-exist-modelmasters.component';

describe('SelectEquipmentExistModelmastersComponent', () => {
  let component: SelectEquipmentExistModelmastersComponent;
  let fixture: ComponentFixture<SelectEquipmentExistModelmastersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectEquipmentExistModelmastersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectEquipmentExistModelmastersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
