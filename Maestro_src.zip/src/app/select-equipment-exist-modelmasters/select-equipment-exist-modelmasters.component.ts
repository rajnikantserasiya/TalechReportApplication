import { Component, OnInit } from '@angular/core';
import { Equipments_mm } from './../services/equipments-mm.service';
import { SelectModelMasterService } from './../services/select-model-master.service';
import { AddMasterModelService } from '../add-master-model/add-master-model.component';
import {PaginationPipe} from '../pipes/pagination.pipe';
import { DataService } from './../services/data-component.service';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { AppConstant } from './../app.constant';

@Component({
    selector: 'app-select-equipment-exist-modelmasters',
    templateUrl: './select-equipment-exist-modelmasters.component.html',
    styleUrls: ['./select-equipment-exist-modelmasters.component.css'],
	providers: [ AddMasterModelService],
})
export class SelectEquipmentExistModelmastersComponent implements OnInit {
    searchboxText = "Search";
    modHeadText = "Model";
    modcatHeadText = "Model Category";
    addText = "Add >";
    equipbymm: Equipments_mm[];

    pagingConfig = { "startIndex": 1, "endIndex": 5, "itemsPerPage": 10, "action": "refresh" };
   
    equipbymodelOriginal: any = [];
    totalCount: number = 0;

    selectedModelItems: any = [];
    selectedMODELItemsValue: any = [];
    selectedMODELLifeValue: any = [];

    selectedMODELCATEGORY: any =[];
    selectedMODELHR_TYPE: any =[];
    selectedHrsYear1Boom: any =[];

    searchText: string = "";

    checkedColumnCount: number = 0;

    constructor(private selectModelMasterService: SelectModelMasterService, private addMasterModelService: AddMasterModelService ,  private appConstant : AppConstant , private fetchCurrentDataService : FetchCurrentDataService , private dataService : DataService) {
        this.fetchCurrentDataService.screenDataStream$.subscribe(
            () => {
            if(!this.fetchCurrentDataService.disableFlagSaveModelMaster){
                this.fetchCurrentDataService.disableFlagSaveModelMaster = true;
                if(this.equipbymm &&  this.equipbymm.length>0){   
                    this.fetchCurrentDataService.createJsonToSave(this.equipbymm, this.appConstant.modelMasterRoot);
                }       
            }           
        });
    }

    ngOnInit() {
        document.getElementById("slide-nav").style.width = "0";
        this.getEquipByMM();
    }

    getEquipByMM(): void {

        this.selectModelMasterService.selectModelMasterData().then(

            result => {
                result.forEach( item => {
                    item["checked"] = false;
                });
                this.equipbymm = result;
                this.equipbymodelOriginal = JSON.parse(JSON.stringify(result));
                this.totalCount = this.equipbymm.length;
            }
            )
            .catch(error => console.log(error));
    }

    addbyMM(equip, event) {

        document.getElementById("slide-nav").style.width = "0";
        var index = this.selectedModelItems.indexOf(equip.MODEL);

        if (event.target.checked) {
            
            this.selectedModelItems.push(equip.MODEL);
            this.selectedMODELLifeValue.push(equip.EQ_LIFE);

            this.selectedMODELCATEGORY.push(equip.MODELCATEGORY);
            this.selectedMODELHR_TYPE.push(equip.HR_TYPE); 
            this.selectedHrsYear1Boom.push(equip.HrsYear1Boom);  
                
        }
        else {
            if (index !== -1) {
                this.selectedModelItems.splice(index, 1);
                this.selectedMODELLifeValue.splice(index, 1);

                this.selectedMODELCATEGORY.splice(index, 1);
                this.selectedMODELHR_TYPE.splice(index, 1); 
                this.selectedHrsYear1Boom.splice(index, 1); 
            }
        }

        localStorage.setItem("SelectedMODELValue", this.selectedModelItems);
        localStorage.setItem("selectedMODELLife", this.selectedMODELLifeValue);

        localStorage.setItem("selectedMODELCATEGORY", this.selectedMODELCATEGORY);
        localStorage.setItem("selectedMODELHR_TYPE", this.selectedMODELHR_TYPE);
        localStorage.setItem("SelectModelHrsYear1Boom", this.selectedHrsYear1Boom);

        console.log(localStorage.getItem("SelectedMODELValue"));
        this.maintainCheckedCount();
    }

    maintainCheckedCount() {
        this.checkedColumnCount = 0;
        this.equipbymm.forEach(element => {
            if (element["checked"]) {
                this.checkedColumnCount++;
            }
        });
    }

    add(equipbymm): void {

        document.getElementById("slide-nav").style.width = "0";

        this.selectedModelItems = [];
        this.selectedMODELLifeValue = [];
        
        let selectedMODELValues: string = localStorage.getItem("SelectedMODELValue");


        if (selectedMODELValues != "" && selectedMODELValues != null && equipbymm != undefined) {

            let selectedMODELValueArr: any = [];

            selectedMODELValueArr = selectedMODELValues.split(",");


            for (let i = 0; i < selectedMODELValueArr.length; i++) {

                var selectedSNValuestr = selectedMODELValueArr[i];

                var index = equipbymm.findIndex(obj => obj["MODEL"] === selectedSNValuestr)
                if(index > -1){
                    equipbymm[index]['checked'] = false;
                }   
            };
        }

        this.maintainCheckedCount();

       this.addMasterModelService.show();

    }

    refreshData(configData): void {
        console.log("Recieved Data from  paging component" + JSON.stringify(configData));
        this.pagingConfig = configData;
        document.getElementById("slide-nav").style.width = "0";
    }

    onSearchTextChange(value): void {
        var that = this;
        document.getElementById("slide-nav").style.width = "0";                     
        if(value.length >= 2){           
            this.searchText = value;
            this.pagingConfig["searchText"] = value;
            this.equipbymm = JSON.parse(JSON.stringify(this.equipbymodelOriginal));
            this.equipbymm = this.equipbymm.filter(item => {              
                if (that.selectedModelItems.indexOf(item["MODEL"]) >= 0) {
                    item["checked"] = true;
                } else {
                    item["checked"] = false;
                }                
                return (item["MODEL"].trim().toUpperCase().includes(value.trim().toUpperCase()) || item["MODELCATEGORY"].trim().toUpperCase().includes(value.trim().toUpperCase()));
            });
            this.totalCount = this.equipbymm.length;
            this.pagingConfig = { "startIndex": 1, "endIndex": 5, "itemsPerPage": 10, "action": "refresh" };
        } 
        else if(value.length == 0) {
            var checkedRecord : any = this.equipbymm.filter(item => {                                  
                return   item["checked"] == true;;
            });                   
            this.equipbymm = JSON.parse(JSON.stringify(this.equipbymodelOriginal));
            this.equipbymm.forEach(item => {              
                if (that.selectedModelItems.indexOf(item["MODEL"]) >= 0) {
                    item["checked"] = true;
                } else {
                    item["checked"] = false;
                }                               
            });
            this.totalCount = this.equipbymm.length;
            this.pagingConfig = { "startIndex": 1, "endIndex": 5, "itemsPerPage": 10, "action": "refresh" };
        }       
    }
    
    enableDisableAdd() {
        let disableReport: boolean = false;
        if (this.checkedColumnCount > 0) {
            disableReport = false;
        } else {
            disableReport = true;
        }
        return disableReport;
    }

   

}
