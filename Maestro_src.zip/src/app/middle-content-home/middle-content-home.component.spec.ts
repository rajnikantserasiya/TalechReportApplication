import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MiddleContentHomeComponent } from './middle-content-home.component';

describe('MiddleContentHomeComponent', () => {
  let component: MiddleContentHomeComponent;
  let fixture: ComponentFixture<MiddleContentHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MiddleContentHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MiddleContentHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
