import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginDialogService } from '../login-popup/login-popup.component';
import { LogoutService } from '../services/logout.service';
import * as XLSX from 'xlsx';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { CustomerCountryService } from './../services/customer-country.service';
import { Country_mm } from '../services/eq-exclusions-class';
import { DataService } from './../services/data-component.service';
import { UpdateFleetService }  from '../services/update-fleet.service';
import { StartNewSessionDialogService } from '../start-new-session-popup/start-new-session-popup.component';
import { LoadOldSessionDialogService } from '../load-old-session-popup/load-old-session-popup.component';
import { ContinueExistingSessionDialogService } from '../continue-existing-session-popup/continue-existing-session-popup.component';
import { NgIf } from '@angular/common';

import {EqExclusionsServiceService} from '../services/eq-exclusions-service.service';

//Azure AD Changes
import {Http, Response, Headers, RequestMethod, RequestOptions} from "@angular/http";
import { AuthService } from "../interceptor/auth.service";

import { ReportService } from '../services/report.service';

//Azure AD Changes
import { CommonService } from '../services/common.service';

declare var jquery: any;
declare var $: any;
declare var PNotify: any;

@Component({
    selector: 'app-middle-content-home',
    templateUrl: './middle-content-home.component.html',
    styleUrls: ['./middle-content-home.component.css'],
    providers: [LoginDialogService, StartNewSessionDialogService, LoadOldSessionDialogService, ContinueExistingSessionDialogService, CustomerCountryService]
})
export class MiddleContentHomeComponent implements OnInit {

    data: any = [];
    mappedData: any = [];
    columns: any = [];
    public countrymm: Country_mm[];
    public tokenValue: any = "123";
    hiddenLoginStatus: string = 'login';
    constructor(private eqExclusionsServiceService: EqExclusionsServiceService,
        private startNewSessionDialogService: StartNewSessionDialogService,
        private loadOldSessionDialogService: LoadOldSessionDialogService,
        private continueExistingSessionDialogService: ContinueExistingSessionDialogService, private maestroRouter: Router, private customerCountryService: CustomerCountryService, private dataService: DataService,
        private updateFleetService: UpdateFleetService, private loginDlgService: LoginDialogService,
        private logoutService: LogoutService, private reportService: ReportService
        //Azure AD Changes
        , private _http: Http, private authService: AuthService,
        public commonService: CommonService
    ) {
    }

    ngOnInit() {
        //Azure AD Changes
        if (this.commonService.getAzureADAuthenticationEnableFlagValue()) {
            if (this.authService.getAuthToken() === null || this.authService.getAuthToken() === '') {
                this.reportService.SaveUserLoginTrack("User Logged In");
                //this.azureADTokenRequestMethod();
                this.logoutService.azureADTokenRequestMethod(true);
            }
        }
        else {
            //Azure AD Changes

            //Commented below method and uncomment above this.azureADTokenRequestMethod() method for Azure AD Login
            this.LoaddataInNormalLoginMode();
        }

    }

    LoaddataInNormalLoginMode() {

        //debugger;
        this.reportService.SaveUserLoginTrack("User Logged In");

        localStorage.setItem("IsGenerateReportActive", "false");
        if (localStorage.getItem("token") == "" || localStorage.getItem("token") == null) {
            //var btnopenStartNewSession = (<HTMLInputElement>document.getElementById("btnopenStartNewSession"));
            //var btnopenDialog = (<HTMLInputElement>document.getElementById("btnopenDialog"));
            //var btnopenContinueExistingSession = (<HTMLInputElement>document.getElementById("btnopenContinueExistingSession"));
            var slideOutDiv = (<HTMLInputElement>document.getElementById("slide-nav"));
            var openslideBtn = (<HTMLInputElement>document.getElementById("openslideBtn"));
            //btnopenStartNewSession.disabled = true;
            //btnopenDialog.disabled = true;
            //btnopenContinueExistingSession.disabled = true;
            slideOutDiv.style.display = 'none';
            openslideBtn.style.display = 'none';

            //var logoutBtn = (<HTMLInputElement>document.getElementById("logout-btn"));
            //logoutBtn.style.display = 'none';

            //var logInBtn = (<HTMLInputElement>document.getElementById("login-btn"));
            //logInBtn.style.display = 'block';
            $("#login-btn").show();

            var welcomeUsrTxt = (<HTMLInputElement>document.getElementById("welcomeUsr"));

            welcomeUsrTxt.childNodes[1].textContent = localStorage.getItem("userId");

            welcomeUsrTxt.hidden = true;
        }
        else {
            var logoutBtn = (<HTMLInputElement>document.getElementById("logout-btn"));
            logoutBtn.style.display = 'block';

            var logInBtn = (<HTMLInputElement>document.getElementById("login-btn"));
            logInBtn.style.display = 'none';

            var welcomeUsrTxt = (<HTMLInputElement>document.getElementById("welcomeUsr"));

            welcomeUsrTxt.childNodes[1].textContent = localStorage.getItem("userId");

            welcomeUsrTxt.hidden = false;
        }
        if (localStorage.getItem("PriceListType") == "" || localStorage.getItem("PriceListType") == null) {
            localStorage.setItem("PriceListType", "N/A");
        }
        if (localStorage.getItem("PriceList") == "" || localStorage.getItem("PriceList") == null) {
            localStorage.setItem("PriceList", "N/A");
        }
        //localStorage.setItem("PriceListType_Report", "");
        //localStorage.setItem("PriceList_Report", "");

    }


    openLogin(): void {

        this.loginDlgService.show();

    }

    logout(): void {

        localStorage.setItem("token", "");
        localStorage.setItem("PriceListType", "");
        localStorage.setItem("PriceList", "");

        this.logoutService.logoutUser(localStorage.getItem("token")).then(result => result)
            .catch(error => console.log(error));



        this.maestroRouter.navigateByUrl('main');

        var beforeLoginTxt = (<HTMLInputElement>document.getElementById("beforeLogin"));

        if (beforeLoginTxt != null) {
            beforeLoginTxt.style.display = 'block';
        }

        var welcomeUsrTxt = (<HTMLInputElement>document.getElementById("welcomeUsr"));
        welcomeUsrTxt.hidden = true;

        var slideOutDiv = (<HTMLInputElement>document.getElementById("slide-nav"));
        slideOutDiv.style.display = 'none';

        var openslideBtn = (<HTMLInputElement>document.getElementById("openslideBtn"));
        openslideBtn.style.display = 'none';

        var logoutBtn = (<HTMLInputElement>document.getElementById("logout-btn"));
        logoutBtn.style.display = 'none';

        var logInBtn = (<HTMLInputElement>document.getElementById("login-btn"));
        logInBtn.style.display = 'block';
    }


    openStartNewSession(): void {
        this.dataService.clearOptionsData();
        this.closeNav();
        this.startNewSessionDialogService.show();
    }

    disableButton(): boolean {
        var tokenValue = localStorage.getItem("token");
        return (tokenValue === "" || tokenValue === null);
    }

    openOldSession(): void {
        this.dataService.clearOptionsData();
        this.closeNav();
        this.loadOldSessionDialogService.show();
    }


    closeNav() {
        document.getElementById("slide-nav").style.width = "0";
    }

    openContinueExistingSession(): void {
        this.dataService.clearOptionsData();
        this.closeNav();
        this.continueExistingSessionDialogService.show();
    }


    onFileChange(evt: any) {
        /* wire up file reader */
        this.columns = [];
        var fileName = "";
        const target: DataTransfer = <DataTransfer>(evt.target);
        if (evt.target.files[0]["name"]) {
            fileName = evt.target.files[0]["name"];
            console.log(fileName);
        }
        if (fileName.indexOf('xls') > 0 || fileName.indexOf('xlsx') > 0) {
            if (target.files.length !== 1) throw new Error('Cannot use multiple files');
            const reader: FileReader = new FileReader();
            reader.onload = (e: any) => {
                /* read workbook */
                const bstr: string = e.target.result;
                const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

                /* grab first sheet -  considering single sheet scenario currently*/
                const wsname: string = wb.SheetNames[0];
                const ws: XLSX.WorkSheet = wb.Sheets[wsname];

                /* save data */
                this.data = (XLSX.utils.sheet_to_json(ws, { header: 1 }));
                if (this.data.length > 1) {
                    PNotify.prototype.options.styling = "fontawesome";
                    PNotify.prototype.options.stack.firstpos2 = 250;
                    // UI Changes (Changed width to 500 from 300
                    new PNotify({
                        text: 'Updating Fleet',
                        delay: 3000000,
                        width: 500
                    });
                    $(".ui-pnotify-text").append("<span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span>");
                    this.updateData(evt);
                }
            };
            reader.readAsBinaryString(target.files[0]);
            evt.target["value"] = "";
        } else {
            alert('Please Select valid file format');
        }
    }

    onFileBomChange(evt: any) {
        /* wire up file reader */
        this.columns = [];
        const target: DataTransfer = <DataTransfer>(evt.target);
        var fileName = "";
        if (evt.target.files[0]["name"]) {
            fileName = evt.target.files[0]["name"];
            console.log(fileName);
        }
        if (fileName.indexOf('xls') > 0 || fileName.indexOf('xlsx') > 0) {
            if (target.files.length !== 1) throw new Error('Cannot use multiple files');
            const reader: FileReader = new FileReader();
            reader.onload = (e: any) => {
                /* read workbook */
                const bstr: string = e.target.result;
                const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

                /* grab first sheet -  considering single sheet scenario currently*/
                const wsname: string = wb.SheetNames[0];
                const ws: XLSX.WorkSheet = wb.Sheets[wsname];

                /* save data */
                this.data = (XLSX.utils.sheet_to_json(ws, { header: 1 }));
                if (this.data.length > 1) {
                    PNotify.prototype.options.styling = "fontawesome";
                    PNotify.prototype.options.stack.firstpos2 = 250;
                    // UI Changes (Changed width to 500 from 300
                    new PNotify({
                        text: 'Updating Bom',
                        delay: 3000000,
                        width: 500
                    });
                    $(".ui-pnotify-text").append("<span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span>");
                    this.updateBomData(evt);
                }
            };
            reader.readAsBinaryString(target.files[0]);
            evt.target["value"] = "";
        } else {
            alert('Please Select valid file format');
        }
    }

    updateData(evt) {
        var obj = [];
        var intervalStartIndex = -1;
        var json = [];
        var array = [];

        this.data[0].forEach(item => {
            if (isNaN(item)) {
                this.columns.push(item);
                obj.push({ "filterName": item, "filterValue": [] });
            }
        });
        intervalStartIndex = obj.length;
        for (var i = 1; i < this.data.length; i++) {
            var tempArray = this.data[i];
            var objTemp = {};
            for (var j = 0; j < intervalStartIndex; j++) {
                objTemp[obj[j]["filterName"]] = tempArray[j];
            }
            json.push(objTemp);
        }
        array = this.columns;
        this.columns = array.filter(function (item, pos) {
            return array.indexOf(item) == pos;
        })
        this.mappedData = json;
        this.updateFleetData();
    }

    updateBomData(evt) {
        var obj = [];
        var intervalStartIndex = -1;
        var json = [];
        var array = [];

        this.data[0].forEach(item => {
            if (isNaN(item)) {
                this.columns.push(item);
                obj.push({ "filterName": item, "filterValue": [] });
            }
        });
        intervalStartIndex = obj.length;
        for (var i = 1; i < this.data.length; i++) {
            var tempArray = this.data[i];
            var objTemp = {};
            for (var j = 0; j < intervalStartIndex; j++) {
                objTemp[obj[j]["filterName"]] = tempArray[j];
            }
            json.push(objTemp);
        }
        array = this.columns;
        this.columns = array.filter(function (item, pos) {
            return array.indexOf(item) == pos;
        })
        this.mappedData = json;
        this.updateBomsData();
    }

    updateBomsData() {
        this.updateFleetService.updateBomData(this.mappedData).then(result => {
            console.log(result);
            this.onBomUpdateSuccess();
        })
            .catch(error => this.onBomUpdateFail());
    }

    updateFleetData() {
        this.updateFleetService.updateFleetData(this.mappedData).then(result => {
            console.log(result);
            this.onFleetUpdateSuccess();
        })
            .catch(error => this.onFleetUpdateFail());
    }

    onFleetUpdateSuccess() {
        PNotify.removeAll();
        // UI Changes (Changed width to 500 from 300
        new PNotify({
            text: 'Updated Fleet Successfully',
            delay: 1000,
            width: 500,
            type: 'success'
        });
    }

    onBomUpdateSuccess() {
        PNotify.removeAll();
        // UI Changes (Changed width to 500 from 300
        new PNotify({
            text: 'Updated Bom Successfully',
            delay: 1000,
            width: 500,
            type: 'success'
        });
    }

    onFleetUpdateFail() {
        PNotify.removeAll();
        // UI Changes (Changed width to 500 from 300
        new PNotify({
            text: 'Updated Fleet Successfully',
            delay: 1000,
            width: 500,
            type: 'error'
        });

    }

    onBomUpdateFail() {
        PNotify.removeAll();
        // UI Changes (Changed width to 500 from 300
        new PNotify({
            text: 'UpdatedBomsFleet Successfully',
            delay: 1000,
            width: 500,
            type: 'error'
        });

    }

    //Azure AD Changes
    //azureADTokenRequestMethod() {
    //    this._http.get('/.auth/me')
    //        .toPromise().then((response) => {

    //            //debugger;
    //            // User Maestro Application AD Group object id
    //            let adminGroupObjectId = "72506c0d-6cb7-4703-a3dd-1093f44d1450";
    //            let normalUserGroupObjectId = "4c277dbe-03df-4a52-a95a-da4d4db01796";

    //            let tokenVal = response.json()[0]["id_token"];
    //            let userClaimsObject = response.json()[0]["user_claims"];

    //            this.authService.setAuthToken(tokenVal);
    //            localStorage.setItem("UserName", response.json()[0]["user_id"]);

    //            // display admin panel or not based on user group
    //            var adminSlide = (<HTMLInputElement>document.getElementById("adminSlideId"));
    //            var slideOutDiv = (<HTMLInputElement>document.getElementById("slide-nav"));
    //            var openslideBtn = (<HTMLInputElement>document.getElementById("openslideBtn"));

    //            var userRole = '';
    //            userClaimsObject.forEach(item => {

    //                var strtype = item["typ"];
    //                if (strtype == "groups") {

    //                    var strVal = item["val"];
    //                    if (strVal == adminGroupObjectId) {
    //                        // admin                                                  
    //                        slideOutDiv.style.display = 'block';
    //                        openslideBtn.style.display = 'block';
    //                        adminSlide.style.display = 'block';

    //                        userRole = "Admin";
    //                    }
    //                    else if (userRole == '' && strVal == normalUserGroupObjectId) {
    //                        // normal user
    //                        slideOutDiv.style.display = 'none';
    //                        openslideBtn.style.display = 'none';
    //                        adminSlide.style.display = 'none';
    //                        userRole = "User";
    //                    }
    //                }

    //                if (strtype == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname") {
    //                    localStorage.setItem("userId", item["val"]);
    //                }

    //            });

    //            //debugger;
    //            if (userRole == '') {
    //                alert("You are not assigned to any maestro application group. Please contact your administrator.")
    //                // user is not assigned to maestro application groups
    //                var btnopenStartNewSession = (<HTMLInputElement>document.getElementById("btnopenStartNewSession"));
    //                var btnopenDialog = (<HTMLInputElement>document.getElementById("btnopenDialog"));
    //                var btnopenContinueExistingSession = (<HTMLInputElement>document.getElementById("btnopenContinueExistingSession"));

    //                btnopenStartNewSession.disabled = true;
    //                btnopenDialog.disabled = true;
    //                btnopenContinueExistingSession.disabled = true;
    //            }
    //            else {
    //                //debugger;
    //                localStorage.setItem("userRole", userRole);

    //                // Just for testing purpose
    //                //if (localStorage.getItem("UserName") == "ashwini.dhanuche_c@sandvik.com") {
    //                //    localStorage.setItem("UserName", "ashwini");

    //                //}
    //                //// Just for testing purpose
    //                //if (localStorage.getItem("UserName") == "anup.gandhamwar_c@sandvik.com") {
    //                //    localStorage.setItem("UserName", "AnupG");
    //                //}
    //            }

    //            this.LoadDataInAzureADLoginModel();
    //        }).catch(this.handleError);
    //}

    //Azure AD Changes
    LoadDataInAzureADLoginModel() {

        var welcomeUsrTxt = (<HTMLInputElement>document.getElementById("welcomeUsr"));
        welcomeUsrTxt.childNodes[1].textContent = localStorage.getItem("userId");
        welcomeUsrTxt.hidden = false;
        //debugger;
        localStorage.setItem("IsGenerateReportActive", "false");
        if (this.authService.getAuthToken() == "" || this.authService.getAuthToken() == null) {
            var slideOutDiv = (<HTMLInputElement>document.getElementById("slide-nav"));
            var openslideBtn = (<HTMLInputElement>document.getElementById("openslideBtn"));
            slideOutDiv.style.display = 'none';
            openslideBtn.style.display = 'none';
        }

        if (localStorage.getItem("PriceListType") == "" || localStorage.getItem("PriceListType") == null) {
            localStorage.setItem("PriceListType", "N/A");
        }
        if (localStorage.getItem("PriceList") == "" || localStorage.getItem("PriceList") == null) {
            localStorage.setItem("PriceList", "N/A");
        }
    }

    //Azure AD Changes
    LogOut(): void {
        this.logoutService.logoutUserFromAzureAD();
    }

    AzureLogOut(): void {
        this.logoutService.logoutUserFromAzureAD();
    }

    //Azure AD Changes
    private handleError(error: any): any {
        console.log("Error in /.auth/me method");
        window.location.reload();
        //window.location.href = "https://maestrowebappadauthentication.azurewebsites.net/.auth/logout";
        //window.location.href = "https://login.microsoftonline.com/0166c58b-5ffe-4245-b610-931b438f7470/oauth2/logout";

    }
}

