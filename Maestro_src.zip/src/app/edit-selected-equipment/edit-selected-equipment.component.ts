import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import {ElementRef, Component, HostListener, HostBinding, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable } from '@angular/core';
import { DataService } from './../services/data-component.service';
import { SaveService } from '../services/save.service';
import { AppConstant } from './../app.constant';
import { CommonUtil }  from './../common/common-util';

@Component({
    selector: 'app-edit-selected-equipment',
    templateUrl: './edit-selected-equipment.component.html',
    styleUrls: ['./edit-selected-equipment.component.css']
})
export class EditSelectedEquipmentComponent implements OnInit {

    constructor(private dataService: DataService, private saveService: SaveService, private appConstant: AppConstant, private commonUtil: CommonUtil, private eRef: ElementRef, private activeModal: NgbActiveModal) { }
    selectedImportItemsValues: any = [];
    max: Number = 7;
    maxQty: Number = 2;

    ngOnInit() {
        this.selectedImportItemsValues = JSON.parse(JSON.stringify(this.dataService.getEditSelecEquip()));
    }

    public restrictNumeric(e) {
        var key = e.keyCode ? e.keyCode : e.which;
        if (!([8, 9, 13, 27, 110, 190].indexOf(key) !== -1 ||
            (key == 65 && (e.ctrlKey || e.metaKey)) ||
            (key >= 35 && key <= 40) ||
            (key == 43 && key == 45) ||
            (key >= 48 && key <= 57 && !(e.shiftKey || e.altKey)) ||
            (key >= 96 && key <= 105)
        )) e.preventDefault();

        if (e.target.value.length >= this.max) e.preventDefault();
    }

    public restrictQtyNumeric(e) {
        var key = e.keyCode ? e.keyCode : e.which;
        if (!([8, 9, 13, 27, 110, 190].indexOf(key) !== -1 ||
            (key == 65 && (e.ctrlKey || e.metaKey)) ||
            (key >= 35 && key <= 40) ||
            (key == 43 && key == 45) ||
            (key >= 48 && key <= 57 && !(e.shiftKey || e.altKey)) ||
            (key >= 96 && key <= 105)
        )) e.preventDefault();

        if (e.target.value.length >= this.maxQty) e.preventDefault();
    }

    public restrictZero(e) {
        var key = e.keyCode ? e.keyCode : e.which;
        if (e.target.value == '' || e.target.value == "0" || e.target.value.length > this.max)
        { e.target.value = 1 };
    }

    public restrictQty(e) {
        var key = e.keyCode ? e.keyCode : e.which;
        if (e.target.value == '' || e.target.value == "0" || e.target.value.length > this.maxQty)
        { e.target.value = 1 };
    }

    trackByIndex(index: number, value: number) {
        return index;
    }

    onOkAddMasterClicked(selectedItemsValues: any): any {
        this.dataService.clearReferenceForList(true);
        this.saveService.saveMaestroSelectedEquipmentData(selectedItemsValues).then()
            .catch(error => console.log(error));
    }

    close() {
        this.activeModal.dismiss(true);
    }

    onModelChange(value, field, data) {

        var ngNativeEl = data.SerialNo != 'N/A' ? this.eRef.nativeElement.querySelector('#' + field + data.SerialNo.split(' ').join('')) : this.eRef.nativeElement.querySelector('#' + field + data.Model.split(' ').join(''));
        //var ngNativeEl = this.eRef.nativeElement.querySelector('#' + field + data.SerialNo.split(' ').join(''));
        if (value) {
            var temp = value.toString() || "";
            switch (field) {
                case 'Quantity':
                    if (this.commonUtil.checkSpecialRegex(temp, false, false) || temp.length > this.maxQty) {
                        value = data[field];
                        ngNativeEl.value = data[field];
                    } else {
                        data[field] = value;
                    }
                    break;

                case 'HourFrom':
                    if (this.commonUtil.checkSpecialRegex(temp, false, false) || temp.toString().length > this.max) {
                        value = data[field];
                        ngNativeEl.value = data[field];
                    } else {
                        data[field] = value;
                    }
                    break;

                case 'HourTo':
                    if (this.commonUtil.checkSpecialRegex(temp, false, false) || temp.toString().length > this.max) {
                        value = data[field];
                        ngNativeEl.value = data[field];
                    } else {
                        data[field] = value;
                    }
                    break;

                default: break;
            }
        }
    }

    setDynamicId(field, data) {
        var id: string = "";
        if (data['SerialNo'] && data['SerialNo'].toLowerCase() === "n/a") {
            id = field + (data['Model']);
        } else if (data['Model'] && data['Model'].toLowerCase() === "n/a") {
            id = field + (data['SerialNo']);
        } else {
            id = field + (data['SerialNo']);
        }
        id = id.replace(/\s/g, "");
        return id;
    }

    onOkAddImportBomMasterClicked() {
        this.saveService.editMaestroSelectedEquipmentData(this.selectedImportItemsValues).then((response) => {
            this.onSaveSuccess();
        })
            .catch(error => console.log(error));
    }

    onSaveSuccess() {
        this.dataService.clearReferenceForList(true);
        setTimeout(item => {
            var addSelectedEpqBtn = document.getElementById("addSelectedEpqBtn");
            addSelectedEpqBtn.click();
        }, 500);
        this.activeModal.close();
    }


}

@Injectable() export class EditSelectedBomService {

    constructor(private modalService: NgbModal) { }

    public show() {
        const modalRef = this.modalService.open(EditSelectedEquipmentComponent);
        modalRef.componentInstance.name = "editSelecEquip";
        modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }
}
