import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditSelectedEquipmentComponent } from './edit-selected-equipment.component';

describe('EditSelectedEquipmentComponent', () => {
  let component: EditSelectedEquipmentComponent;
  let fixture: ComponentFixture<EditSelectedEquipmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditSelectedEquipmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditSelectedEquipmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
