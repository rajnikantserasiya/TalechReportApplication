import { Component, OnInit } from '@angular/core';
import { StartNewSessionDialogService } from '../start-new-session-popup/start-new-session-popup.component';
import { LoadOldSessionDialogService } from '../load-old-session-popup/load-old-session-popup.component';
import { SaveExistingSessionPopupService } from '../save-existing-session-popup/save-existing-session-popup.component';
import {SaveService } from '../services/save.service';
import {LogoutService } from '../services/logout.service';
import * as FileSaver from 'file-saver';
import { Router } from '@angular/router';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { AppConstant } from './../app.constant';
import { DataService } from './../services/data-component.service';
import { ExportUserLogDialogService } from '../export-user-log/export-user-log.component';
import { UpdateFleetDialogService } from '../update-fleet-popup/update-fleet-popup.component';
import { UpdateBomsDialogService } from '../update-boms-popup/update-boms-popup.component';
import { AdvancedRuleDialogService} from '../advaced-rule/advaced-rule.component';
import { NewUserMappingDialogService} from '../new-user-mapping/new-user-mapping.component';
import { UserLogTrackDialogService } from '../user-log-track/user-log-track.component';
import { CommonService } from '../services/common.service';

@Component({
    selector: 'app-slideout-menu',
    templateUrl: './slideout-menu.component.html',
    styleUrls: ['./slideout-menu.component.css'],
    providers: [StartNewSessionDialogService, LoadOldSessionDialogService, SaveExistingSessionPopupService, ExportUserLogDialogService, UpdateFleetDialogService, UpdateBomsDialogService, AdvancedRuleDialogService]
})
export class SlideoutMenuComponent implements OnInit {

    constructor(private saveService: SaveService, private exportUserLogDialogService: ExportUserLogDialogService, private startNewSessionDialogService: StartNewSessionDialogService, private logoutService: LogoutService,
        private loadOldSessionDialogService: LoadOldSessionDialogService, private saveExistingSessionPopupService: SaveExistingSessionPopupService,
        private maestroRouter: Router, private fetchCurrentDataService: FetchCurrentDataService,
        private appConstant: AppConstant, private dataService: DataService,
        private updateFleetDialogService: UpdateFleetDialogService,
        private updateBomsDialogService: UpdateBomsDialogService,
        private advancedRuleDialogService: AdvancedRuleDialogService,
        private newUserMappingDialogService: NewUserMappingDialogService,
        private userLogTrackDialogService: UserLogTrackDialogService,
        public commonService: CommonService
    ) { }

    ngOnInit() {
        this.closeNav();
    }

    public saveMaestroSessionData(): void {
        this.closeNav();
        this.saveExistingSessionPopupService.show();
    }

    public updateFleetDialog(): void {
        this.closeNav();
        this.updateFleetDialogService.show();
    }

    public updateBomsDialog(): void {
        this.closeNav();
        this.updateBomsDialogService.show();
    }

    exportUserLogDialog(): void {
        this.closeNav();
        this.exportUserLogDialogService.show();
    }

    advanceRules(): void {
        var tab = this.dataService.getActiveTab();
        //if(tab === 'tab-exclusion' || tab === 'tab-preview') {
        this.closeNav();
        this.advancedRuleDialogService.show();
        //}    
    }

    startNewSessionDialog(): void {
        this.closeNav();
        this.startNewSessionDialogService.show();
    }

    logoutUser(): void {
        localStorage.setItem("token", "");
        this.closeNav();
        this.maestroRouter.navigateByUrl('main');
        var loginTxt = (<HTMLInputElement>document.getElementById("login-btn"));
        this.logoutService.logoutUser(localStorage.getItem("token")).then(result => result).catch(error => console.log(error));
        loginTxt.innerText = "LOG IN";
        loginTxt.value = "LogIn"
        var welcomeUsrTxt = (<HTMLInputElement>document.getElementById("welcomeUsr"));
        welcomeUsrTxt.hidden = true;
        var slideOutDiv = (<HTMLInputElement>document.getElementById("slide-nav"));
        slideOutDiv.style.display = 'none';
        var openslideBtn = (<HTMLInputElement>document.getElementById("openslideBtn"));
        openslideBtn.style.display = 'none';
    }

    openOldSession(): void {
        this.closeNav();
        this.loadOldSessionDialogService.show();
    }

    fileSave(): void {
        var textToSave = '{"ListMaestroSessionMetadata":[{"UserId":"' + localStorage.getItem("UserName") + '","SessionId":"Session","CurrentDate":"","ItemId":"Item"},{"UserId":"' + localStorage.getItem("UserName") + '","SessionId":"Session1","CurrentDate":"","ItemId":"Item1"}]}';
        var textToSaveAsBlob = new Blob([textToSave], { type: "text/plain" });
        var fileNameToSaveAs = "MaestroSessionMetadata.json";
        FileSaver.saveAs(textToSaveAsBlob, fileNameToSaveAs);
    }

    destroyClickedElement(event): void {
        document.body.removeChild(event.target);
    }

    fileRead(event): void {
        let filelst: FileList = event.target.files;
        let fileTypeArray = filelst[0].name.split(".");
        let fileTypeName = fileTypeArray[1].trim();
        if (fileTypeName === "json") {
            if (filelst.length > 0) {
                var fileReader = new FileReader();
                fileReader.readAsText(filelst[0]);
                var that = this;
                fileReader.onloadend = function (e) {
                    var content = fileReader.result;
                    that.fetchCurrentDataService.setJsonAppData(JSON.parse(content));
                    alert(content);
                    var fileLoader = (<HTMLInputElement>document.getElementById("fileLoader"));
                    fileLoader.value = null;
                    setTimeout(function () {
                        that.validate();
                    }, 1000)
                }
            }
        }
        else {
            alert("Please Select a valid Json file");
        }
    }

    openNav() {
        document.getElementById("slide-nav").style.width = "250px";
    }

    closeNav() {
        document.getElementById("slide-nav").style.width = "0";
    }


    validate() {
        var sessionDetails = this.fetchCurrentDataService.extraDataBasedOnRoot(this.appConstant.sessionDetailsRoot);
        if (sessionDetails && localStorage.getItem('UserName') == sessionDetails["filterValue"][0]["user"]) {
            this.saveService.deleteMaestroSessionData(localStorage.getItem("UserName")).then(
                resultInner => {
                    this.setCacheData(resultInner);
                })
                .catch(error => console.log(error));
        } else {
            window.alert('Invalid User');
        }
    }

    setCacheData(result) {
        this.dataService.updateCacheReference(this.fetchCurrentDataService.getJsonAppData());
        this.fetchCurrentDataService.skipJsonCreationOnSave = true;
        this.maestroRouter.navigateByUrl('contsession');
        setTimeout(() => {
            this.dataService.saveSessionDetails();
        }, 500);
    }

    newUserMapping() {
        this.closeNav();
        this.newUserMappingDialogService.show();
    }

    userLogginTrackDialog(): void {
        this.closeNav();
        this.userLogTrackDialogService.show();
    }
}
