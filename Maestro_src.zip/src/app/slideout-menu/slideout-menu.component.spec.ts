import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SlideoutMenuComponent } from './slideout-menu.component';

describe('SlideoutMenuComponent', () => {
  let component: SlideoutMenuComponent;
  let fixture: ComponentFixture<SlideoutMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SlideoutMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SlideoutMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
