import { Component, OnInit } from '@angular/core';
import {UpdateFleetService}  from '../services/update-fleet.service';
import * as XLSX from 'xlsx';
declare var jquery: any;
declare var $: any;
declare var PNotify: any;

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent  {
  data : any = [];
  mappedData : any = [];
  columns : any = [];

  constructor(private updateFleetService : UpdateFleetService) { }

  onFileChange(evt: any) {
    /* wire up file reader */
    this.columns = [];
    var fileName = "";
    const target: DataTransfer = <DataTransfer>(evt.target);
    if(evt.target.files[0]["name"]){
      fileName = evt.target.files[0]["name"];
      console.log(fileName);
    }
    if(fileName.indexOf('xls') > 0 || fileName.indexOf('xlsx')>0) {
      if (target.files.length !== 1) throw new Error('Cannot use multiple files');
      const reader: FileReader = new FileReader();
      reader.onload = (e: any) => {
          /* read workbook */
          const bstr: string = e.target.result;
          const wb: XLSX.WorkBook = XLSX.read(bstr, {type: 'binary'});
    
          /* grab first sheet -  considering single sheet scenario currently*/
          const wsname: string = wb.SheetNames[0];
          const ws: XLSX.WorkSheet = wb.Sheets[wsname];
    
          /* save data */
          this.data = (XLSX.utils.sheet_to_json(ws, {header: 1}));
          if(this.data.length > 1){     
            PNotify.prototype.options.styling = "fontawesome";
            PNotify.prototype.options.stack.firstpos2 = 250;
            // UI Changes (Changed width to 500 from 300
            new PNotify({
                text: 'Updating Fleet',
                delay: 3000000,
                width: 500
            });
            $(".ui-pnotify-text").append("<span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span>");
            this.updateData(evt);       
        }
      };
      reader.readAsBinaryString(target.files[0]);
      evt.target["value"] = "";
    } else {
        alert('Please Select valid file format');
    }    
  }

  onFileBomChange(evt: any) {
    /* wire up file reader */
    this.columns = [];
    const target: DataTransfer = <DataTransfer>(evt.target);
    var fileName = "";
    if(evt.target.files[0]["name"]){
      fileName = evt.target.files[0]["name"];
      console.log(fileName);
    }
    if(fileName.indexOf('xls') > 0 || fileName.indexOf('xlsx')>0) {
      if (target.files.length !== 1) throw new Error('Cannot use multiple files');
      const reader: FileReader = new FileReader();
      reader.onload = (e: any) => {
        /* read workbook */
        const bstr: string = e.target.result;
        const wb: XLSX.WorkBook = XLSX.read(bstr, {type: 'binary'});
  
        /* grab first sheet -  considering single sheet scenario currently*/
        const wsname: string = wb.SheetNames[0];
        const ws: XLSX.WorkSheet = wb.Sheets[wsname];
  
        /* save data */
        this.data = (XLSX.utils.sheet_to_json(ws, {header: 1}));
        if(this.data.length > 1){     
          PNotify.prototype.options.styling = "fontawesome";
          PNotify.prototype.options.stack.firstpos2 = 250;
          // UI Changes (Changed width to 500 from 300
          new PNotify({
              text: 'Updating Bom',
              delay: 3000000,
              width: 500
          });
          $(".ui-pnotify-text").append("<span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span>");
          this.updateBomData(evt);
        }
      };
      reader.readAsBinaryString(target.files[0]);
      evt.target["value"] = "";
    } else {
      alert('Please Select valid file format');
    }     
  }

  updateData(evt) {
    var obj = [];
    var intervalStartIndex = -1;
    var json = [];
    var array = [];

    this.data[0].forEach( item => {     
      if(isNaN(item)){
        this.columns.push(item);
        obj.push({"filterName": item , "filterValue" : []});
      }     
    });
    intervalStartIndex = obj.length;    
    for( var i = 1; i< this.data.length ; i++){
        var tempArray = this.data[i];      
        var objTemp = {};
        for( var j = 0 ; j<intervalStartIndex ; j++){
          objTemp[obj[j]["filterName"]] =  tempArray[j];                          
        }   
        json.push(objTemp);               
    }     
    array = this.columns;
    this.columns  = array.filter(function(item, pos) {
      return array.indexOf(item) == pos;
    })
    this.mappedData = json;    
    this.updateFleetData();
  } 
  
  updateBomData(evt) {
    var obj = [];
    var intervalStartIndex = -1;
    var json = [];
    var array = [];

    this.data[0].forEach( item => {     
      if(isNaN(item)){
        this.columns.push(item);
        obj.push({"filterName": item , "filterValue" : []});
      }     
    });
    intervalStartIndex = obj.length;    
    for( var i = 1; i< this.data.length ; i++){
        var tempArray = this.data[i];      
        var objTemp = {};
        for( var j = 0 ; j<intervalStartIndex ; j++){
          objTemp[obj[j]["filterName"]] =  tempArray[j];                          
        }   
        json.push(objTemp);               
    }     
    array = this.columns;
    this.columns  = array.filter(function(item, pos) {
      return array.indexOf(item) == pos;
    })
    this.mappedData = json;    
    this.updateBomsData();
  }

  updateBomsData() {
    this.updateFleetService.updateBomData(this.mappedData).then(result =>{            
        console.log(result);    
        this.onBomUpdateSuccess();
    })
    .catch(error =>  this.onBomUpdateFail());
  }

  updateFleetData() {
    this.updateFleetService.updateFleetData(this.mappedData).then(result =>{            
        console.log(result);    
        this.onFleetUpdateSuccess();
    })
    .catch(error =>  this.onFleetUpdateFail());
  }

  onFleetUpdateSuccess() {
      PNotify.removeAll();
      // UI Changes (Changed width to 500 from 300
    new PNotify({
        text: 'Updated Fleet Successfully',
        delay: 1000,
        width: 500,
        type :'success'       
    });
  }

  onBomUpdateSuccess() {
      PNotify.removeAll();
    // UI Changes (Changed width to 500 from 300
    new PNotify({
        text: 'Updated Bom Successfully',
        delay: 1000,
        width: 500 ,
        type :'success'       
    });
  }

  onFleetUpdateFail() {
      PNotify.removeAll();
    // UI Changes (Changed width to 500 from 300
    new PNotify({
        text: 'Updated Fleet Successfully',
        delay: 1000,
        width: 500,
        type :'error'       
    });

  }

  onBomUpdateFail() {
      PNotify.removeAll();
    // UI Changes (Changed width to 500 from 300
    new PNotify({
        text: 'UpdatedBomsFleet Successfully',
        delay: 1000,
        width: 500,
        type :'error'       
    });

  }



}
