import {Component, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import * as sha from 'crypto-js';
import {LoginService } from '../services/login.service';

@Component({
    templateUrl: './login-popup.component.html',
    selector: 'app-login-popup',
    styleUrls: ['./login-popup.component.css']
})
export class LoginDlgComponent  {
    username: string;
    password: string;
    
    constructor(public activeModal: NgbActiveModal, public changeRef: ChangeDetectorRef, private loginService: LoginService) {
    }

    onLoginClicked(username,password): void {
        document.getElementById("slide-nav").style.width = "0";
        var resultString;
        this.loginService.authenticateUser(username, sha.SHA512(password)).then(result => result)
            .catch(error => console.log(error));
    }
}

@Injectable() export class LoginDialogService {

    constructor(private modalService: NgbModal) { }

    public show() {
        const modalRef = this.modalService.open(LoginDlgComponent);
        modalRef.componentInstance.name = "showlogindlg";
        modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }
}
