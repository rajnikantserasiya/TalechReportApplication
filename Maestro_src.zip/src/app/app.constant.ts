//load-session
import { Injectable } from '@angular/core';

@Injectable()
export class AppConstant {
    //Root Mapping for external to file functioanilty
    selectedEquipemtRoot = "selectedEquipment";
    selectedSnRoot = "selectedSN";
    sessionDetailsRoot = "sessionDetails";
    exclusionsRoot = "exclusions";
    previewRoot = "previewRoot";
    factorsRoot = "factorsRoot";
    modelMasterRoot = "modelMaster";
    optionsRoot = "options";
    //Application global constants 
    country = "COUNTRY";
    countryCode = "countryCode";
    fileDataSource = "file";
    newSessionDataSource = "new_session";
    oldSessionDataSource = "old_session";
    countryList = "countryList";
    previewSelectedEquipment = "previewSelectedEquipment";
    previewSelected = "previewSelected";    
    partscon_reportInterval= 'partscon_reportInterval';
    partscon_colDropdown = 'partscon_colDropdown';
    partscon_repFormat = 'partscon_repFormat';
    contentRestrictionValue = 'contentRestrictionValue';
    costForcastSubTotalValue = 'costForcastSubTotalValue';
    costForcastReportFormat = 'costForcastReportFormat'; 
    importBomPreview = 'importBomPreview';
    importBomPreviewFileName = 'importBomPreviewFileName';
    activeFilters = 'activeFilters';
    IsAzureADAuthenticationEnabled = true;
};






