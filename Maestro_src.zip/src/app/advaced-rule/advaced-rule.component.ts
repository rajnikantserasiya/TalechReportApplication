import { Component, OnInit, Injectable, Input, EventEmitter, Output, OnChanges, SimpleChange, SimpleChanges } from '@angular/core';
import { AdvancedSearchService } from './../services/advanced-search.service';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

@Component({
    selector: 'app-advaced-rule',
    templateUrl: './advaced-rule.component.html',
    styleUrls: ['./advaced-rule.component.css']
})
export class AdvacedRuleComponent implements OnInit {

    @Input('equipmentSelected') equipmentSelected;
    @Input('resetFilters') resetFilter;
    @Output() filterData: EventEmitter<any> = new EventEmitter();

    mappedTableData = []
    activeFilters = [];
    operators: any = [
        { 'label': 'Like', 'id': 1, 'type': 'string' },
        { 'label': 'Not Like', 'id': 2, 'type': 'string' },
        { 'label': 'In', 'id': 3, 'type': 'string' },
        { 'label': 'Not In', 'id': 4, 'type': 'string' },
        { 'label': '=', 'id': 5, 'type': 'int' },
        { 'label': '<=', 'id': 6, 'type': 'int' },
        { 'label': '>=', 'id': 7, 'type': 'int' },
        { 'label': '>', 'id': 8, 'type': 'int' },
        { 'label': '<', 'id': 9, 'type': 'int' }
        //,{ 'label' : 'between' , 'id' : 10 , 'type' :'int' }                              
    ];
    columns: any = [
        { 'label': 'SectionId', 'id': 1, 'type': 'string' },
        { 'label': 'Section', 'id': 2, 'type': 'string' },
        { 'label': 'Item', 'id': 3, 'type': 'string' },
        { 'label': 'Description', 'id': 4, 'type': 'string' },
        { 'label': 'Qty', 'id': 5, 'type': 'int' },
        { 'label': 'UnitPrice', 'id': 6, 'type': 'int' },
        { 'label': 'LifetimeHours', 'id': 7, 'type': 'int' }
    ];
    rules: any = [{
        'IsActive': false,
        'ColumnName': 'Equipment',
        'Operator': '+',
        'Value1': '200',
        'Value2': null,
        'ID': 23
    },
        {
            'IsActive': false,
            'ColumnName': 'Equipment',
            'Operator': '<=',
            'Value1': '200',
            'Value2': null,
            'ID': 23
        },
        {
            'IsActive': false,
            'ColumnName': 'Equipment',
            'Operator': '>=',
            'Value1': '200',
            'Value2': '300',
            'ID': 23
        }
    ];

    cols = [
        { field: 'IsInclude', header: '', width: '3%' },
        { field: 'ColumnName', header: 'Column', width: '7%' },
        { field: 'Operator', header: 'Operator', width: '7%' },
        { field: 'valuesFrom', header: 'Values 1', width: '7%' },
        { field: 'valuesTo', header: 'Values 2', width: '7%' }
    ];

    selectUnselect: string = "Select All";
    selectAllFilter = false;
    loadFlag: boolean = false;
    selectedOp: any = "select";
    selectedCol: any = "select";
    Value1: any;
    Value2: any;
    values: string;

    constructor(private advancedSearchService: AdvancedSearchService, public activeModal: NgbActiveModal) {
    }

    ngOnInit() {
        this.rules = [];
        this.activeFilters = [];
        this.getMappedData();
        this.fetchRules();
    }

    getMappedData() {
        this.advancedSearchService.getMappedData().then((data) => {
            if (data) {
                this.handleResponse(data);
            }
        })
            .catch(error => console.log(error));
    }

    handleResponse(data) {
        this.mappedTableData = data;
        this.mappedTableData.forEach(item => {
            var temp = this.activeFilters.filter(filter => {
                return filter['label'] === item['NFW_Group'];
            });
            if (temp.length > 0) {
                console.log('item already present , push the family code if not present');
                this.activeFilters.forEach(filter => {
                    if (filter['label'] === item['NFW_Group']) {
                        if (filter['Family_Code'].indexOf(item['Family_Code']) < 0) {
                            filter['Family_Code'].push(item['Family_Code']);
                        }
                    }
                });
            } else {
                var obj = { 'label': item['NFW_Group'], 'Family_Code': [], 'type': 'NFW_Group', 'selected': false };
                obj['Family_Code'].push(item['Family_Code']);
                this.activeFilters.push(obj);
            }
        });
    }

    ngOnChanges(changes) {
        if (changes['resetFilter'] && changes['resetFilter'].currentValue) {
            this.resetFilters();
        }
    }

    resetFilters() {
        this.activeFilters.forEach(item => {
            item['selected'] = true;
        });
    }

    onModelChange(value, data) {
        data['selected'] = value;
        var obj = { 'activeFilter': data, 'allFilters': this.activeFilters, 'type': 'single' };
        this.advancedSearchService.setActiveFilters(this.activeFilters);
        this.filterData.emit(obj);
    }

    validateDisable() {
        return this.equipmentSelected.length > 0 && this.equipmentSelected != 'Select equipment' ? false : true;
    }

    getDynamicWidth(col) {
        console.log(col.width);
        return col.width;
    }

    onSelectAll(value) {
        if (value) {
            this.selectUnselect = "Unselect All";
        } else {
            this.selectUnselect = "Select All";
        }
        this.selectAllFilter = value;
        this.activeFilters.forEach(item => {
            item['selected'] = value;
        });
        var obj = { 'activeFilter': [], 'allFilters': this.activeFilters, 'type': 'all' };
        this.advancedSearchService.setActiveFilters(this.activeFilters);
        this.filterData.emit(obj);
    }

    showHideRange() {
        var flag: boolean = true;
        if (this.selectedOp) {
            if (this.selectedOp.indexOf('Like') >= 0 || this.selectedOp.indexOf('Not Like') >= 0 || this.selectedOp.indexOf('In') >= 0 || this.selectedOp.indexOf('Not In') >= 0) {
                flag = true;
            } else {
                flag = false;
            }
        }
        //console.log(this.selectedCol +""+ this.selectedOp );

        return true;
        //return flag;
    }

    onModelDropdownChange(value, type) {
        if (type === "column") {
            this.selectedCol = value;
            if (this.selectedCol.indexOf('Qty') >= 0 || this.selectedCol.indexOf('UnitPrice') >= 0 || this.selectedCol.indexOf('LifetimeHours') >= 0) {
                this.operators = [
                    { 'label': '=', 'id': 5, 'type': 'int' },
                    { 'label': '<=', 'id': 6, 'type': 'int' },
                    { 'label': '>=', 'id': 7, 'type': 'int' },
                    { 'label': '>', 'id': 8, 'type': 'int' },
                    { 'label': '<', 'id': 9, 'type': 'int' }
                    //,{ 'label' : 'between' , 'id' : 10 , 'type' :'int' }                              
                ];
            } else {
                this.operators = [
                    { 'label': 'Like', 'id': 1, 'type': 'string' },
                    { 'label': 'Not Like', 'id': 2, 'type': 'string' },
                    { 'label': 'In', 'id': 3, 'type': 'string' },
                    { 'label': 'Not In', 'id': 4, 'type': 'string' }
                ];
            }
        } else {
            this.selectedOp = value;
        }
    }

    addRule() {
        var obj = [];
        obj.push({
            'ID': '',
            'UserName': localStorage.getItem('userId'),
            'IsActive': 'true',
            'ColumnName': this.selectedCol,
            'Operator': this.selectedOp,
            'Value1': this.Value1,
            'Value2': ''
        });
        if (this.Value2) {
            obj[0]['Value2'] = this.Value2;
        }
        var dataToSend = { 'MaestroRules': obj };
        this.advancedSearchService.saveRules(JSON.stringify(dataToSend)).then(response => {
            if (response) {
                this.clearSelectedValues();
                this.fetchRules();
            }
        });
    }

    clearSelectedValues() {
        this.selectedCol = "select";
        this.selectedOp = "select";
        this.values = "";
        this.Value1 = "";
        this.Value2 = "";
    }

    fetchRules() {
        this.advancedSearchService.fetchRules().then(response => {
            this.rules = response;
            //if(response && response.length > 0) {
            //  this.rules = response;
            //}
        });
    }

    deleteRules() {
        var rulesToDelete = [];
        this.rules.forEach(item => {
            if (item['IsActive']) {
                var obj = {};
                obj['ID'] = item['ID'];
                obj['UserName'] = localStorage.getItem('UserName');
                obj['IsActive'] = "false";
                obj['ColumnName'] = item['ColumnName'];
                obj['Operator'] = item['Operator'];
                obj['Value1'] = item['Value1'];
                obj['Value2'] = item['Value2'];
                if (!obj['Value2']) {
                    obj['Value2'] = '';
                }
                rulesToDelete.push(obj);
            }
        });
        var dataToSend = { 'MaestroRules': rulesToDelete };
        if (true) {
            this.advancedSearchService.deleteRules(JSON.stringify(dataToSend)).then(response => {
                if (response) {
                    console.log('rules deleted successfully');
                    this.fetchRules();
                }
            })
        }
    }

    onInputModelChange(value, field) {
        if (field === "Value1") {
            this.Value1 = value;
        } else {
            this.Value2 = value;
        }
    }

    ngModelCheckBoxChange(value, data) {
        data['IsActive'] = value;
    }

    closeModal() {
        this.rules = [];
        this.clearSelectedValues();
        this.activeModal.dismiss(true);
    }

    validateRemove() {
        var count: number = 0;
        this.rules.forEach(item => {
            if (item['IsActive']) {
                count++;
            }
        });
        return count <= 0;
    }

}



@Injectable() export class AdvancedRuleDialogService {

    constructor(private modalService: NgbModal) { }

    public show() {
        const modalRef = this.modalService.open(AdvacedRuleComponent, { windowClass: "advanced-rule-window" });
        modalRef.componentInstance.name = "advanceRule";
        modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }
}
