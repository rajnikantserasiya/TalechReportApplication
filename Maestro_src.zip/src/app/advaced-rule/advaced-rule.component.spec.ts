import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvacedRuleComponent } from './advaced-rule.component';

describe('AdvacedRuleComponent', () => {
  let component: AdvacedRuleComponent;
  let fixture: ComponentFixture<AdvacedRuleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdvacedRuleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvacedRuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
