import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StartNewSessionPopupComponent } from './start-new-session-popup.component';

describe('StartNewSessionPopupComponent', () => {
  let component: StartNewSessionPopupComponent;
  let fixture: ComponentFixture<StartNewSessionPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StartNewSessionPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StartNewSessionPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
