import {Component, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable } from '@angular/core';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import {LoginService } from '../services/login.service';
import {SaveService } from '../services/save.service';
import { Router } from '@angular/router';
import { DataService } from './../services/data-component.service';
import { ReportService } from '../services/report.service';

@Component({
    selector: 'app-start-new-session-popup',
    templateUrl: './start-new-session-popup.component.html',
    styleUrls: ['./start-new-session-popup.component.css']
})
export class StartNewSessionPopupComponent implements OnInit {

    constructor(public activeModal: NgbActiveModal, public changeRef: ChangeDetectorRef, 
        private loginService: LoginService, private saveService: SaveService, 
        private maestroRouter: Router, private dataService : DataService, 
        private reportService : ReportService) {
        console.log("StartNewSessionPopupComponent construct");
    }

    ngOnInit() {
        console.log("StartNewSessionPopupComponent init");
    }

    onStartNewClicked(): void {
        this.reportService.SaveUserLoginTrack("Start New Session");
        localStorage.removeItem("COUNTRY");
        this.dataService.setOptionsPriceType('GLP');
        this.saveService.deleteMaestroSessionData(localStorage.getItem("UserName")).then(result => {
            if(result){
                this.clearSuccess();    
            }            
        })
        .catch(error => console.log(error));        
    }

    clearSuccess() {     
        localStorage.setItem("PriceListType", "GLP");
        localStorage.removeItem("PriceList");
        localStorage.setItem("PriceListType_Report", "GLP");
        localStorage.removeItem("PriceList_Report");
        localStorage.removeItem("PriceListCountry");
        this.dataService.setOptionsPriceType('GLP');   
        this.dataService.setOptions('maplDropdown', '');
        this.dataService.setOptions('glpDropdown', '');
        this.dataService.setViewBomModel([]);
        this.dataService.clearReferenceForList(true);
        var closeLoginBtn = document.getElementById("btnCancel");
        closeLoginBtn.click();
        this.maestroRouter.navigateByUrl('main');
        setTimeout(() => {
            this.maestroRouter.navigateByUrl('contsession');
        },50);
    }
}

@Injectable() export class StartNewSessionDialogService {

    constructor(private modalService: NgbModal) { }

    public show() {
        const modalRef = this.modalService.open(StartNewSessionPopupComponent);
        modalRef.componentInstance.name = "showlogindlg";
        modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }
}
