import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportsCostForecastComponent } from './reports-cost-forecast.component';

describe('ReportsCostForecastComponent', () => {
  let component: ReportsCostForecastComponent;
  let fixture: ComponentFixture<ReportsCostForecastComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportsCostForecastComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportsCostForecastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
