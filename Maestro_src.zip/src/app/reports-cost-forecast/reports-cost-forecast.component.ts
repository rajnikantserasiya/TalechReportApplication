import { Component, OnInit } from '@angular/core';
import {ReportService} from '../services/report.service';
import { SelectEquipmentMasterService } from './../services/select-equipment-master.service';
import { GenerateCostReportsService } from '../generate-cost-forecast-reports-popup/generate-cost-forecast-reports-popup.component';
import { DataService } from './../services/data-component.service';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { AppConstant } from './../app.constant';
import { HtmlResultPoupservice } from '../htmlview/html-result.component';
import { CommonService } from '../services/common.service';
declare var jquery: any;
declare var $: any;
declare var PNotify: any;

@Component({
  selector: 'app-reports-cost-forecast',
  templateUrl: './reports-cost-forecast.component.html',
  styleUrls: ['./reports-cost-forecast.component.css'],
  providers: [GenerateCostReportsService, HtmlResultPoupservice]
})
export class ReportsCostForecastComponent  {
    max: Number = 7;
    disableReportschange: boolean = false;
    reportType : any[] = [
        { Name: 'XLS Spreadsheet'},
        { Name: 'Html Report'}
    ];
   
    public restrictNumeric(e) {
        var key = e.keyCode ? e.keyCode : e.which;
        if (!([8, 9, 13, 27, 110, 190].indexOf(key) !== -1 ||
            (key == 65 && (e.ctrlKey || e.metaKey)) ||
            (key >= 35 && key <= 40) ||
            (key == 43 && key == 45) ||
            (key >= 48 && key <= 57 && !(e.shiftKey || e.altKey)) ||
            (key >= 96 && key <= 105)
        )) e.preventDefault();

        if (e.target.value.length >= this.max) e.preventDefault();
    }
    
    public restrictZero(e) {
        var key = e.keyCode ? e.keyCode : e.which;
        if (e.target.value == '' || e.target.value == "0" || e.target.value.length > this.max) e.target.value = 7;

    }

    constructor( private htmlResultPoupservice: HtmlResultPoupservice, private generateCostReportsService: GenerateCostReportsService,private reportService: ReportService, private selectEquipmentMasterService: SelectEquipmentMasterService , private fetchCurrentDataService: FetchCurrentDataService, private appConstant: AppConstant , private dataService : DataService , private commonService : CommonService ) { 
        this.fetchCurrentDataService.screenDataStream$.subscribe(
        () => {
          if (!this.fetchCurrentDataService.disableFlagSaveCostForcast) {
            this.fetchCurrentDataService.disableFlagSaveCostForcast = true;            
            console.log('Fetching data for Report - Cost Forecast');  
          }
        });  
    }

    ngOnInit() {

        // UI Changes
        document.getElementById("slide-nav").style.width = "0";
    }

    validateReportGeneration(): boolean {
        let disableReport: boolean = false;
        if (this.reportService.getDownloadInProgress()) {
            disableReport = true;
        } else {
            if (parseInt(this.selectEquipmentMasterService.getSelectedEquipment()) > 0) {

                disableReport = this.disableReportschange;
            } else {
                disableReport = true;
            }
        }
        if (this.dataService.getReportsValue('IsengineHrsValue') == false) {
            disableReport = true;
        }
        return disableReport;
    }

    generateReportDlg(): void {
        if(localStorage.getItem("PriceListType_Report")=="" || localStorage.getItem("PriceList_Report")=="") {
            alert("Please select Price Type and Country in the Option tab.");
        } else {
            this.generateCostReportsService.show();
        }
    }
    
    generateReportDlgHtml(): void {
        if(localStorage.getItem("PriceListType_Report")=="" || localStorage.getItem("PriceList_Report")=="") {
            alert("Please select Price Type and Country in the Option tab.");
        } else {
                this.htmlResultPoupservice.show();
        }
    }

}
  