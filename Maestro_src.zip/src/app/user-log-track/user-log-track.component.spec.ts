import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserLogTrackComponent } from './user-log-track.component';

describe('UserLogTrackComponent', () => {
  let component: UserLogTrackComponent;
  let fixture: ComponentFixture<UserLogTrackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserLogTrackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserLogTrackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
