import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddImportBomComponent } from './add-import-bom.component';

describe('AddImportBomComponent', () => {
  let component: AddImportBomComponent;
  let fixture: ComponentFixture<AddImportBomComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddImportBomComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddImportBomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
