import {Component, HostListener, HostBinding, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable } from '@angular/core';
import {EqImportBom} from '../services/eq-exclusions-class';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { DataService } from './../services/data-component.service';
import { AppConstant } from './../app.constant';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { ElementRef } from '@angular/core';
import { CommonUtil }  from './../common/common-util';
import { SelectEquipmentOtherService } from './../services/select-equipment-other.service';




@Component({
    selector: 'app-add-import-bom',
    templateUrl: './add-import-bom.component.html',
    styleUrls: ['./add-import-bom.component.css'],
    providers: [EqImportBom, SelectEquipmentOtherService]
})
export class AddImportBomComponent implements OnInit {

    constructor(public eRef: ElementRef, public commonUtil: CommonUtil, public activeModal: NgbActiveModal, public dataService: DataService,
        private appConstant: AppConstant, private fetchCurrentDataService: FetchCurrentDataService, public selectEquipmentOtherService: SelectEquipmentOtherService) { }

    selectedImportItemsValues: EqImportBom[] = [];
    mappedJson: any = [];

    max: Number = 7;
    maxQty: Number = 2;

    ngOnInit() {
        //debugger;
        this.selectedImportItemsValues = [];
        let selectedMODELValues: string = localStorage.getItem("SelectedMODELValue_Import");
        let selectedMODELCATEGORYValues: string = localStorage.getItem("selectedMODELCATEGORY_Import");
        if (selectedMODELValues != "" && selectedMODELValues != null) {

            this.selectEquipmentOtherService.getLifeHrsFromModel(selectedMODELValues).then(
                result => {                    
                    var Model_HoursTo = "15000";
                    if (result != null && result[0]["EQ_LIFE"]) {
                        Model_HoursTo = result[0]["EQ_LIFE"];
                    }

                    let newName = {
                        UserName: localStorage.getItem("UserName"),
                        EqSourceType: "3",
                        ModelCategory: selectedMODELCATEGORYValues,
                        Model: selectedMODELValues,
                        Quantity: "1",
                        HourFrom: "0",
                        HourTo: Model_HoursTo//"15000",
                    };
                    this.selectedImportItemsValues.push(newName);
                }
            )
                .catch(error => console.log(error));
            //selectEquipmentOtherService


        }

    }

    trackByIndex(index: number, value: number) {
        return index;
    }
    close() {
        this.activeModal.dismiss(true);
    }

    public restrictNumeric(e) {
        var key = e.keyCode ? e.keyCode : e.which;
        if (!([8, 9, 13, 27, 110, 190].indexOf(key) !== -1 ||
            (key == 65 && (e.ctrlKey || e.metaKey)) ||
            (key >= 35 && key <= 40) ||
            (key == 43 && key == 45) ||
            (key >= 48 && key <= 57 && !(e.shiftKey || e.altKey)) ||
            (key >= 96 && key <= 105)
        )) e.preventDefault();

        if (e.target.value.length >= this.max) e.preventDefault();
    }

    public restrictQtyNumeric(e) {
        var key = e.keyCode ? e.keyCode : e.which;
        if (!([8, 9, 13, 27, 110, 190].indexOf(key) !== -1 ||
            (key == 65 && (e.ctrlKey || e.metaKey)) ||
            (key >= 35 && key <= 40) ||
            (key == 43 && key == 45) ||
            (key >= 48 && key <= 57 && !(e.shiftKey || e.altKey)) ||
            (key >= 96 && key <= 105)
        )) e.preventDefault();

        if (e.target.value.length >= this.maxQty) e.preventDefault();
    }

    public restrictZero(e) {
        var key = e.keyCode ? e.keyCode : e.which;
        if (e.target.value == '' || e.target.value == "0" || e.target.value.length > this.max)
        { e.target.value = 1 };
    }

    public restrictQty(e) {
        var key = e.keyCode ? e.keyCode : e.which;
        if (e.target.value == '' || e.target.value == "0" || e.target.value.length > this.maxQty)
        { e.target.value = 1 };
    }

    onOkAddImportBomMasterClicked(selectedImportItemsValues: any): any {

        this.dataService.setData(this.appConstant.selectedEquipemtRoot, [], true);
        this.fetchCurrentDataService.addImportBomModel(selectedImportItemsValues);
        var closeLoginBtn = document.getElementById("add-model-import-popupCloseBtn");
        closeLoginBtn.click();
        localStorage.removeItem("SelectedMODELValue_Import");
        localStorage.removeItem("selectedMODELCATEGORY_Import");

    }

    onModelChange(value, field, data) {
        //debugger;
        var ngNativeEl = this.eRef.nativeElement.querySelector('#' + field + data['Model'].split(' ').join(''));
        if (value) {
            var temp = value.toString() || "";
            switch (field) {
                case 'Quantity':
                    if (this.commonUtil.checkSpecialRegex(temp, false, false) || temp.length > this.maxQty) {
                        value = data[field];
                        ngNativeEl.value = data[field];
                    } else {
                        data[field] = value;
                    }
                    break;

                case 'HourFrom':
                    if (this.commonUtil.checkSpecialRegex(temp, false, false) || temp.toString().length > this.max) {
                        value = data[field];
                        ngNativeEl.value = data[field];
                    } else {
                        data[field] = value;
                    }
                    break;

                case 'HourTo':
                    if (this.commonUtil.checkSpecialRegex(temp, false, false) || temp.toString().length > this.max) {
                        value = data[field];
                        ngNativeEl.value = data[field];
                    } else {
                        data[field] = value;
                    }
                    break;

                default: break;
            }
        }
    }

    setDynamicId(field, data) {
        //debugger;
        var id: string = "";
        if (data['SerialNo'] && data['SerialNo'].toLowerCase() === "n/a") {
            id = field + (data['Model']);
        } else if (data['Model'] && data['Model'].toLowerCase() === "n/a") {
            id = field + (data['SerialNo']);
        } else {
            id = field + (data['Model']);
        }

        id = id.replace(/\s/g, "");
        return id;
    }

}

@Injectable() export class AddImportBomService {

    constructor(private modalService: NgbModal) { }

    public show() {
        const modalRef = this.modalService.open(AddImportBomComponent);
        modalRef.componentInstance.name = "showaddimportbompopup";
        modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }
}
