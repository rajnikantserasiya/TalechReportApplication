import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoadSessionSpecificationTabComponent } from './load-session-specification-tab.component';

describe('LoadSessionSpecificationTabComponent', () => {
  let component: LoadSessionSpecificationTabComponent;
  let fixture: ComponentFixture<LoadSessionSpecificationTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoadSessionSpecificationTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoadSessionSpecificationTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
