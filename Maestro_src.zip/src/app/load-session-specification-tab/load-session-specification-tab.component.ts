import { Component, OnInit } from '@angular/core';
import { TreeModule,TreeNode,TreeTableModule , DataTableModule } from 'primeng/primeng';
import { DialogModule } from 'primeng/dialog';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { SelectEquipmentMasterService } from './../services/select-equipment-master.service';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { DataService } from './../services/data-component.service';
import { AppConstant } from './../app.constant';
import { LoadOldSessionDialogService } from '../load-old-session-popup/load-old-session-popup.component';
import { UpdateFleetService }  from '../services/update-fleet.service';

declare var jquery: any;
declare var $: any;
declare var PNotify: any;

@Component({
  selector: 'app-load-session-specification-tab',
  templateUrl: './load-session-specification-tab.component.html',
  styleUrls: ['./load-session-specification-tab.component.css'],
  providers: [ConfirmationService , LoadOldSessionDialogService]
})

export class ContSessionComponent  {

  contSessionTitle   = "Continue Existing Session [ BHP_AU_2017_09 ] > "
  tab1Title    = "1) Select Equipment";
  tab2Title    = "2) Exclusions";
  tab3Title    = "3) Options";
  tab4Title    = "4) Factors";
  tab5Title      = "5) Preview";
  tab6Title      = "6) Reports";
  tab1tab1Title    = "Existing SN";
  tab1tab2Title    = "Model Masters";
  tab1tab3Title    = "Other";
  flag = true;
  resetModel : any = {
    'tab-existingSN' : true , 
    'tab-modelMasters' : true ,
    'tab-equipmentBom' : true ,
    'tab-reports' : true ,
    'tab-preview' : true ,
    'tab-factors' : true ,
    'tab-options' : true ,
    'tab-exclusion' : true ,
    'tab-selectEquip' : true 
  };
  displayConfirmBox : boolean = false;
  event : any;
  skipTabChange = false;
  
  constructor(private fetchCurrentDataService : FetchCurrentDataService , private dataService : DataService , private  appConstant : AppConstant , private confirmationService : ConfirmationService , private loadOldSessionDialogService : LoadOldSessionDialogService , private updateFleetService : UpdateFleetService) { 
    console.log("ContSessionComp ctor");      
  }
 
  onUpdateEqbySn(e: SelectEquipmentMasterService[]) {
    console.log("ev to par");
  }
  
  getActiveTab(event) {  
    var changeFlag =  this.dataService.getSkipTabChange(event.activeId); 
    if(event.activeId) {
      this.dataService.setActiveTab(event.activeId);
    }
    if(!changeFlag){     
      this.dataService.setSkipTabChange(false , event.activeId);
      var txt = "";
      var changesFlag  = false;
      this.event = event;
      if(event.activeId === "tab-exclusion" || event.activeId === "tab-preview" || event.activeId === "tab-factors" ||  event.activeId === "tab-options" ) {       
        changesFlag = this.dataService.getTabModified(event.activeId);  
        if(changesFlag){   
          event.preventDefault();           
          this.confirmationService.confirm({
            message: 'Do you want to save the data before proceeding ?',
            header: 'Confirmation',
            icon: 'fa fa-question-circle',
            accept: () => {             
              this.onConfirmClick(event);
            },
            reject: () => {
              this.onAlertReject(event);
            }
          });       
          console.log(txt);                
        }                       
      }   
    }    
  }

  onConfirmClick(event) {  
      this.dataService.setSkipTabChange(true , event.activeId);       
      document.getElementById(event.activeId+'-save').click();  
      document.getElementById('select-tab').click();

      // UI Changes
      //PNotify.prototype.options.styling = "fontawesome";
      //PNotify.prototype.options.stack.firstpos2 = 250;
      //new PNotify({
      //    text: 'Saving Data',
      //    delay: 1000,
      //    width: 300  
      //});             
  }
  
  onAlertReject(event) {
    this.dataService.setSkipTabChange(true , event.activeId);         
    this.dataService.setTabModified(event.activeId, false); 
    document.getElementById(event.activeId+'-reset').click();     
    document.getElementById('select-tab').click();    
  }

  reloadTab(t , subTab) {    
    t.tabs.setDirty(true);
    t.select(t.activeId);    
    document.getElementById(t.activeId).click();
    this.fetchCurrentDataService.setActiveTab(t.activeId);
    this.resetModel[t.activeId] = false;
    setTimeout(() => {
      this.resetModel[t.activeId] = true;
      if(t.activeId === "tab-exclusion") {
        this.excludeParentNodes();
      }
    },100);
  }

  continueTabLoad(parentTab , childTab) {
    if(this.event && this.event.nextId) {
      parentTab.select(this.event.nextId);         
    }    
  }

  excludeParentNodes() {   
    var selectEquip : any = this.dataService.getData(this.appConstant.selectedEquipemtRoot);
    var nodes = selectEquip.map(Equipment => <TreeNode> {
      label: Equipment["Model"] +' SN :' + Equipment["SerialNo"] +' ('+ Equipment["Quantity"] +')',
      leaf: false,
      level: 0,
      value: [Equipment],
      IsInclude : this.getSelected(Equipment["Model"] +' SN :' + Equipment["SerialNo"] +' ('+ Equipment["Quantity"] +')')
    });  
    this.dataService.setData('exclusionParentList', nodes , true); 
  }

  getSelected(label) {
    var cachedExclusionParent = this.dataService.getExclusionParentListCached();
    cachedExclusionParent = cachedExclusionParent.filter( item => {
      return item['label'] === label;
    });
    return cachedExclusionParent.length>0 ? cachedExclusionParent[0]["IsInclude"] : "True";
  }

  reRenderData(parentTab , childTabEquip) {
    return this.resetModel[parentTab];          
  }
}
