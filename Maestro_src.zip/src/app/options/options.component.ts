import { Component, OnInit, ElementRef } from '@angular/core';
import {EqExclusionsServiceService} from '../services/eq-exclusions-service.service';
import { DataService } from './../services/data-component.service';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { AppConstant } from './../app.constant';
import { CountryList } from '../services/eq-exclusions-class';
import {OptionsComponentService} from '../services/options-component.service';
import { SelectEquipmentMasterService } from './../services/select-equipment-master.service';


@Component({
    selector: 'app-options',
    templateUrl: './options.component.html',
    styleUrls: ['./options.component.css']
})
export class OptionsComponent implements OnInit {
    price: string;
    public countryList: any = [];
    CountryCode;
    CountryCode2;

    constructor(private eRef: ElementRef, private eqExclusionsServiceService: EqExclusionsServiceService, private dataService: DataService, private appConstant: AppConstant, private fetchCurrentDataService: FetchCurrentDataService, private optionsComponentService: OptionsComponentService, private selectEquipmentMasterService: SelectEquipmentMasterService) {
        this.fetchCurrentDataService.screenDataStream$.subscribe(
            () => {
                //debugger;
                if (!this.fetchCurrentDataService.disableFlagSaveOptions) {
                    this.fetchCurrentDataService.disableFlagSaveOptions = true;
                    if (this.dataService.getOptionsPriceType().length > 0) {
                        this.price = this.dataService.getOptionsPriceType();
                    }
                    // Load JSON Changes
                    this.CountryCode = this.dataService.getOptions('maplDropdown');
                    this.CountryCode2 = this.dataService.getOptions('glpDropdown');

                    var obj = [{ 'price': this.price, 'glpDropdown': this.CountryCode2, 'maplDrodown': this.CountryCode }];
                    this.fetchCurrentDataService.createJsonToSave(obj, this.appConstant.optionsRoot);
                }
            });
    }

    ngOnInit() {
        setTimeout(() => {
            var priceList: any = [];
            var dropdownValue;
            this.dataService.setSkipTabChange(false, 'all');
            document.getElementById("slide-nav").style.width = "0";
            this.price = this.dataService.getOptionsPriceType() || "";
            this.CountryCode2 = this.dataService.getOptions('glpDropdown') || "";
            this.CountryCode = this.dataService.getOptions('maplDropdown') || "";

            if (this.price.length <= 0 && this.CountryCode.length <= 0 && this.CountryCode2.length <= 0) {
                this.getOptionsData();
            } else {
                if (this.CountryCode2.indexOf('-') >= 0) {
                    priceList = this.CountryCode2.split('-');
                    if (priceList.length == 2) {
                        priceList = this.dataService.getPriceListFromCountryAndPriceType(priceList[0], priceList[1]);
                        dropdownValue = this.CountryCode2 + "-" + priceList;
                        this.CountryCode2 = dropdownValue;
                        this.dataService.setOptions('glpDropdown', this.CountryCode2);
                    }
                }


                if (this.CountryCode.indexOf('-') >= 0) {
                    priceList = this.CountryCode.split('-');
                    if (priceList.length == 2) {
                        priceList = this.dataService.getPriceListFromCountryAndPriceType(priceList[0], priceList[1]);
                        dropdownValue = this.CountryCode + "-" + priceList;
                        this.CountryCode = dropdownValue;
                        this.dataService.setOptions('maplDropdown', this.CountryCode);
                    }
                }
            }

            if (this.dataService.getData('optionsCountryList').length > 0) {
                this.countryList = this.dataService.getData('optionsCountryList');
            }
        }, 500);
    }

    filterItemsOfType(type) {
        return this.countryList.length > 0 ? this.countryList.filter(x => x.ListType == type) : [];
    }

    onPriceRadioChecked(value): void {
        this.dataService.setTabModified('tab-options', true);
        document.getElementById("slide-nav").style.width = "0";
        this.price = value;
        localStorage.setItem("PriceListType", this.price);
        this.dataService.setOptionsPriceType(this.price);
    }

    onPriceRadioCheckedGLP(value): void {
        this.dataService.setTabModified('tab-options', true);
        document.getElementById("slide-nav").style.width = "0";
        this.price = value;
        localStorage.setItem("PriceListType", this.price);
        this.dataService.setOptionsPriceType(this.price);
    }

    getPriceUpdateMAPL(value) {
        this.dataService.setOptions('maplDropdown', value);
        this.dataService.setTabModified('tab-options', true);
        //priceList
        var priceList = value.split('-')[2];
        //countryCode
        var priceListCountry = value.split('-')[1];
        this.CountryCode = value;
        this.price = "MAPL";
        localStorage.setItem("PriceListType", this.price);
        localStorage.setItem("PriceList", priceList);
        localStorage.setItem("PriceListType_Report", this.price);
        localStorage.setItem("PriceList_Report", priceList);
        localStorage.setItem("PriceListCountry", priceListCountry);
        document.getElementById("slide-nav").style.width = "0";
        this.dataService.clearScreenList("PreviewList");
    }

    getPriceUpdateGLP(value) {
        //debugger;
        this.dataService.setOptions('glpDropdown', value);
        this.dataService.setTabModified('tab-options', true);
        var priceList = value.split('-')[2];
        var priceListCountry = value.split('-')[1];
        this.CountryCode2 = value;
        this.price = "GLP";
        localStorage.setItem("PriceListType", this.price);
        localStorage.setItem("PriceList", priceList);
        localStorage.setItem("PriceListType_Report", this.price);
        localStorage.setItem("PriceList_Report", priceList);
        localStorage.setItem("PriceListCountry", priceListCountry);
        document.getElementById("slide-nav").style.width = "0";
        this.dataService.clearScreenList("PreviewList");
        this.eqExclusionsServiceService.updateGLPMAPLPrice(this.price, priceList)
            .then(result => { })
            .catch(error => console.log(error));
    }

    saveOptionsData() {
        var mapl;
        var glp;
        var maplPriceList;
        var glpPriceList;
        if (this.CountryCode.indexOf('-') > 0) {
            mapl = this.CountryCode.split('-')[1];
            maplPriceList = this.CountryCode.split('-')[2];
        }
        if (this.CountryCode2.indexOf('-') > 0) {
            glp = this.CountryCode2.split('-')[1];
            glpPriceList = this.CountryCode2.split('-')[2];
        }
        var obj = [{ 'PriceType': this.price, 'MAPLCountryCode': mapl, 'GLPCountryCode': glp, 'UserName': localStorage.getItem('UserName'), 'GLPPriceList': glpPriceList, 'MAPLPriceList': maplPriceList }];
        this.dataService.setTabModified('tab-options', false);
        this.optionsComponentService.saveOptionsData(JSON.stringify(obj)).then(
            (response) => {
                this.dataService.setSkipTabChange(false, 'all');
                console.log('data saved');
            },
            (error) => {
                console.log(error);
            },
            () => {
                console.log('request completed');
            }
        )
    }

    validateSave() {
        return !this.dataService.getTabModified('tab-options');
    }

    resetOptionsData() {
        this.getOptionsData();
    }


    getOptionsData() {

        this.optionsComponentService.getOptionsData().then(result => {
            if (result) {
                var priceListGLP;
                var priceListMAPL;
                var countryList = this.dataService.getData('optionsCountryList');
                this.dataService.clearOptionsData();
                this.price = "";
                this.CountryCode = "";
                this.CountryCode2 = "";
                if (!result[0]['GLPCountryCode'] && !result[0]['MAPLCountryCode']) {
                    this.dataService.setOptions('glpDropdown', 'GLP' + '-' + result[0]['DefaultCountry']);
                    this.dataService.setOptions('maplDropdown', 'MAPL' + '-' + result[0]['DefaultCountry']);
                    this.dataService.setOptionsPriceType('GLP');
                    this.price = 'GLP';
                    localStorage.setItem("PriceListType", "GLP");
                    localStorage.setItem("PriceListType_Report", "GLP");
                    localStorage.setItem("PriceList", result[0]['GLPPriceList']);
                    localStorage.setItem("PriceList_Report", result[0]['GLPPriceList']);
                }
                else {
                    if (!this.dataService.getOptionsPriceType() || this.dataService.getOptionsPriceType().length == 0) {
                        this.dataService.setOptionsPriceType(result[0]['PriceType']);
                        if (result[0]['PriceType'] === "GLP" && result[0]['GLPPriceList']) {
                            localStorage.setItem("PriceListType", "GLP");
                            localStorage.setItem("PriceListType_Report", "GLP");
                            localStorage.setItem("PriceList", result[0]['GLPPriceList']);
                            localStorage.setItem("PriceList_Report", result[0]['GLPPriceList']);
                        } else if (result[0]['PriceType'] === "MAPL" && result[0]['MAPLPriceList']) {
                            localStorage.setItem("PriceListType", "MAPL");
                            localStorage.setItem("PriceListType_Report", "MAPL");
                            localStorage.setItem("PriceList", result[0]['MAPLPriceList']);
                            localStorage.setItem("PriceList_Report", result[0]['MAPLPriceList']);
                        }
                    }
                    if ((!this.dataService.getOptions('glpDropdown') && result[0]['GLPCountryCode']) || (this.dataService.getOptions('glpDropdown').length == 0 && result[0]['GLPCountryCode'])) {
                        this.dataService.setOptions('glpDropdown', 'GLP' + "-" + result[0]['GLPCountryCode'] + "-" + result[0]['GLPPriceList']);
                        this.CountryCode2 = this.dataService.getOptions('glpDropdown');
                    }
                    if ((!this.dataService.getOptions('maplDropdown') && result[0]['MAPLCountryCode']) || (this.dataService.getOptions('maplDropdown').length == 0 && result[0]['MAPLCountryCode'])) {
                        this.dataService.setOptions('maplDropdown', 'MAPL' + "-" + result[0]['MAPLCountryCode'] + "-" + result[0]['MAPLPriceList']);
                        this.CountryCode = this.dataService.getOptions('maplDropdown');
                    }
                }
            }
            this.setPriceList();
        })
            .catch(error => {
                console.log('Error');
            });
    }

    setPriceList() {
        var priceListMapl: any;
        var priceListGLP: any;
        var maplValue;
        var glpValue = this.dataService.getOptions('glpDropdown');
        if (glpValue.indexOf('-') >= 0) {
            priceListGLP = glpValue.split('-');
            if (priceListGLP.length == 2) {
                priceListGLP = this.dataService.getPriceListFromCountryAndPriceType(priceListGLP[0], priceListGLP[1]);
                glpValue = glpValue + "-" + priceListGLP;
                this.dataService.setOptions('glpDropdown', glpValue);
                this.CountryCode = glpValue;
            }
        }

        maplValue = this.dataService.getOptions('maplDropdown');
        if (maplValue.indexOf('-') >= 0) {
            priceListMapl = maplValue.split('-');
            if (priceListMapl.length == 2) {
                priceListMapl = this.dataService.getPriceListFromCountryAndPriceType(priceListMapl[0], priceListMapl[1]);
                maplValue = maplValue + "-" + priceListMapl;
                this.dataService.setOptions('maplDropdown', maplValue);
                this.CountryCode2 = maplValue;
            }
        }
        if (this.dataService.getOptionsPriceType() === 'GLP') {
            localStorage.setItem("PriceList", priceListGLP);
            localStorage.setItem("PriceList_Report", priceListGLP);
        } else {
            localStorage.setItem("PriceList", priceListMapl);
            localStorage.setItem("PriceList_Report", priceListMapl);
        }
    }

    processEquipResult(result) {
        if (result && result.length > 0) {
            if (!result[0]['PriceType']) {
                this.dataService.setOptionsPriceType('GLP');
            } else {
                this.dataService.setOptionsPriceType(result[0]['PriceType']);
            }
            if (result[0]['GLPCountryCode']) {
                this.dataService.setOptions('glpDropdown', result[0]['PriceType'] + "-" + result[0]['GLPCountryCode']);
            }
            if (result[0]['MAPLCountryCode']) {
                this.dataService.setOptions('maplDropdown', result[0]['PriceType'] + "-" + result[0]['MAPLCountryCode']);
            }
        }
    }
}
