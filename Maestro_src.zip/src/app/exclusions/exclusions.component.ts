import { Component, OnInit, ViewEncapsulation, Input, EventEmitter, Output ,ViewChild} from '@angular/core';
import {TreeModule, TreeNode } from 'primeng/primeng';
import { TreeTableModule, DataTableModule } from 'primeng/primeng';
import {EqExclusionsServiceService} from '../services/eq-exclusions-service.service';
import {EqExclusionsClass} from '../services/eq-exclusions-class';
import {EqExclusionsList} from '../services/eq-exclusions-class';
import {EqSelectedList} from '../services/eq-exclusions-class';
import { SelectEquipmentMasterService } from './../services/select-equipment-master.service';
import { Observable } from 'rxjs/Observable';
import { DataService } from './../services/data-component.service';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { AppConstant } from './../app.constant';
import { CommonUtil }  from './../common/common-util';
import { AdvancedSearchService } from './../services/advanced-search.service';
import { ContextMenuModule } from 'primeng/contextmenu';
import { MenuItem } from 'primeng/api';

declare var jquery: any;
declare var $: any;

@Component({
    selector: 'app-exclusions',
    templateUrl: './exclusions.component.html',
    styleUrls: ['./exclusions.component.css'],
    providers: [EqExclusionsClass, EqExclusionsList, EqSelectedList]
})
export class ExclusionsComponent implements OnInit {

    @ViewChild("ptree") ptree;

    searchboxText = "Search";
    selectedNodesArray: TreeNode[] = [];
    eqs: TreeNode[];
    nodes: TreeNode[] = [];
    regions: any = [];
    checkSelectedCount: number = 0;
    treeCollapsedCount: number = -1;
    parentNodeConfig = { "isPartialSelected": false, "isSelected": false };
    exclusionMasterList: any = [];
    isChecked = 0;
    isUnchecked = 0;
    tempNode: any = [];
    searchText: string = "";
    acyclicNode: any;
    setDirty: boolean = false;
    public ExclusionsClassList: EqExclusionsClass[] = [];
    public objEquipmentData: EqExclusionsList[] = [];
    public equipmentsSelected: any = [];
    loadflag = true;
    noEqipSelectedMessage: boolean = false;
    objValue: string[] = [];
    tempNode1: any;
    selectedEquipment: string = "";
    resetFilter: boolean = false;
    filterModifiedFlag: boolean = false;
    items: any = [];
    rightClickTargetNode: any = [];
    treatAsLeafItem: boolean = false;
    scrollFlag = true;
    selectedParentNode = [];


    constructor(private eqExclusionsServiceService: EqExclusionsServiceService, private eqExclusionsClass: EqExclusionsClass, private eqExclusionsList: EqExclusionsList, private eqSelectedList: EqSelectedList, private selectEquipmentMasterService: SelectEquipmentMasterService, private dataService: DataService, private fetchCurrentDataService: FetchCurrentDataService, private appConstant: AppConstant, private commonUtil: CommonUtil, private advancedSearchService: AdvancedSearchService) {
        this.fetchCurrentDataService.screenDataStream$.subscribe(
            () => {
                if (!this.fetchCurrentDataService.disableFlagSaveExclusion) {
                    this.fetchCurrentDataService.disableFlagSaveExclusion = true;
                    if (this.nodes && this.nodes.length > 0) {
                        this.getNonCyclicData();
                    }
                }
            });

        this.fetchCurrentDataService.refreshScreenStream$.subscribe(
            () => {
                if (!this.fetchCurrentDataService.reloadFlagExclusion) {
                    this.fetchCurrentDataService.reloadFlagExclusion = true;
                    this.reloadScreen();
                }
            });
    }           

    reloadScreen() {
        if (this.fetchCurrentDataService.getActiveTab() === "tab-exclusion") {
            this.selectedNodesArray = [];
            this.nodes = [];
            this.eqs = [];
            this.checkSelectedCount = 0;
            this.treeCollapsedCount = -1;
            this.parentNodeConfig = { "isPartialSelected": false, "isSelected": false };
            this.exclusionMasterList = [];
            this.isChecked = 0;
            this.isUnchecked = 0;
            this.tempNode = [];
            this.searchText = "";
            this.acyclicNode = [];
            this.filterModifiedFlag = false;
            this.ngOnInit();
        }
    }

    fixCachedData() {
        if (this.dataService.getData('exclusionParentList').length > 0) {
            this.loadflag = false;
            this.nodes = this.dataService.getData('exclusionParentList');
            this.nodes.forEach(item => {
                item["children"] = [];
                item["expanded"] = false;
                var filterNode = this.selectedNodesArray.filter(node => {
                    return node.label === item.label && node["IsInclude"] == "True";
                });
                if (filterNode.length == 0) {
                    if (item["IsInclude"] == "True") {
                        this.selectedNodesArray.push(item);
                    }
                }
            });
            this.noEqipSelectedMessage = false;
        }
    }

    ngOnInit() {
        var that = this;
        var activeFilters = this.dataService.getData('activeFilters') || [];
        this.items = [
            {
                label: 'Include Parent',
                command: (event) => {                    
                    that.includeExcludeTargetNode(event, 'Include');
                    //event.originalEvent.preventDefault();
                }
            },
            {
                label: 'Exclude Parent',
                command: (event) => {                    
                    that.includeExcludeTargetNode(event, 'Exclude');
                    //event.originalEvent.preventDefault();            
                }
            }
        ];


        this.dataService.setSkipTabChange(false, 'all');
        document.getElementById("slide-nav").style.width = "0";
        this.setDirty = false;
        $.extend($.expr[':'], {
            'containsi': function (elem, i, match, array) {
                return (elem.textContent || elem.innerText || '').toLowerCase()
                    .indexOf((match[3] || "").toLowerCase()) >= 0;
            }
        });
        if (this.dataService.getData('exclusionParentList').length > 0) {
            this.loadflag = false;
            this.nodes = this.dataService.getData('exclusionParentList');
            this.nodes.forEach(item => {
                item["children"] = [];
                item["expanded"] = false;
              //  item.label = item.label + this.checkEquipmentType(item.value[0].EqSourceType);
                  item.label = item['value'][0]['Model'] + ' SN :' + item['value'][0]['SerialNo'] + ' (' + item['value'][0]['Quantity'] + ')'+ this.checkEquipmentType(item['value'][0]['EqSourceType']);
                var filterNode = this.selectedNodesArray.filter(node => {
                    return node.label + this.checkEquipmentType(node["EqSourceType"]) === item.label && node["IsInclude"] == "True";
                });
                if (filterNode.length == 0) {
                    if (item["IsInclude"] == "True") {
                        this.selectedNodesArray.push(item);
                    }
                }
                
            });
            this.noEqipSelectedMessage = false;
        } else {
            if (this.dataService.getData('selectedEquipment').length == 0) {               
                this.noEqipSelectedMessage = true;
                this.loadflag = false;
            } else {
                this.noEqipSelectedMessage = false;
                this.getExclusionsEquipmenList();
            }
        }              
    }

    findRow(searchValue: string) {
        this.scrollFlag = true;
        document.getElementById("slide-nav").style.width = "0";

        if (this.commonUtil.checkSpecialRegex(searchValue, false, true)) {
            // dont even search if special characters are present
        } else {
            this.searchText = searchValue;
            if (searchValue.length > 3) {
                this.searchNodes(searchValue);
            } else {
                //this.searchNodes(searchValue); 
                if (searchValue.length == 0) {
                    this.nodes.forEach(item => {
                        item["expanded"] = false;
                    });
                }
                $('.ui-treenode-label *').removeClass("rowSelected");
            }
        }
    }

    getExclusionsEquipmenList(): void {
        let equipmentsSelected: EqSelectedList[] = [];
        this.selectEquipmentMasterService.selectedEquipmentMaster()
            .then(result => {
                this.handleEquipmentData(result);
            })
            .catch(error => console.log(error));
    }

    handleEquipmentData(result) {
        

        if (result) {
            this.loadflag = false;
            this.equipmentsSelected = result;
            this.getSupplierEquipment().then((Equipments: EqSelectedList[]) => {
                this.nodes = Equipments.map(Equipment => <TreeNode>{
                    
                    label: Equipment["Model"] + ' SN :' + Equipment["SerialNo"] + ' (' + Equipment["Quantity"] + ')' + this.checkEquipmentType(Equipment["EqSourceType"]),
                    leaf: false,
                    level: 0,
                    value: [Equipment],
                    IsInclude: "True",
                    IsModified: false
                });

                //we can save nodes here as it wont have any children assigned and hence will take less time to render on ui  
                this.dataService.setData('exclusionParentList', this.nodes, true);
                this.nodes.forEach(item => {
                    var filterNode = this.selectedNodesArray.filter(node => {
                        return node.label === item.label;
                    });
                    if (filterNode.length == 0) {
                        this.selectedNodesArray.push(item);
                    }
                });
            });
        }
    }

    checkEquipmentType(equptype:any)
    {
        let selectedEquipment: string = "";
        if(equptype=="3")
        {
            selectedEquipment="_Other"
        } 
        else {
                selectedEquipment=""
            };
    
            return selectedEquipment;
    }
    checkSelected() {
        this.nodes.forEach(item => {
            this.normalize(item);
        });
    }

    normalize(parent) {
        var that = this;
        if (parent && parent.children) {
            for (var i = 0, l = parent.children.length; i < l; ++i) {
                var child = parent.children[i];
                child.index = i;
                if (child["IsInclude"] === "True") {
                    this.removeDuplicatesAndInsert(child);
                }
                this.normalize(child);
            }
        }
    }

    removeDuplicatesAndInsert(node) {
        var indexNode = [];
        var filteredTemp = this.selectedNodesArray.filter(s => {
            return s["Path"] === node["Path"];
        });
        if (filteredTemp.length >= 1) {
            this.selectedNodesArray = this.selectedNodesArray.filter(s => {
                return s["Path"] != node["Path"];
            });
        }
        this.selectedNodesArray.push(node);
    }

    getSupplierEquipment(): Promise<EqSelectedList[]> {
        return new Promise((resolve, reject) => {
            resolve(this.equipmentsSelected);
        });
    }

    getExclusionsList(Equipment: any): Promise<any> {
        let strEquipment: string = "";
        if (Equipment["EqSourceType"] == "1") {
            strEquipment = Equipment["SerialNo"];
        }
        if (Equipment["EqSourceType"] == "2") {
            strEquipment = Equipment["Model"];
        }
        if (Equipment["EqSourceType"] == "3") {
            strEquipment = Equipment["Model"] + " SN " + Equipment["SerialNo"];
        }
        return new Promise((resolve, reject) => {
            resolve(
                this.eqExclusionsServiceService.selectedExclusionsEquipment(Equipment)
                    .then(result => {
                        this.getSupplierEqSelectedLevelFirst(strEquipment, result)
                    })
                    .catch(error => console.log(error)))
        });

    }

    getSupplierEqSelectedLevelFirst(strEquipment: string, result): Promise<any> {
        return new Promise((resolve, reject) => {
            this.regions = JSON.parse(JSON.stringify(result));
            this.regions.forEach(item => {
                item['IsModified'] = false;
            });
            resolve(this.regions);
        });
    }

    includeExcludeTargetNode(event, label) {
        this.treatAsLeafItem = true;
        var node = { node: this.rightClickTargetNode };
        if (label === "Include") {
            if ((!node.node.level) || (node.node.level <= 0) || (this.rightClickTargetNode['IsInclude'] === "True" && !this.rightClickTargetNode['partialSelected']) || (this.rightClickTargetNode['IsInclude'] === true && !this.rightClickTargetNode['partialSelected'])) {
                //do nothing         
                alert('action not allowed');
            } else {
                node.node['partialSelected'] = false;
                this.includeExcludeNode(node.node, true);
            }
        } else {
            if ((!node.node.level) || (node.node.level <= 0) || (this.rightClickTargetNode['IsInclude'] === "False" && !this.rightClickTargetNode['partialSelected']) || (this.rightClickTargetNode['IsInclude'] === false && !this.rightClickTargetNode['partialSelected'])) {
                //do nothing 
                alert('action not allowed');
            } else {
                node.node['partialSelected'] = false;
                this.includeExcludeNode(node.node, false);
            }
        }
        // this.rightClickTargetNode = null; 
    }

    includeExcludeNode(selectedNode, includeParent) {
        //this.skipOuterLoop = false;
        var path = selectedNode["Path"] || "";
        var skipChild = false;
        this.nodes.forEach(node => {
            if (node["Path"] === path) {
                node['IsInclude'] = includeParent ? "True" : "False";
                node['IsModified'] = true;
                this.dataService.setTabModified('tab-exclusion', true);
                this.insertRemoveItem(node, includeParent);
                skipChild = true;
            }
            if (!skipChild && node.children) {
                for (var i = 0; i < node.children.length; i++) {
                    this.modifyNodeManually(node.children[i], selectedNode, includeParent);
                }
            }
        });
    }

    modifyNodeManually(parent, selectedNode, includeParent) {
        var that = this;
        var modified = false;
        var skipChild = false;
        var path = selectedNode["Path"] || "";
        if (parent["Path"] && parent.level >= 0) {
            if (parent["Path"] === path) {
                parent['IsInclude'] = includeParent ? "True" : "False";
                parent['IsModified'] = true;
                this.dataService.setTabModified('tab-exclusion', true);
                this.insertRemoveItem(parent, includeParent);
                skipChild = true;
                // this.skipOuterLoop = true;    
            }
        }
        if (!skipChild && parent && parent.children) {
            for (var i = 0; i < parent.children.length; i++) {
                var child = parent.children[i];
                child.index = i;
                if (!modified && child["Path"] && child["Path"] === path) {
                    this.dataService.setTabModified('tab-exclusion', true);
                    child['IsInclude'] = includeParent ? "True" : "False";
                    child['IsModified'] = true;
                    this.insertRemoveItem(child, includeParent);
                    //modified = true;    
                    //break;
                }
                if (child.children) {
                    this.modifyNodeManually(child, selectedNode, includeParent);
                }
            }
        }
    }


    nodeSelect(node) {
        if (node.node.level && node.node.level != 0 ) {
            this.dataService.setTabModified('tab-exclusion', true);
        }
        document.getElementById("slide-nav").style.width = "0";

        if (node.node) {
            node.node['IsModified'] = true;
            if (node.node["IsInclude"]) {
                node.node["IsInclude"] = "True";
                this.insertRemoveItem(node.node, true);
                if (node.node.children && node.node.children.length > 0) {
                    this.updateCheckBoxBinding(node.node, true);
                }
            }

            if (node.node.parent) {
                var count = 0;
                node.node.parent.children.forEach(item => {
                    if (item["IsInclude"] === "True") {
                        count++;
                    }
                });
                if (count === node.node.parent.children.length) {                    
                    node.node.parent["IsInclude"] = "True";
                    node.node.parent['IsModified'] = true;
                    if(node.node.parent.level != 0 || node.node.parent.level != '0'  ) {
                        this.selectedNodesArray = this.selectedNodesArray.filter(item => {
                            return item['label'] != node.node.parent['label'];
                        });
                        this.selectedNodesArray.push(node.node.parent); 
                        if(node.node.parent.parent) {
                            this.selectParentNodes(node.node.parent.parent, "True"); 
                        }                        
                    }                                                        
                }
            }
        }
    }

    nodeUnselect(node) {
        if (node.node.level && node.node.level != 0 ) {
            this.dataService.setTabModified('tab-exclusion', true);
        } 
        document.getElementById("slide-nav").style.width = "0";
        if (node.node) {
            if (node.node) {
                node.node["IsInclude"] = "False";
                node.node['IsModified'] = true;
                this.insertRemoveItem(node.node, false);
                if (node.node.children && node.node.children.length > 0) {
                    this.updateCheckBoxBinding(node.node, false);
                }
            }
            if (node.node.parent) {
                var count = 0;
                node.node.parent.children.forEach(item => {
                    if (item["IsInclude"] === "False") {
                        count++;
                    }
                });
                if (count === node.node.parent.children.length) {                 
                    node.node.parent["IsInclude"] = "True";
                    node.node.parent['IsModified'] = true;
                    if(node.node.parent.level != 0 || node.node.parent.level != '0'  ) {
                        this.selectedNodesArray = this.selectedNodesArray.filter(item => {
                            return item['label'] != node.node.parent['label'];
                        });
                        this.selectedNodesArray.push(node.node.parent);
                        if(node.node.parent.parent) {
                            this.selectParentNodes(node.node.parent.parent, "True"); 
                        }
                    }                                                                
                }
            }
        }
    }

    updateCheckBoxBinding(node: TreeNode[], flag: boolean) {
        this.updateCheckBoxBindingInNodes(node, flag);
    }

    updateCheckBoxBindingInNodes(parent, flag) {
        var that = this;
        if (parent && parent.children) {
            for (var i = 0, l = parent.children.length; i < l; ++i) {
                var child = parent.children[i];
                child.index = i;
                if (child) {
                    var flagTemp = flag ? "True" : "False";
                    child["IsInclude"] = flagTemp;
                    child['IsModified'] = true;
                    this.insertRemoveItem(child, flag);
                }
                this.updateCheckBoxBindingInNodes(child, flag);
            }
        }
    }

    createListToSave(reloadTab) {
        this.exclusionMasterList = [];
        this.nodes.forEach(item => {
            this.getExclusionDataInList(item, false);
        });
        console.log(this.exclusionMasterList);
        if (this.exclusionMasterList) {
            this.onOkUpdateExclusionClicked(reloadTab);
        }
    }

    getExclusionDataInList(parent, flag) {
        var that = this;
        if (parent && parent.children) {
            for (var i = 0, l = parent.children.length; i < l; ++i) {
                var child = parent.children[i];
                child.index = i;
                if (child["IsModified"]) {
                    var indexNode = [];
                    var filteredTemp = this.exclusionMasterList.filter(s => {
                        return s["Path"] === child["Path"];
                    });
                    if (filteredTemp.length >= 1) {
                        this.exclusionMasterList = this.exclusionMasterList.filter(s => {
                            return s["Path"] != child["Path"];
                        });
                    }
                    this.exclusionMasterList.push(child);
                }
                this.getExclusionDataInList(child, flag);
            }
        }
    }

    onOkUpdateExclusionClicked(reloadTab): any {
        this.dataService.setSkipTabChange(false, 'tab-exclusion');
        this.filterModifiedFlag = true;
        //todo

        var activeFilters = this.dataService.getData('activeFilters') || [];


        this.eqExclusionsServiceService.saveMaestroExclusionData(this.exclusionMasterList, activeFilters).then(
            result => {
                this.dataService.setTabModified('tab-exclusion', false);
                this.dataService.setSkipTabChange(false, 'all');
                if (reloadTab) {
                    this.dataService.clearReferenceForList(false);
                    document.getElementById('reload_tab').click();
                    this.filterModifiedFlag = false;
                }
            }
        )
            .catch(error => console.log(error));
    }

    removeNodeFromSelectedArray(label) {
        var indexToRemove = -1;
        for (var i = 0; i < this.selectedNodesArray.length; i++) {
            if (this.selectedNodesArray[i]["path"] && this.selectedNodesArray[i]["path"] === label) {
                indexToRemove = i;
                break;
            }
        }
        if (indexToRemove > -1) {
            this.selectedNodesArray.splice(indexToRemove, 1);
        }
    }

    getFirstParent(node) {
        var that = this;
        if (node && !node.parent) {
            this.tempNode = node;
        }
        if (node && node) {
            this.getFirstParent(node.parent);
        }
    }

    nodeExpand(event: any) {
        document.getElementById("slide-nav").style.width = "0";
        var that = this;
        if (event.node) {
            var checkSelected = 0;
            if (event.node.level == 0) {
                let Equipment = event.node.value[0];
                if (event.node.children && event.node.children.length > 0) {

                } else {
                    var filterdata = this.dataService.getEqExclusionsMaster(event.node.label, false);
                    var activeFilters = this.dataService.getData('activeFilters') || [];
                    if (filterdata.length > 0 && filterdata[0]["filterValue"].length > 0) {
                        event.node.children = filterdata[0]["filterValue"];
                        var that = this;
                        setTimeout((that) => {
                            this.regions = [];
                            this.checkSelected();                                                           
                           /* this.nodes.forEach(item => {
                                this.onAdvancedFilterAllSearch(item, activeFilters , false);            
                            }); */                                                         
                        }, 3000, this);

                    } else {
                        this.loadflag = true;
                        this.getExclusionsList(Equipment).then((result) => {
                            this.handleLevelZeroOutput(event, result, Equipment);
                        });
                    }
                }
            }
        }
        setTimeout(function (item) {
            if (that.searchText.length > 3) {
                $(".ui-treenode-label *:containsi('" + that.searchText + "')").addClass("rowSelected");
                $('.ui-treenode-label *:not(:containsi(' + that.searchText + '))').removeClass("rowSelected");
            }
        }, 500);
    }

    handleLevelZeroOutput(event, result, Equipment) {       
        if (this.regions && this.regions.length > 0) {
            var regions = JSON.parse(JSON.stringify(this.regions));
            if (event.node.children && event.node.children.length > 0) {
            } else {
                var obj = { "filterName": event.node.label, "filterValue": this.regions };
                this.dataService.setEqExclusionsMaster(obj);
                event.node.children = this.regions;
            }
            var that = this;
            setTimeout((that) => {
                if (event.node && event.node["IsInclude"] == "False") {
                    this.updateCheckBoxBinding(event.node, false);
                }
                this.regions = [];
                this.checkSelected();
                this.nodes.forEach(node => {
                    var activeFilters =  this.dataService.getData('activeFilters')  || [];
                    /* if(node.children) {
                        this.onAdvancedFilterAllSearch(node, activeFilters , true);
                    }*/                          
                });  
                this.loadflag = false;                                                  
            }, 2000, this);
        }
    }

    searchNodes(searchText: string) {
        var count = 0;
        this.nodes.forEach(node => {
            if (node["label"].includes(searchText)) {
                //first search here               
                node["expanded"] = true;
            }
            this.expandCollapseNodes(node, searchText);

        });
        setTimeout(function (item) {
            $(".ui-treenode-label *:containsi('" + searchText + "')").addClass("rowSelected");
            $('.ui-treenode-label *:not(:containsi(' + searchText + '))').removeClass("rowSelected");
        }, 500);

    }

    expandCollapseNodes(parent, searchText) {
        var that = this;
        if (parent && parent.children) {
            for (var i = 0, l = parent.children.length; i < l; ++i) {
                var child = parent.children[i];
                child.index = i;
                if(!child['parent']) {
                    child['parent'] = parent;
                }
                if (child["label"].toUpperCase().includes(searchText.toUpperCase())) {                   
                    this.setScrollPosition(child , i);
                    this.setParentNodes(parent, true);
                }
                this.expandCollapseNodes(child, searchText);
            }
        }
    }

    setScrollPosition(child , index) {
        setTimeout( () => {
            if(this.scrollFlag) {
                this.getParentNodeWithLevel(child , '1');
                this.selectedParentNode['firstLevelIndex'] = index;
                if(this.selectedParentNode){                    
                    this.scrollToSelectionPrimeNgDataTree(child.parent, this.ptree, "ptree" , this.selectedParentNode);    
                }                       
            }
            this.scrollFlag = false;
        },1000);
    }
    
    scrollToSelectionPrimeNgDataTree(selection, tree, elementIdName , firstLevelNode) {
        var parentNodeIndex = 0;
        var childNodeIndex = 0;
    
        this.nodes.forEach( (item , index) => {
            if( item['label'] ===  firstLevelNode.parent['label']) {
                parentNodeIndex = index;
            }
        });
        if (tree.value !== null) {
            var selector = 'span:contains('+this.searchText+')';
            var selection =  $( document.getElementById(elementIdName)).find(selector).parent();
            if(selection.length > 0) {
                selection[0].scrollIntoView();
            }                       
        }           
    }

    getParentNodeWithLevel(node , level) {
        if (node && node.level !=  level  && node.level !='0') {  
            if(node.parent) {
                this.getParentNodeWithLevel(node.parent, level);
            }                      
        } else if (node && node.level == '1') {
            this.selectedParentNode = node;            
        }     
    }

    setParentNodes(node, value) {
        if (node) {
            node['expanded'] = value;
            this.setParentNodes(node.parent, value);
        }
    }

    selectParentNodes(node, value) {
        if (node) {
            node['IsInclude'] = value;
            node['IsModified'] = true;
            node['partialSelected'] = false;
            this.selectedNodesArray = this.selectedNodesArray.filter(item => {
                return item['label'] != node['label'];
            });

            this.selectedNodesArray.push(node);
            if (!node.parent) {
                node['partialSelected'] = false;
            } else {
                this.selectParentNodes(node.parent, value);
            }
           
        }
    }

    getNonCyclicData() {
        var nodes = this.dataService.getEqExclusionsMaster('', true);
        var nodeTemp = [];
        var parentNodes = this.dataService.getData('exclusionParentList');
        var parentTemp: any = [];
        var parentNodeTemp: any = [];
        var exclusionNodeTemp: any = [];
        parentNodes.forEach(item => {
            parentTemp.push({ 'IsInclude': item['IsInclude'], 'label': item['label'], leaf: item['leaf'], level: item['level'], value: item['value'], partialSelected: item['partialSelected'] });
        });
        parentNodeTemp.push(parentTemp);
        nodes.forEach(element => {
            var json;
            var itemIndex;
            var obj = { 'filterName': element["filterName"], 'filterValue': [] };
            this.tempNode1 = [];
            if (element["filterValue"] && element["filterValue"].length > 0) {
                for (var i = 0; i < element["filterValue"].length; i++) {
                    var seen = [];
                    json = JSON.stringify(nodes[0].filterValue, function (key, val) {
                        if (typeof val == "object") {
                            if (seen.indexOf(val) >= 0) {
                                return;
                            }
                            seen.push(val);
                        }
                        return val;
                    });
                    this.acyclicNode = JSON.parse(json);
                    this.acyclicNode.forEach(item => {
                        this.removeCyclicDependency(item);
                    });
                    obj["filterValue"] = this.acyclicNode;
                }
            }
            exclusionNodeTemp.forEach(function (item, index) {
                if (item["filterName"] == obj["filterName"]) {
                    itemIndex = i;
                }
            });
            exclusionNodeTemp.splice(i, 1);
            exclusionNodeTemp = exclusionNodeTemp.filter(s => {
                return s["filterName"] != obj["filterName"];
            });
            exclusionNodeTemp.push(obj);
            this.tempNode1.push([]);

        });
        var obj = [{ 'exclusionParentList': parentTemp, 'exclusionList': exclusionNodeTemp }];
        var filters = this.dataService.getData('activeFilters') || [];
        this.fetchCurrentDataService.createJsonToSave(obj, this.appConstant.exclusionsRoot);       
        this.fetchCurrentDataService.createJsonToSave(filters, this.appConstant.activeFilters);
        console.log(nodeTemp);
    }

    removeCyclicDependency(node) {
        if (node["parent"]) {
            node["parent"] = [];
        }
        if (node.children && node.children.length > 0) {
            for (var i = 0; i < node.children.length; i++) {
                this.removeCyclicDependency(node.children[i])
            }
        }
    }

    checkIfDirty() {
        this.dataService.setIsTabDirty(this.setDirty)
    }

    saveExclusionData(str) {
        if (str === "manual") {
            this.createListToSave(true);
        } else {
            this.createListToSave(false);
        }
    }

    resetExclusionData() {
        this.dataService.clearScreenList('ExclusionList');
    }

    validateSave() {
        var flag = (this.dataService.getTabModified('tab-exclusion') && this.nodes.length > 0);
        if (flag) {
            return false;
        } else {
            if(this.filterModifiedFlag) {
                return false;
            } else {
                return true;
            }            
        }
    }

    filterData(filters) {
        this.loadflag = true;
        this.filterModifiedFlag = true;
        //var activeFilters = this.advancedSearchService.getActiveFilters() || [];
        var activeFilters = filters.activeFilter || [];
        this.nodes.forEach(item => {
            if (filters['type'] && filters['type'] === 'all') {
                this.onAdvancedFilterAllSearch(item, filters , false);
            } else {
                this.onAdvancedFilterSearch(item, activeFilters);
            }
        });
        setTimeout(item => {
            this.loadflag = false;
        }, 1000)
    }

    onAdvancedFilterSearch(parent, filters) {
        var that = this;
        var commCodeFlag = false;                        
        if (parent && parent.children) {
            for (var i = 0, l = parent.children.length; i < l; ++i) {
                var child = parent.children[i];
                child.index = i;                    
                if (child) {                   
                    if (filters['IsActive'] && filters['Family_Code'].indexOf(child['commCode']) >= 0) {                                                                                                 
                        if (!this.validateMasterRules(filters , child)) {
                            this.includeExcludeItem('include' , child);  
                        }                          
                    } else if (!filters['IsActive'] && filters['Family_Code'].indexOf(child['commCode']) >= 0) {                                              
                        if (!this.validateMasterRules(filters , child)) {
                            this.includeExcludeItem('exclude' , child);  
                        }                           
                    }
                }
                if (child['IsInclude'] == "True") {
                    this.onAdvancedFilterSearch(child, filters);
                }

            }
        }
    }

    insertRemoveItem(child, insert) {
        var tempnodes = this.selectedNodesArray.filter(node => {
            return node['Path'] === child['Path'];
        });
       // console.log(tempnodes);
        this.selectedNodesArray = this.selectedNodesArray.filter(node => {
            return node['Path'] != child['Path'];
        });
        if (insert) {
            this.selectedNodesArray.push(child);
        }
    }
     
    includeExcludeItem(action , child) {
        if(action === 'include') {
            if(child['IsInclude'] == "False") {                          
                this.dataService.setTabModified('tab-exclusion', true);         
            }
            child['IsModified'] = true;   
            child['IsInclude'] = "True";                      
            this.insertRemoveItem(child, true);
            if (child.children && child.children.length > 0) {
                console.log(child);                            
                this.updateCheckBoxBinding(child, true);                                                                                             
            } 
        } else {
            if(child['IsInclude'] == "True") {                           
                this.dataService.setTabModified('tab-exclusion', true);
            }
            child['IsModified'] = true;   
            child['IsInclude'] = "False";                                                          
            this.insertRemoveItem(child, false);
            if (child.children && child.children.length > 0) {
                console.log(child);                           
                this.updateCheckBoxBinding(child, false);                                       
            }  
        }
    }

    onAdvancedFilterAllSearch(parent, activeFilters , skipModify = false) {
        var that = this;
        var activeFilters = this.dataService.getData('activeFilters') || [];                     
        if (parent && parent.children) {
            for (var i = 0, l = parent.children.length; i < l; ++i) {
                var child = parent.children[i];                 
                child.index = i;               
                if (child) {  
                    var  count  = {'isChecked': 0 , 'isUnchecked' :0};                 
                    activeFilters.forEach(filter => {
                        if (filter['IsActive'] && filter['Family_Code'].indexOf(child['commCode']) >= 0) {                           
                            if (!this.validateMasterRules(filter , child)) {
                                this.includeExcludeItem('include' , child);  
                            }                                                     
                            count.isChecked++;                           
                        } else if (!filter['IsActive'] && filter['Family_Code'].indexOf(child['commCode']) >= 0) {                           
                            if (!this.validateMasterRules(filter , child)) {
                                this.includeExcludeItem('exclude' , child);  
                            }  
                            count.isUnchecked++;                            
                        }
                    });
                    if(count.isChecked > 0 && count.isUnchecked > 0) {                      
                        this.includeExcludeItem('exclude', child);                   
                    }
                }
                if (child['IsInclude'] == "True") {
                    this.onAdvancedFilterAllSearch(child, activeFilters ,skipModify = false);
                }
            }
        }
    }

    includeAllFilters() {
        var activeFilters = this.dataService.getData('activeFilters')  || [];
        this.loadflag = true;
        setTimeout(() => {
            this.loadflag = false;
        }, 0);
    }

    onNodeContextMenuSelect(event, cm, tn) {
        //tn.onNodeContextMenuSelect.unsubscribe();
        if (event.node.parent) {
            this.rightClickTargetNode = event.node.parent;
        }
        event.originalEvent.preventDefault();
        // event.originalEvent = null;
    }

    onSelectionchange(value) {
        this.selectedNodesArray = value;
    }
    
    validateMasterRules(filter , item) {
        var flag = false;
        //WHERE ((Not ((NFW_definitions_180516.Family_Code) Like "*4412*" Or (NFW_definitions_180516.Family_Code) Like "*4307*")) AND ((NFW_definitions_180516.NFW_Group)="HOSES") AND (Not ((ITEM_MASTER.DESC_ENG) Like "*REFRIGE*" Or (ITEM_MASTER.DESC_ENG) Like "*fuel*")));
        if(!(filter['Family_Code'].indexOf('4412') >= 0  || filter['Family_Code'].indexOf('4307') >=0 ) &&  filter['NFWGroupName'] === 'HOSES' &&  (item['Description'].indexOf('REFRIGE') >=0  || item['Description'].indexOf('fuel') >=0 )) {
            flag = true;
        }
        //WHERE (((NFW_definitions_180516.NFW_Group) Like "*WINDOWS*") AND (Not ((ITEM_MASTER.DESC_ENG) Like "*LATH*" Or (ITEM_MASTER.DESC_ENG) Like "*SHADE*")));
        else if((filter['NFWGroupName'].indexOf('WINDOWS') >=0 ) && ((item['Description'].indexOf('LATH') >=0  || item['Description'].indexOf('SHADE') >=0 ))) {
            flag = true;
        }
        //wHERE (((NFW_definitions_180516.NFW_Group) Like "*FENDERS*") AND (Not ((ITEM_MASTER.DESC_ENG) Like "*RUBBER*" And (ITEM_MASTER.DESC_ENG) Like "*MOUNT*")));
        else if((filter['NFWGroupName'].indexOf('FENDERS') >=0 ) && ((item['Description'].indexOf('RUBBER') >=0  || item['Description'].indexOf('MOUNT') >=0 ))) {
            flag = true;
        }
        //wHERE (((NFW_definitions_180516.Family_Code) Not Like "*P8088*") AND ((NFW_definitions_180516.NFW_Group) Like "*GRILLS*")); 
        else if( filter['Family_Code'].indexOf('P8088') <0  && filter['NFWGroupName'].indexOf('GRILLS') >=0 ) {
            flag = true;
        }
        return flag;
    }

}

// Array.unique()
declare global {
    interface Array<T> {
        unique(): Array<T>;
    }
}
Array.prototype.unique = function () {
    let n: any[] = [], r: any[] = [];
    for (var i = 0; i < this.length; i++) {
        if (!n[this[i]]) {
            n[this[i]] = true;
            r.push(this[i]);
        }
    }
    return r;
}

