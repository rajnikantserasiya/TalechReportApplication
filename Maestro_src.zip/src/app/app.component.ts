import { Component, OnInit, NgModule } from '@angular/core';
import {Router, NavigationEnd, ActivatedRoute} from '@angular/router';
import {StartPopupService } from './start-popup.service'
import { HttpClient } from '@angular/common/http';
import { Http } from "@angular/http";
import { HttpModule } from '@angular/http';
import { NgIf } from '@angular/common';
import { SaveDataService } from './save-data.service';
import { DataService } from './services/data-component.service';
import {EqExclusionsServiceService} from './services/eq-exclusions-service.service';
import { LoaderService } from './services/loader.service';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css'],
    providers: []

})
export class AppComponent implements OnInit {
    title = 'app';
    showVar: boolean = true;
    visitedStates: Array<String> = [];
    showLoader;

    toggleChild() {
        this.showVar = !this.showVar;
    }

    ngOnInit() {	
	 
        this.newService.fetchData();					
		this.IECheck();
    }

    constructor(private newService: SaveDataService, private router: Router, private activatedRoute: ActivatedRoute, private dataService: DataService, private eqExclusionsServiceService: EqExclusionsServiceService
        , private loaderService: LoaderService) {

        this.loaderService.status.subscribe((val: boolean) => {
            this.showLoader = val;
        });

        this.router.routeReuseStrategy.shouldReuseRoute = function(){
            return false;
        }; 
        this.router.events.subscribe((event) => {
            if (event.constructor.name === "NavigationStart") {
                this.checkIfStatesValid(event);
            }
            if (event instanceof NavigationEnd) {
                this.router.navigated = false;
                window.scrollTo(0, 0);
            }
        });
    }
		  
    checkIfStatesValid(evt) {
        if (this.visitedStates.length == 0 && evt.url === "/contsession") {           
            if (!localStorage.getItem("token")) {
                this.router.navigateByUrl('main');
                this.visitedStates.push(evt.constructor.name);
            }
        }
        else if (evt.url === "/main") {
            
        }
        else {
            this.visitedStates.push(evt.constructor.name);
        }
    }
	
	IECheck(): void {        
        if (FileReader.prototype.readAsBinaryString === undefined) {
            FileReader.prototype.readAsBinaryString = function (fileData) {
            let binary = '';
            const pt = this;
            const reader = new FileReader();
            reader.onload = function (e) {
                const bytes = new Uint8Array(reader.result);
                const length = bytes.byteLength;
                for (let i = 0; i < length; i++) {
                binary += String.fromCharCode(bytes[i]);
                }
                const f = {target: {result: binary}};
                pt.onload(f);
            }
            reader.readAsArrayBuffer(fileData);
            }
        }
    }
}
