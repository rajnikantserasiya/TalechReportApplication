import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminImportFleetPopupComponent } from './admin-import-fleet-popup.component';

describe('AdminImportFleetPopupComponent', () => {
  let component: AdminImportFleetPopupComponent;
  let fixture: ComponentFixture<AdminImportFleetPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminImportFleetPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminImportFleetPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
