import { Component, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable, ElementRef } from '@angular/core';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Subject }    from 'rxjs/Subject';
import {SelectEquipmentOtherService}  from '../services/select-equipment-other.service';
import { Country_mm } from '../services/eq-exclusions-class';
import {CustomerCountryService} from './../services/customer-country.service';
import { DataService } from './../services/data-component.service';

declare var jquery: any;
declare var $: any;

@Injectable() export class LoadImportFleetModalService {
    columns: any = [];
    onOkClick = new Subject<any>();
    onOkClickStream$ = this.onOkClick.asObservable();

    constructor(private modalService: NgbModal) {
    }

    public show() {
        const modalRef = this.modalService.open(AdminImportFleetPopupComponent);
        modalRef.componentInstance.name = "AdminImportFleetPopup";
        modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }

    setColumns(columns) {
        this.columns = columns;
    }

    getColumns() {
        return this.columns;
    }

    onOkClicked(data) {
        this.onOkClick.next(data);
    }
}

@Component({
    selector: 'app-admin-import-fleet-popup',
    templateUrl: './admin-import-fleet-popup.component.html',
    styleUrls: ['./admin-import-fleet-popup.component.css'],
    providers: [SelectEquipmentOtherService, CustomerCountryService]
})
export class AdminImportFleetPopupComponent implements OnInit {

    public countrymmAdmin: Country_mm[];
    columns: any = [];
    modelCategory: any = [];
    modelList: any = [];
    selectedModelCategory: string = 'select';
    selectedModel: string = 'select';
    COUNTRY = 'select';
    SalesArea = '';
    Terattory = '';
    CustID = '';
    formModel: any = {
        'modelCategory': 'select', 'model': 'select', 'country': 'select', 'SalesArea': 'input', 'Terattory': 'input', 'CustID': 'input', 'serialNumber': 'select', 'parentId': 'select', 'parentDescription': 'select', 'item': 'select', 'itemDescription': 'select', 'quantity': 'select'
    };
    constructor(private eRef: ElementRef, public activeModal: NgbActiveModal, public changeRef: ChangeDetectorRef,
        private loadImportFleetModalService: LoadImportFleetModalService, private selectEquipmentOtherService: SelectEquipmentOtherService,
        private customerCountryService: CustomerCountryService, private dataService: DataService) {
    }

    ngOnInit() {
        this.modelCategory = [];
        this.columns = this.loadImportFleetModalService.getColumns();
        this.getModelCategory();
        this.getCountry();
    }

    getModelCategory() {
        this.selectEquipmentOtherService.getModelCategory().then(
            (data) => {
                if (data) {
                    this.modelCategory = data;
                }
            }
        )
            .catch(error => console.log(error));
    }

    getModelforBom(value) {
        this.selectEquipmentOtherService.getModel(value).then(
            (data) => {
                if (data) {
                    this.modelList = data;
                }
            }
        )
            .catch(error => console.log(error));
    }

    ngOnDestroy() {
        this.columns = [];
    }

    onModelChange(value, str) {
        if (str === 'modelCategory') {
            this.selectedModelCategory = value;
            this.getModelforBom(value);
        } else if (str === 'model') {
            this.selectedModel = value;
        }
        this.formModel[str] = value;
    }

    onOkClick() {
        /*
            callback on parent component registered via subjects            
        */
        //debugger;
        this.loadImportFleetModalService.onOkClicked(this.formModel);
        this.activeModal.dismiss(true);
    }

    onReset() {
        /*
            callback on parent component registered via subjects            
        */
        this.activeModal.dismiss(true);
    }

    validateForm() {
        return $('select').hasClass('ng-invalid-admin-bom-panel');
    }

    getDynamicClass(ref, modelCategory) {
        var className = "";
        className = modelCategory.value == 'select' ? 'ng-invalid-admin-bom-panel' : 'ng-valid-admin-bom-panel';
        return className;
    }

    getCountry(): void {
        this.customerCountryService.customerCountryData().then(result => {
            //debugger;
            //delete result[0];
            const index = result.findIndex(res => res.COUNTRY === "All");
            result.splice(index, 1);
            this.countrymmAdmin = result;
            //this.dataService.setData('countryList', result, false);
            //this.customerCountryService.selectCountry((result.length.toString()));
        })
            .catch(error => console.log(error));
    }

}
