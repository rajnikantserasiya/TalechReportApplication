import {Router , NavigationEnd , CanActivate , CanDeactivate} from '@angular/router';
import {Injectable }  from '@angular/core';
import { Location } from '@angular/common';

@Injectable()
export class GuardOnActivate implements CanActivate  {

    visitedStates : Array<String>= [];

    constructor(private router: Router, private location: Location){               
    }

    canActivate(evt) {
      var flag = true;      
      return flag;
    }

    checkIfStatesValid(evt) {
        
        var flag = true;
        if(this.visitedStates.length == 0  && evt.url[0].path === "contsession"){    
          if(!localStorage.getItem("token")){
            flag = false;
            var that = this;          
            location.href = location.origin;
            location.reload();           
            this.visitedStates.push(evt.constructor.name);
          }      
        }
        else if(evt.url[0].path != "main"){
            this.visitedStates.push(evt.constructor.name);
        } 
        return flag;
      }

}



 