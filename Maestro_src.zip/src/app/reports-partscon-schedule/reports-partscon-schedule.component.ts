import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import { Subscription }   from 'rxjs/Subscription';
import { GenerateCostReportsCPHService } from '../generate-reports-cph-popup/generate-reports-cph-popup.component';
import { GenerateReportsService } from '../generate-reports-popup/generate-reports-popup.component';
import { SelectEquipmentMasterService } from './../services/select-equipment-master.service';
import { ReportService} from '../services/report.service';
import { DataService } from './../services/data-component.service';
import { AppConstant } from './../app.constant';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { HtmlResultPoupservice } from '../htmlview/html-result.component';
import {EqExclusionsServiceService} from '../services/eq-exclusions-service.service';
import {EqFactorsList} from '../services/eq-exclusions-class';

@Component({
    selector: 'app-reports-partscon-schedule',
    templateUrl: './reports-partscon-schedule.component.html',
    styleUrls: ['./reports-partscon-schedule.component.css'],
    providers: [GenerateReportsService, HtmlResultPoupservice, GenerateCostReportsCPHService]
})
export class ReportsPartsconScheduleComponent {

    max: Number = 4;
    disableReports: boolean = true;
    disableReportschange: boolean = false;
    subscription: Subscription;
    reportIntervalModel: Number = 500;
    showValidationMessage: boolean = false;
    columnDropdown = [];
    engineHours = "";
    equipfactors: EqFactorsList[];

    public restrictNumeric(e) {
        var key = e.keyCode ? e.keyCode : e.which;
        if (!([8, 9, 13, 27, 110, 190].indexOf(key) !== -1 ||
            (key == 65 && (e.ctrlKey || e.metaKey)) ||
            (key >= 35 && key <= 40) ||
            (key == 43 && key == 45) ||
            (key >= 48 && key <= 57 && !(e.shiftKey || e.altKey)) ||
            (key >= 96 && key <= 105)
        )) e.preventDefault();

        if (e.target.value.length >= this.max) e.preventDefault();
    }
    
    public restrictZero(e) {
        var key = e.keyCode ? e.keyCode : e.which;
    }
    
    constructor(private eqExclusionsServiceService: EqExclusionsServiceService, private htmlResultPoupservice: HtmlResultPoupservice, private generatereportsservice: GenerateReportsService, private generateCostReportsCPHService: GenerateCostReportsCPHService, private selectEquipmentMasterService: SelectEquipmentMasterService, private reportService: ReportService , private dataService : DataService , private appConstant : AppConstant , private fetchCurrentDataService: FetchCurrentDataService ) {
        this.fetchCurrentDataService.screenDataStream$.subscribe(
            () => {
              if (!this.fetchCurrentDataService.disableFlagSavePartscon) {
                this.fetchCurrentDataService.disableFlagSavePartscon = true; 
                this.fetchCurrentDataService.createJsonToSave(this.reportIntervalModel, this.appConstant.partscon_reportInterval);        
                this.fetchCurrentDataService.createJsonToSave(this.engineHours, this.appConstant.partscon_colDropdown);                   
                console.log('Fetching data for Report - Part Consumption');  
                }
        });       
        this.selectEquipmentMasterService.equipmentSelected$.subscribe(
            numberOfEquipments => {
                this.disableReports = parseInt(numberOfEquipments) <= 0;
        });
    }

    reportIntervalChange(value): any {
        if (value < 50 || value > 9999) {
            this.showValidationMessage = true;
            this.disableReportschange = true;            
        } else {
            this.showValidationMessage = false;
            this.reportIntervalModel = value;            
            this.disableReportschange = false;
            this.dataService.setReportsValue('partscon_reportInterval', value);   
        }
    }

    generateReportDlg(): void {       
        if(localStorage.getItem("PriceListType_Report")=="" || localStorage.getItem("PriceList_Report")=="")
        {
            alert("Please select Price Type and Country in the Option tab.");
        }
        else{        
            this.generatereportsservice.show();
         }
    }

    generateReportDlgHtml(): void {
        if(localStorage.getItem("PriceListType_Report")=="" || localStorage.getItem("PriceList_Report")=="") {
            alert("Please select Price Type and Country in the Option tab.");
        } else {
                this.htmlResultPoupservice.show();
        }
    }
    
    generateReportDlgCPH(): void {
        if (localStorage.getItem("PriceListType_Report") == "" || localStorage.getItem("PriceList_Report") == "") {
            alert("Please select Price Type and Country in the Option tab.");
        }
        else {
            this.generateCostReportsCPHService.show();
        }
    }
    
    ngOnInit() {        
        // UI Changes
        document.getElementById("slide-nav").style.width = "0";  
        localStorage.setItem("ReportOption", "XLS Spreadsheet");
    }

    getCustomList(reportOption) {      
        localStorage.setItem("ReportOption", "");
        localStorage.setItem("ReportOption", reportOption);
    }

    validateReportGeneration(str): boolean {
        let disableReport: boolean = false;
        let cphButtonRef = (<HTMLInputElement>document.getElementById("generateReportBtnCPH"));
        //disableReport = true;
        if (this.reportService.getDownloadInProgress()) {            
            disableReport = true;
        } else {
            if (parseInt(this.selectEquipmentMasterService.getSelectedEquipment()) > 0) {
              
                disableReport = this.disableReportschange;
            } else {
                disableReport = true; 
            }
        }
        if (this.dataService.getReportsValue('IsengineHrsValue') == false) {
            disableReport = true;
        }

        if(str === "cph" && cphButtonRef ) {
            cphButtonRef.disabled = disableReport ? true : false;
        }
        return disableReport;
    }
}
