import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportsPartsconScheduleComponent } from './reports-partscon-schedule.component';

describe('ReportsPartsconScheduleComponent', () => {
  let component: ReportsPartsconScheduleComponent;
  let fixture: ComponentFixture<ReportsPartsconScheduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportsPartsconScheduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportsPartsconScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
