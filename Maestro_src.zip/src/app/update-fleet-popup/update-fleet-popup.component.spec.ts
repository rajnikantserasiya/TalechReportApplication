import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateFleetPopupComponent } from './update-fleet-popup.component';

describe('UpdateFleetPopupComponent', () => {
  let component: UpdateFleetPopupComponent;
  let fixture: ComponentFixture<UpdateFleetPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateFleetPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateFleetPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
