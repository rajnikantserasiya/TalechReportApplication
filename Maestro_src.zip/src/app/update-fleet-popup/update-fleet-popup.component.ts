import {Component, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable } from '@angular/core';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-update-fleet-popup',
  templateUrl: './update-fleet-popup.component.html',
  styleUrls: ['./update-fleet-popup.component.css']
})
export class UpdateFleetPopupComponent {
    constructor(public activeModal: NgbActiveModal, public changeRef: ChangeDetectorRef) { }    
    
    openFleetDialog(): void {               
        var closeUpdateFleetBtn = document.getElementById("closeUpdateFleetBtn");
        closeUpdateFleetBtn.click();  
        
        setTimeout( () => {
            var fileLoaderButton = document.getElementById("update_fleet");
            fileLoaderButton.click();
        }, 1000);        
    }
}

@Injectable() export class UpdateFleetDialogService {

    constructor(private modalService: NgbModal) { }

    public show() {
        const modalRef = this.modalService.open(UpdateFleetPopupComponent);
        modalRef.componentInstance.name = "showupdatedlg";
        modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }
}

