import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateReportsPopupComponent } from './generate-reports-popup.component';

describe('GenerateReportsPopupComponent', () => {
  let component: GenerateReportsPopupComponent;
  let fixture: ComponentFixture<GenerateReportsPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenerateReportsPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerateReportsPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
