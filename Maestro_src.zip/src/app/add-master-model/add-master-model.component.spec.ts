import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddMasterModelComponent } from './add-master-model.component';

describe('AddMasterModelComponent', () => {
  let component: AddMasterModelComponent;
  let fixture: ComponentFixture<AddMasterModelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddMasterModelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddMasterModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
