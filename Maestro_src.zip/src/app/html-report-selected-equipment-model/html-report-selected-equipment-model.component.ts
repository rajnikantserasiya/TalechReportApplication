import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import {ElementRef, Component, HostListener, HostBinding, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable } from '@angular/core';
import { DataService } from './../services/data-component.service';
import { SaveService } from '../services/save.service';
import { AppConstant } from './../app.constant';
import { CommonUtil }  from './../common/common-util';
import { EqSelectedList } from '../services/eq-exclusions-class';
import { SelectEquipmentMasterService } from './../services/select-equipment-master.service';
import { EqSelectedPreviewList } from '../services/eq-exclusions-class';
import { CommonService } from '../services/common.service';
declare var jquery: any;
declare var $: any;


@Component({
    selector: 'app-html-report-selected-equipment-model',
    templateUrl: './html-report-selected-equipment-model.component.html',
    styleUrls: ['./html-report-selected-equipment-model.component.css'],
})
export class HtmlReportSelectedEquipmentModelComponent implements OnInit {

    selectedEquipment: EqSelectedList[];
    eqSelectedPreviewList: EqSelectedPreviewList[] = [];
    strEquipment = "Select equipment";
    disableReportschange: boolean = false;
    errorMessage = '';
    display: boolean = false;
    routerpath = '';

    constructor(private dataService: DataService, private selectEquipmentMasterService: SelectEquipmentMasterService,
        private commonService: CommonService, public activeModal: NgbActiveModal) { }

    ngOnInit() {
        this.getSelectedEquipmentList();
        this.setRouterPathBasedOnReportType();
    }

    setRouterPathBasedOnReportType() {
        var reportType = this.commonService.getReportType() || '';
        if (reportType === "cost_forecast") {
            this.routerpath = '/costforecastreport';
        }
        else if (reportType === "partscom_cph") {
            this.routerpath = '/cphreport';
        }
        else if (reportType === "partscom_xls") {
            this.routerpath = '/partconsumptionreport';
        }
    }

    getSelectedEquipmentList(): void {

        this.selectEquipmentMasterService.selectedEquipmentMaster()
            .then(result => {

                this.getEquipmentSelectedList(result)

            }).catch(error => console.log(error));

    }

    closeCurrentModel() {
        this.activeModal.dismiss(true);
    }

    getEquipmentSelectedList(result) {

        this.selectedEquipment = result;
        let intInc: number = 0;
        
        for (let entry of this.selectedEquipment) {
            let strEquipment: string = "";
            intInc = intInc + 1;
            if (entry["EqSourceType"] == "1") {
                strEquipment = entry["Model"] + ' SN:' + entry["SerialNo"];
            };
            if (entry["EqSourceType"] == "2") {
                strEquipment = entry["Model"] + ' SN:' + entry["SerialNo"];
            }
            if (entry["EqSourceType"] == "3") {
                strEquipment = entry["Model"] + ' SN:' + entry["SerialNo"] + "_Other";
            }

            let newName = {
                Id: intInc.toString(),
                Equipment: strEquipment,
                EqSourceType: entry["EqSourceType"].toString(),
                SerialNo: entry["SerialNo"].toString(),
                Model: entry["Model"].toString(),
                UserName: entry["UserName"].toString(),
                Quantity: entry["Quantity"]
            };
            if (entry["EqSourceType"] == "1" || entry["EqSourceType"] == "2" || entry["EqSourceType"] == "3") {
                this.eqSelectedPreviewList.push(newName);
            }
        }
    }

    getSelectedEquipment(Equipment): void {

        //var Equipid = $("#selectEquipment").val();        
        if (Equipment != 'Select equipment') {
            for (let entry of this.eqSelectedPreviewList.filter(s => s.Id == Equipment)) {

                let sourceType: string = entry["EqSourceType"].toString()
                let strSerialNo: string = "";
                let strModel: string = "";
                var priceType = this.dataService.getOptionsPriceType();
                var country = this.dataService.getActiveCountry();
                var priceList = this.dataService.getActivePriceList();
                var fromHrs = this.commonService.getReportInterval('from');
                var toHrs = this.commonService.getReportInterval('to');
                var maintenancePartsForeCostsReportParameters = this.commonService.getMaintenancePartsForeCostsReportParameters();

                if (entry["EqSourceType"] == "1") {
                    strSerialNo = entry["SerialNo"];
                };
                if (entry["EqSourceType"] == "2") {
                    strModel = entry["Model"];
                }
                if (entry["EqSourceType"] == "3") {
                    strModel = entry["Model"];
                }



                this.commonService.setHTMLReportEquipmentDetails
                    (
                    sourceType, strSerialNo, strModel, priceType, country, priceList, fromHrs, toHrs,
                    maintenancePartsForeCostsReportParameters.reportCostPerStrategy,
                    maintenancePartsForeCostsReportParameters.reportExecutiveSummary,
                    maintenancePartsForeCostsReportParameters.reportIntervalSummary,
                    maintenancePartsForeCostsReportParameters.reportBOMDetails,
                    maintenancePartsForeCostsReportParameters.reportInterest,
                    maintenancePartsForeCostsReportParameters.reportFormat
                    );
            }
        }
    }

    showDialog(message) {
        this.errorMessage = message;
        this.display = true;
    }

}


@Injectable() export class SelectedEquipmentModelService {

    constructor(private modalService: NgbModal) { }

    public show() {
        const modalRef = this.modalService.open(HtmlReportSelectedEquipmentModelComponent);
        modalRef.componentInstance.name = "htmlReportSelectedEquipmentModel";
        //modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }
}

