import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HtmlReportSelectedEquipmentModelComponent } from './html-report-selected-equipment-model.component';

describe('HtmlReportSelectedEquipmentModelComponent', () => {
  let component: HtmlReportSelectedEquipmentModelComponent;
  let fixture: ComponentFixture<HtmlReportSelectedEquipmentModelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HtmlReportSelectedEquipmentModelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HtmlReportSelectedEquipmentModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
