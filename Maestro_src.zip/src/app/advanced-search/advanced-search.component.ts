import { Component, OnInit, Input, EventEmitter, Output, OnChanges, SimpleChange, SimpleChanges } from '@angular/core';
import { AdvancedSearchService } from './../services/advanced-search.service';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { DataService } from './../services/data-component.service';
import { CommonMessagePopupService } from '../common-message-popup/common-message-popup.component';

declare var jquery: any;
declare var $: any;

@Component({
    selector: 'app-advanced-search',
    templateUrl: './advanced-search.component.html',
    styleUrls: ['./advanced-search.component.css'],
    providers: [CommonMessagePopupService]
})
export class AdvancedSearchComponent implements OnInit {

    @Input() nodescount;
    @Input() EquipCount
    @Input('equipmentSelected') equipmentSelected;
    @Input('resetFilters') resetFilter;
    @Input('screen') screen;
    @Output() filterData: EventEmitter<any> = new EventEmitter();

    mappedTableData = []
    activeFilters = [];
    operators: any = [
        { 'label': 'Like', 'id': 1, 'type': 'string' },
        { 'label': 'Not Like', 'id': 2, 'type': 'string' },
        { 'label': 'In', 'id': 3, 'type': 'string' },
        { 'label': 'Not In', 'id': 4, 'type': 'string' },
        { 'label': '=', 'id': 5, 'type': 'int' },
        { 'label': '<=', 'id': 6, 'type': 'int' },
        { 'label': '>=', 'id': 7, 'type': 'int' },
        { 'label': '>', 'id': 8, 'type': 'int' },
        { 'label': '<', 'id': 9, 'type': 'int' },
        { 'label': 'between', 'id': 10, 'type': 'int' }
    ];
    columns: any = [
        { 'label': 'Parent_Id', 'id': 1, 'type': 'string' },
        { 'label': 'Parent_Desc', 'id': 2, 'type': 'string' },
        { 'label': 'Item_Id', 'id': 3, 'type': 'string' },
        { 'label': 'Item_Desc', 'id': 4, 'type': 'string' },
        { 'label': 'Qty', 'id': 5, 'type': 'int' },
        { 'label': 'Price', 'id': 6, 'type': 'int' },
        { 'label': 'Life', 'id': 7, 'type': 'int' }
    ];
    rules: any = [{
        'IsActive': false,
        'ColumnName': 'Equipment',
        'Operator': '+',
        'Value1': '200',
        'Value2': null
    },
        {
            'IsActive': false,
            'ColumnName': 'Equipment',
            'Operator': '<=',
            'Value1': '200',
            'Value2': null
        },
        {
            'IsActive': false,
            'ColumnName': 'Equipment',
            'Operator': '>=',
            'Value1': '200',
            'Value2': '300'
        }
    ];

    cols = [
        { field: 'IsInclude', header: '', width: '3%' },
        { field: 'ColumnName', header: 'Column', width: '7%' },
        { field: 'Operator', header: 'Operator', width: '7%' },
        { field: 'valuesFrom', header: 'Values 1', width: '7%' },
        { field: 'valuesTo', header: 'Values 2', width: '7%' }
    ];

    selectUnselect: string = "Unselect All";
    selectAllFilter = true;
    loadFlag: boolean = false;
    selectedOp: any = "select";
    selectedCol: any = "select";
    Value1: any;
    Value2: any;
    values: string;

    constructor(private advancedSearchService: AdvancedSearchService, private dataService: DataService, private commonMessagePopupService: CommonMessagePopupService) {
    }

    ngOnInit() {
        //this.rules = [];
        //this.activeFilters = [];
        //this.getMappedData();

        //reset in preview screen issue changes
        this.resetAll();
    }

    resetAll() {
        this.rules = [];
        this.activeFilters = [];
        this.dataService.setData('activeFilters', this.activeFilters, true);
        this.getMappedData();
    }

    ngOnDestroy() {
        if (this.activeFilters.length > 0) {
            this.dataService.setData('activeFilters', this.activeFilters, true);
        }
    }

    getMappedData() {
        var cachedData = [];
        /*if(this.screen == "exclusion"){
          cachedData = this.dataService.getData('activeFiltersExclusion');
        } else {
          cachedData = this.dataService.getData('activeFilters');      
        } */
        cachedData = this.dataService.getData('activeFilters');
        /* if(cachedData.length == 0) {
            cachedData  = this.advancedSearchService.getActiveFilters();
            this.dataService.setData('activeFilters', cachedData, true);
        }*/
        if (cachedData.length > 0) {
            this.activeFilters = JSON.parse(JSON.stringify(cachedData));
            this.toggleSelectUnselect();
        } else {
            this.advancedSearchService.getMappedData().then((data) => {
                if (data) {
                    this.handleResponse(data);
                    //this.activeFilters.forEach(item => {

                    //    if (item['IsActive'] === false) {
                    //        this.selectAllFilter = false;
                    //        this.selectUnselect = "Select All";
                    //    }

                    //});
                    //reset in preview screen issue changes
                    this.setSelectAllOptionText();
                }
            })
                .catch(error => console.log(error));
        }
    }

    setSelectAllOptionText() {
        var keepGoing = true;
        this.activeFilters.forEach(item => {
            if (keepGoing) {
                if (!item['IsActive']) {
                    this.selectAllFilter = false;
                    this.selectUnselect = "Select All";
                    keepGoing = false
                }
                else {
                    this.selectAllFilter = true;
                    this.selectUnselect = "Unselect All";
                }
            }
        });
    }

    handleResponse(data) {
        this.mappedTableData = data;
        this.mappedTableData.forEach(item => {
            var temp = this.activeFilters.filter(filter => {
                return filter['NFWGroupName'] === item['NFW_Group'];
            });
            if (temp.length > 0) {
                //console.log('item already present , push the family code if not present');
                this.activeFilters.forEach(filter => {
                    if (filter['NFWGroupName'] === item['NFW_Group']) {
                        if (filter['Family_Code'].indexOf(item['Family_Code']) < 0) {
                            filter['Family_Code'].push(item['Family_Code']);
                        }
                    }
                });
            } else {
                var obj = { 'NFWGroupName': item['NFW_Group'], 'Family_Code': [], 'type': 'NFW_Group', 'IsActive': item['IsActive'] };
                obj['Family_Code'].push(item['Family_Code']);


                this.activeFilters.push(obj);
            }
        });
        /*if(this.screen == "exclusion"){
          this.dataService.setData('activeFiltersExclusion', this.mappedTableData , true);
        } else {
          this.dataService.setData('activeFiltersPreview', this.mappedTableData , true);
        } */
        this.dataService.setData('activeFilters', this.activeFilters, true);
        this.toggleSelectUnselect();
    }

    ngOnChanges(changes) {
        //reset in preview screen issue changes
        //if (changes['resetFilter'] && changes['resetFilter'].currentValue) {
        if (changes['resetFilter']) {
            this.resetFilters();
        }
    }

    resetFilters() {
        //this.activeFilters.forEach(item => {
        //    item['IsActive'] = true;
        //});
        //reset in preview screen issue changes
        this.resetAll();
    }

    onModelChange(value, data) {

        //if ((this.screen == "exclusion" && this.nodescount.length == 0) || (this.screen == "preview" && this.EquipCount.length == 0)) {
        //    //alert("Please select any equipment from SELECT EQUIPMENT tab.");
        //    //this.commonMessagePopupService.show();
        //    //this.Confirm("Error Message", "Please select any equipment from SELECT EQUIPMENT tab.", "OK", "", "");
        //    return false;
        //}        
        this.loadFlag = true;
        if (this.screen == "exclusion") {
            this.dataService.setTabModified('tab-exclusion', true);
        } else {
            this.dataService.setTabModified('tab-preview', true);
        }
        data['IsActive'] = value;
        //if (!value) {
        //    this.selectAllFilter = false;
        //    this.selectUnselect = "Select All";
        //}
        var obj = { 'activeFilter': data, 'allFilters': this.activeFilters, 'type': 'single' };
        //this.dataService.setData('activeFilters', this.activeFilters, true);
        // this.advancedSearchService.setActiveFilters(this.activeFilters);
        this.dataService.setData('activeFilters', this.activeFilters, true);
        this.filterData.emit(obj);

        //Reset in preview screen issue 
        this.setSelectAllOptionText();        

        setTimeout(item => {
            this.loadFlag = false;
        }, 1000)

    }

    //validateDisable() {
    //    //debugger;
    //    if (this.screen == "exclusion") {
    //        return this.nodescount.length > 0 ? true : false;
    //        //return this.equipmentSelected.length > 0 && this.equipmentSelected != 'Select equipment' ? false : true;
    //    }
    //    else
    //        return true;
    //}

    getDynamicWidth(col) {
        //console.log(col.width);
        return col.width;
    }

    onSelectAll(value) {
        //debugger;
        //if ((this.screen == "exclusion" && this.nodescount.length == 0) || (this.screen == "preview" && this.EquipCount.length == 0)) {
        //    //alert("Please select any equipment from SELECT EQUIPMENT tab.");
        //    this.commonMessagePopupService.show();
        //    //this.Confirm("Error Message", "Please select any equipment from SELECT EQUIPMENT tab.", "OK", "", "");
        //    return false;
        //}        
        this.loadFlag = true;
        if (this.screen == "exclusion") {
            this.dataService.setTabModified('tab-exclusion', true);
        } else {
            this.dataService.setTabModified('tab-preview', true);
        }
        if (value) {
            this.selectUnselect = "Unselect All";
        } else {
            this.selectUnselect = "Select All";
        }
        this.selectAllFilter = value;
        this.activeFilters.forEach(item => {
            item['IsActive'] = value;
        });
        var obj = { 'activeFilter': [], 'allFilters': this.activeFilters, 'type': 'all' };
        //this.advancedSearchService.setActiveFilters(this.activeFilters);
        this.dataService.setData('activeFilters', this.activeFilters, true);
        this.filterData.emit(obj);
        setTimeout(item => {
            this.loadFlag = false;
        }, 1000)

    }

    showHideRange() {
        var flag: boolean = true;
        if (this.selectedOp) {
            if (this.selectedOp.indexOf('Like') >= 0 || this.selectedOp.indexOf('Not Like') >= 0 || this.selectedOp.indexOf('In') >= 0 || this.selectedOp.indexOf('Not In') >= 0) {
                flag = true;
            } else {
                flag = false;
            }
        }
        //console.log(this.selectedCol + "" + this.selectedOp);
        return flag;
    }

    clearSelectedValues() {
        this.selectedCol = "select";
        this.selectedOp = "select";
        this.values = "";
        this.Value1 = "";
        this.Value2 = "";
    }

    onInputModelChange(value, field) {
        if (field === "Value1") {
            this.Value1 = value;
        } else {
            this.Value2 = value;
        }
    }

    ngModelCheckBoxChange(value, data) {
        data['IsActive'] = value;
    }

    getFormName(filter) {
        if (filter['NFWGroupName']) {
            return filter.NFWGroupName;
        } else {
            return Math.random().toString();
        }
    }

    toggleSelectUnselect() {
        var uncheckFlag = false;
        if (this.activeFilters.length > 0) {
            for (var i = 0; i < this.activeFilters.length; i++) {
                if (!this.activeFilters[i]['IsActive']) {
                    uncheckFlag = true;
                    break;
                }
            }
            if (uncheckFlag) {
                this.selectUnselect = "Select All";
                this.selectAllFilter = false;
            } else {
                this.selectUnselect = "Unselect All";
            }
        }
    }

}


