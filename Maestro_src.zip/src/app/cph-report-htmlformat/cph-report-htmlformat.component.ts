import { Component, OnInit, AfterViewInit, ElementRef } from '@angular/core';
import {AccordionModule} from 'primeng/accordion';
import { AuthService } from "../interceptor/auth.service";
import { HttpClient } from '@angular/common/http';
import {Http, Response, Headers, RequestOptions, Request, RequestMethod} from "@angular/http";
import { environment } from '../../environments/environment';
import { LoaderService } from '../services/loader.service';
//import { ElementRef } from '@angular/core';
declare var jquery: any;
declare var $: any;

@Component({
    selector: 'app-cph-report-htmlformat',
    templateUrl: './cph-report-htmlformat.component.html',
    styleUrls: ['./cph-report-htmlformat.component.css'],
    providers: [AccordionModule]
})
export class CphReportHtmlformatComponent implements OnInit, AfterViewInit {

    IsPrintClicked = false;
    toggleChecked: boolean = false;
    ModelCategory: string = '';
    Model: string = '';
    Equipment: string = '';
    //dtBOMDetails: CPHBOMDetailsClass[] = [];
    BOMDetails_Printable_HTMLStructure = '';
    BOMDetails_NonPrintable_FixedHeaderHTMLStructure = '';
    BOMDetails_NonPrintable_RestColHeaderHTMLStructure = '';
    BOMDetails_NonPrintable_RestColDataHTMLStructure = '';
    BOMDetails_NonPrintable_FullHTMLStructure = '';
    IntervalSummaryHTMLStructure = '';

    //Executive summary section
    DateField = '';
    Author = '';
    Pricing = '';
    FromHrs = '';
    ToHrs = '';
    TotalItems = '';
    TotalPrice = '';
    Equipment_SN = '';
    Equipment_Model = '';
    Qty = '';
    Excludes = '';

    //Excluded
    dtExcludedItems = [];

    //Equipment summary
    EquipmentSummary_Equipment_SN = '';
    EquipmentSummary_Equipment_Model = '';
    EquipmentSummary_Equipment_From = '';
    EquipmentSummary_Equipment_To = '';
    EquipmentSummary_Equipment_AnnualExpectedEngineHrs = 0;
    EquipmentSummary_Equipment_AnnualExpectedPERCHours = 0;
    EquipmentSummary_Equipment_AnnualExpectedCOMPHours = 0;
    EquipmentSummary_Equipment_AnnualExpectedPPACKHours = 0;
    EquipmentSummary_Equipment_AnnualExpectedGRBXHours = 0;

    EquipmentSummary_Equipment_TotalCostOverAnalysis = '';
    EquipmentSummary_Equipment_NormalisedCostPerHour = '';
    EquipmentSummary_Equipment_IntervalSummaryTable = [];
    //EquipmentSummary_Equipment_Pricing = [];

    // visible tab properties
    tabBOMDetails = false;
    tabEquipmentSummary = false;
    tabExecutiveSummary = false;

    

    constructor(private _http: HttpClient, private loaderService: LoaderService, public eRef: ElementRef) { }

    ngAfterViewInit() {
        //this.loadEvent();
    }

    errorMessage = '';
    display: boolean = false;

    showDialog(message) {
        this.errorMessage = message;
        this.display = true;
    }

    ngOnInit() {

        this.CPHReportInHTMLFormat();
    }


    loadEvent() {

        var fcBody = this.eRef.nativeElement.querySelector(".fix-column > .tbody"),
            rcBody = this.eRef.nativeElement.querySelector(".rest-columns > .tbody"),
            rcHead = this.eRef.nativeElement.querySelector(".rest-columns > .thead");
        rcBody.addEventListener(
            "scroll",
            function () {
                fcBody.scrollTop = this.scrollTop;
                rcHead.scrollLeft = this.scrollLeft;
            },
            { passive: true }
        );

        //$('#fixed_hdr1').fxdHdrCol({
        //    fixedCols: 3,
        //    width: '100%',
        //    height: 400,
        //    colModal: [
        //        { width: 50, align: 'center' },
        //        { width: 110, align: 'center' },
        //        { width: 170, align: 'left' },
        //        { width: 250, align: 'left' },
        //        { width: 100, align: 'left' },
        //        { width: 70, align: 'left' },
        //        { width: 100, align: 'left' },
        //        { width: 100, align: 'center' },
        //        { width: 90, align: 'left' },
        //        { width: 400, align: 'left' }
        //    ]
        //});
    }


    PrintPreviewmodeMethod() {

        this.IsPrintClicked = !this.IsPrintClicked;
        if (!this.IsPrintClicked) {
            //$(".printableRow").hide();
            //$(".NonprintableRow").show();
            $(".printableTableFormat").hide();
            $(".nonprintableTableFormat").show();
        }

        if (this.IsPrintClicked) {
            //$(".printableRow").show();
            //$(".NonprintableRow").hide();
            $(".printableTableFormat").show();
            $(".nonprintableTableFormat").hide();
        }
    }

    trackByIndex(index: number, value: number) {
        return index;
    }

    CPHReportInHTMLFormat() {

        this.loaderService.display(true);


        var username = localStorage.getItem("UserName");
        var eqSourceType = localStorage.getItem("htmlReportSelectedEquipment_SourceType");
        var SerialNo = localStorage.getItem("htmlReportSelectedEquipment_SerialNo");
        var Model = localStorage.getItem("htmlReportSelectedEquipment_Model");
        var FromHrs = localStorage.getItem("htmlReportSelectedEquipment_FromHrs");
        var ToHrs = localStorage.getItem("htmlReportSelectedEquipment_ToHrs");
        var ReportIntervalTxt = localStorage.getItem("ReportIntervalTxt");
        var ReportHrsType = localStorage.getItem("ReportHrsType");
        var ApplyAlignment = localStorage.getItem("ApplyAlignment");
        var ApplySuppression = localStorage.getItem("ApplySuppression");
        var ReportFilter = localStorage.getItem("ReportFilter");
        var PriceListType = localStorage.getItem("PriceListType");
        var PriceList = localStorage.getItem("PriceList");
        var reportCostPerStrategy = localStorage.getItem("htmlReportSelectedEquipment_ReportCostPerStrategy");
        var reportExecutiveSummary = localStorage.getItem("htmlReportSelectedEquipment_ReportExecutiveSummary");
        var reportIntervalSummary = localStorage.getItem("htmlReportSelectedEquipment_ReportIntervalSummary");
        var reportBOMDetails = localStorage.getItem("htmlReportSelectedEquipment_ReportBOMDetails");
        var reportInterest = localStorage.getItem("htmlReportSelectedEquipment_ReportInterest");
        var reportFormat = localStorage.getItem("htmlReportSelectedEquipment_ReportFormat");
        var PriceListCountry = localStorage.getItem("htmlReportSelectedEquipment_Country");

        if (reportExecutiveSummary == "true") {
            this.tabExecutiveSummary = true
        }

        if (reportIntervalSummary == "true") {
            this.tabEquipmentSummary = true
        }

        if (reportBOMDetails == "true") {
            this.tabBOMDetails = true
        }

        let reportOption: string =
            '{"UserName":"' + username +
            '","EqSourceType":"' + eqSourceType +
            //'","SerialNo":"' + SerialNo +
            //'","Model":"' + Model +
            '","Model_SerialNo":"' + Model + SerialNo +
            '","HoursFrom":"' + FromHrs +
            '","HoursTo":"' + ToHrs +
            '","Interval":"' + ReportIntervalTxt +
            '","ReportHrsType":"' + ReportHrsType +
            '","ApplyAlignment":"' + ApplyAlignment +
            '","ApplySuppression":"' + ApplySuppression +
            '","FilterType":"' + ReportFilter +
            '","PriceType":"' + PriceListType +
            '","PriceList":"' + PriceList +
            '","PriceListCountry":"' + PriceListCountry +
            '","reportCostPerStrategy":"' + reportCostPerStrategy +
            '","reportExecutiveSummary":"' + reportExecutiveSummary +
            '","reportIntervalSummary":"' + reportIntervalSummary +
            '","reportBOMDetails":"' + reportBOMDetails +
            '","reportInterest":"' + reportInterest +
            '","reportFormat":"' + reportFormat +
            '"}';

        //let dataTosend: string = JSON.stringify(reportOption);

        var headers = new Headers();
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: reportOption
        })

        return this._http.post(environment.apiUrl + 'MaestroReport/CPHPcalReportInHTMLFormat', requestoptions)
            .toPromise().then(result => {
                
                var CPHReportdata = JSON.parse(JSON.stringify(result));

                // Executive Summary section
                this.DateField = CPHReportdata.objExecutiveSummary.Date;
                this.Author = CPHReportdata.objExecutiveSummary.Author;
                this.Pricing = CPHReportdata.objExecutiveSummary.Pricing;
                this.FromHrs = CPHReportdata.objExecutiveSummary.From;
                this.ToHrs = CPHReportdata.objExecutiveSummary.To;
                this.TotalItems = CPHReportdata.objExecutiveSummary.TotalItems;
                this.TotalPrice = CPHReportdata.objExecutiveSummary.TotalPrice;
                this.Equipment_SN = CPHReportdata.objExecutiveSummary.Equipment;
                this.Equipment_Model = CPHReportdata.objExecutiveSummary.Model;
                this.Qty = CPHReportdata.objExecutiveSummary.Qty;
                this.Excludes = CPHReportdata.objExecutiveSummary.Excludes;

                //Equipment Summary
                this.EquipmentSummary_Equipment_SN = CPHReportdata.objEquipmentSummary.Equipment;
                this.EquipmentSummary_Equipment_Model = CPHReportdata.objEquipmentSummary.Model;
                this.EquipmentSummary_Equipment_From = CPHReportdata.objEquipmentSummary.From;
                this.EquipmentSummary_Equipment_To = CPHReportdata.objEquipmentSummary.To;
                this.EquipmentSummary_Equipment_AnnualExpectedEngineHrs = CPHReportdata.objEquipmentSummary.ENGCHours;
                this.EquipmentSummary_Equipment_AnnualExpectedPERCHours = CPHReportdata.objEquipmentSummary.PERCHours;
                this.EquipmentSummary_Equipment_AnnualExpectedCOMPHours = CPHReportdata.objEquipmentSummary.COMPHours;
                this.EquipmentSummary_Equipment_AnnualExpectedPPACKHours = CPHReportdata.objEquipmentSummary.PPACKHours;
                this.EquipmentSummary_Equipment_AnnualExpectedGRBXHours = CPHReportdata.objEquipmentSummary.GRBXHours;

                this.EquipmentSummary_Equipment_TotalCostOverAnalysis = CPHReportdata.objEquipmentSummary.TotalCostOverAnalysis;
                this.EquipmentSummary_Equipment_NormalisedCostPerHour = CPHReportdata.objEquipmentSummary.NormalizedCostPerHour;
                var intervalSummaryTable = CPHReportdata.objEquipmentSummary.EquipmentDetails;

                var tabClassname = '';
                var totalIntervals = intervalSummaryTable != null ? intervalSummaryTable.length : 0;
                var totalTabDisplayed = 0;

                if (totalIntervals > 0) {
                    if (totalIntervals <= 12) {
                        tabClassname = 'ui-g-6';
                        totalTabDisplayed = 1;
                    }
                    if (totalIntervals <= 24) {
                        tabClassname = 'ui-g-6';
                        totalTabDisplayed = 2;
                    }
                    else if (totalIntervals <= 36) {
                        tabClassname = 'ui-g-4';
                        totalTabDisplayed = 3;
                    }
                    else if (totalIntervals <= 48) {
                        tabClassname = 'ui-g-3';
                        totalTabDisplayed = 4;
                    }
                    else if (totalIntervals <= 60) {
                        tabClassname = 'ui-g-2';
                        totalTabDisplayed = 5;
                    }
                    else if (totalIntervals <= 72) {
                        tabClassname = 'ui-g-2';
                        totalTabDisplayed = 5;
                    }
                    else if (totalIntervals > 72) {
                        tabClassname = 'ui-g-2';
                        totalTabDisplayed = 5;
                    }
                }

                if (intervalSummaryTable != null && intervalSummaryTable.length > 0) {

                    var tabRow = '';
                    var tabHeader =
                        '<div class=' + tabClassname + '>' +
                        '<table class="IntervalSummaryTable">' +
                        '<tr class="trBackGround">' +
                        '<th class="tdSpacing"> Intervals </th>' +
                        '<th class="tdSpacing"> Interval Total </th>' +
                        '<th class="tdSpacing"> Interval CPH </th>' +
                        '</tr>';
                    var tabFooter = '</table></div>'

                    for (let i = 0; i < intervalSummaryTable.length; i++) {
                        
                        var Intervals = intervalSummaryTable[i].Intervals;
                        var IntervalTotal = Math.round(intervalSummaryTable[i].IntervalTotal);
                        var Item = intervalSummaryTable[i].IntervalCPH == "0" ? 0 : this.Customround(intervalSummaryTable[i].IntervalCPH);

                        tabRow += '<tr>' +
                            '<td class="tdSpacing"> ' + Intervals + ' </td>' +
                            '<td class="tdSpacing"> ' + IntervalTotal + ' </td>' +
                            '<td class="tdSpacing"> ' + Item + ' </td>' +
                            '</tr>'
                            ;

                        if (i == 0 || i == 12 || i == 24 || i == 36 || i == 48 || i == 60) {
                            tabRow = tabHeader + tabRow;
                        }

                        if (i == 11 || i == 23 || i == 35 || i == 47 || i == 59 || i == totalIntervals - 1) {
                            tabRow = tabRow + tabFooter;
                            this.IntervalSummaryHTMLStructure += tabRow;
                            tabRow = '';
                        }

                    }

                    $(".tabEquipmentIntervals").append(this.IntervalSummaryHTMLStructure)
                }


                //Excluded section
                this.dtExcludedItems = CPHReportdata.objExcludeItemsSummary.dtExcludedItems;

                //BOM Details section
                var dtBOMDetails = CPHReportdata.objBOMDetailsSummary.dtBOMDetails;
                this.ModelCategory = CPHReportdata.objBOMDetailsSummary.modelCategory;
                this.Model = CPHReportdata.objBOMDetailsSummary.model;
                this.Equipment = CPHReportdata.objBOMDetailsSummary.equipment;
                var colNames = CPHReportdata.objBOMDetailsSummary.lstIntervalCols;
                var classname = '';

                if (dtBOMDetails != null && dtBOMDetails.length > 0) {

                    //new table format for non printable view mode
                    var FixedheaderStartformat = '<div class="fix-column">' +
                        '<div class="thead">' +
                        '<span class="ItemIDCol">Item </span>' +
                        '<span class="DescriptionCol"> Description</span>' +
                        '</div> ' +
                        '<div class="tbody"> ';
                    var FixedheaderEndFormat = '</div> </div>'; // end tag for <div class="tbody"> and <div class="fix-column"> 

                    var RestcolsHeaderStartFormat =
                        '<div class="rest-columns"> ' +
                        '<div class="thead"> ' +
                        //'<span class="DescriptionCol"> Description </span> ' +
                        '<span class="SectionIDcol"> Section Id </span> ' +
                        '<span class="SectionCol"> Section </span> ' +
                        '<span class="ItemClasscol"> Item Class </span> ' +
                        '<span class="RECcol"> REC </span> ' +
                        '<span class="LifetimeHoursCol"> Lifetime Hours </span> ' +
                        '<span class="QtyCol"> Qty </span> ' +
                        '<span class="UnitPriceCol"> Unit Price </span> ' +
                        '<span class="TotalForecastQtyCol"> Total ForecastQty </span> ';
                    var RestcolsHeaderEndFormat = ' </div> ';

                    var RestColDataStartFormat = ' <div class="tbody"> ';
                    var RestColDataEndFormat = ' </div> </div> '; // <div class="tbody"> end div and also <div class="rest-columns"> end div

                    var PrintableRowdisplayoption = this.IsPrintClicked ? 'block;' : 'none;';
                    var NonPrintableRowdisplayoption = !this.IsPrintClicked ? 'block;' : 'none;';

                    for (let i = 0; i < dtBOMDetails.length; i++) {

                        var SectionId = dtBOMDetails[i].SectionId;
                        var Section = dtBOMDetails[i].Section;
                        var Item = dtBOMDetails[i].Item;
                        var Description = dtBOMDetails[i].Description;
                        var ItemClass = (dtBOMDetails[i].ItemClass == null || dtBOMDetails[i].ItemClass == "") ? "&nbsp;" : dtBOMDetails[i].ItemClass;
                        var REC = dtBOMDetails[i].REC;
                        var LifetimeHours = (dtBOMDetails[i].LifetimeHours == null) ? "&nbsp;" : this.Customround(dtBOMDetails[i].LifetimeHours.toFixed(2));
                        var Qty = (dtBOMDetails[i].Qty == null) ? "&nbsp;" : this.Customround(dtBOMDetails[i].Qty.toFixed(2));
                        var UnitPrice = (dtBOMDetails[i].UnitPrice == null) ? "&nbsp;" : this.Customround(dtBOMDetails[i].UnitPrice.toFixed(2));
                        var TotalForecastQty = (dtBOMDetails[i].TotalForecastQty == null) ? "&nbsp;" : this.Customround(dtBOMDetails[i].TotalForecastQty.toFixed(2));

                        if (i == 0) {
                            classname = '';
                        }
                        else if (i == 1) {
                            classname = 'trBackGround';
                        }
                        else if (i % 2 == 0) {
                            classname = '';
                        }
                        else {
                            classname = 'trBackGround';
                        }

                        this.BOMDetails_Printable_HTMLStructure +=

                            ' <tr class=' + classname + '>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + SectionId + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + Section + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + Item + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + Description + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + ItemClass + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + REC + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + LifetimeHours + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + Qty + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + UnitPrice + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + TotalForecastQty + ' </td>' +
                            ' </tr>' +

                            //' <tr class="' + classname + ' printableRow" style="display: ' + PrintableRowdisplayoption + '">' +
                            ' <tr class="' + classname + ' printableRow">' +
                            '<td class="trBorder printablerow" colspan= "10" width= "100%" >' +
                            '<table>' +
                            '<tr>' + this.createIntervalColRowForPrint(colNames, 0, 23) + '</tr>' +
                            '<tr>' + this.createIntervalValueRowForPrint(dtBOMDetails[i], colNames, 0, 23, UnitPrice, Qty) + '</tr>' +
                            '<tr style=' + (colNames.length > 23 ? 'block;' : 'none;') + '>' + this.createIntervalColRowForPrint(colNames, 24, 47) + '</tr>' +
                            '<tr style=' + (colNames.length > 23 ? 'block;' : 'none;') + '>' + this.createIntervalValueRowForPrint(dtBOMDetails[i], colNames, 24, 47, UnitPrice, Qty) + '</tr>' +
                            '<tr style=' + (colNames.length > 47 ? 'block;' : 'none;') + '>' + this.createIntervalColRowForPrint(colNames, 48, 71) + '</tr>' +
                            '<tr style=' + (colNames.length > 47 ? 'block;' : 'none;') + '>' + this.createIntervalValueRowForPrint(dtBOMDetails[i], colNames, 48, 71, UnitPrice, Qty) + '</tr>' +
                            '<tr style=' + (colNames.length > 71 ? 'block;' : 'none;') + '>' + this.createIntervalColRowForPrint(colNames, 72, 95) + '</tr>' +
                            '<tr style=' + (colNames.length > 71 ? 'block;' : 'none;') + '>' + this.createIntervalValueRowForPrint(dtBOMDetails[i], colNames, 72, 95, UnitPrice, Qty) + '</tr>' +
                            '<tr style=' + (colNames.length > 95 ? 'block;' : 'none;') + '>' + this.createIntervalColRowForPrint(colNames, 96, 119) + '</tr>' +
                            '<tr style=' + (colNames.length > 95 ? 'block;' : 'none;') + '>' + this.createIntervalValueRowForPrint(dtBOMDetails[i], colNames, 96, 119, UnitPrice, Qty) + '</tr>' +
                            '</table>' +
                            '</td>' +
                            ' </tr>';

                        //'<tr class="' + classname +' NonprintableRow">' +
                        //    '<td class="trBorder nonprintablerow" colspan= "9" style = "max-width: 920px !important;overflow-x:auto !important;padding: 0 !important;">' +
                        //    '<table>' +
                        //    '<tr>' + this.createIntervalColRow(colNames) + '</tr>' +
                        //    '<tr>' + this.createIntervalValueRow(dtBOMDetails[i], colNames, UnitPrice, Qty) + '</tr>' +
                        //    '</table>' +
                        //    '</td>' +
                        //'</tr>'

                        //new format table structure for non printable BOM Details table
                        if (i == 0) {
                            // Fixed header start format
                            this.BOMDetails_NonPrintable_FixedHeaderHTMLStructure = FixedheaderStartformat;
                            // Rest cols header start format
                            this.BOMDetails_NonPrintable_RestColHeaderHTMLStructure = RestcolsHeaderStartFormat;
                            // Rest cols header start format
                            this.BOMDetails_NonPrintable_RestColDataHTMLStructure = RestColDataStartFormat;
                        }

                        // Fixed Header data bind 
                        this.BOMDetails_NonPrintable_FixedHeaderHTMLStructure +=
                            ' <div class="trow ' + classname + '"> ' +
                            ' <span class="ItemIDCol"> ' + Item + ' </span> ' +
                            ' <span class="DescriptionCol">' + Description + '</span>' +
                            ' </div> ';

                        //Rest col header needs to bind only one time - Interval col names)
                        if (i == 0) {
                            this.BOMDetails_NonPrintable_RestColHeaderHTMLStructure +=
                                this.createIntervalColHeaderForNonPrintMode(colNames, 0, colNames.length);
                        }

                        // Rest col data bind
                        this.BOMDetails_NonPrintable_RestColDataHTMLStructure +=
                            this.createIntervalColValueForNonPrintMode(dtBOMDetails[i], colNames, 0, colNames.length, UnitPrice,
                                Qty, SectionId, Section, Description, ItemClass, REC,
                                LifetimeHours, TotalForecastQty, classname);


                        if (i == dtBOMDetails.length - 1) {

                            // Fixed header end format
                            this.BOMDetails_NonPrintable_FixedHeaderHTMLStructure += FixedheaderEndFormat;
                            // Rest Col header end format
                            this.BOMDetails_NonPrintable_RestColHeaderHTMLStructure += RestcolsHeaderEndFormat;
                            // Rest Col header end format
                            this.BOMDetails_NonPrintable_RestColDataHTMLStructure += RestColDataEndFormat;

                            this.BOMDetails_NonPrintable_FullHTMLStructure =
                                this.BOMDetails_NonPrintable_FixedHeaderHTMLStructure + this.BOMDetails_NonPrintable_RestColHeaderHTMLStructure + this.BOMDetails_NonPrintable_RestColDataHTMLStructure;
                        }


                    }

                    $(".tabRow").append(this.BOMDetails_Printable_HTMLStructure);
                    $(".total-wrapper").append(this.BOMDetails_NonPrintable_FullHTMLStructure);

                    this.BOMDetails_NonPrintable_FixedHeaderHTMLStructure = "";
                    this.BOMDetails_NonPrintable_RestColHeaderHTMLStructure = "";
                    this.BOMDetails_NonPrintable_RestColDataHTMLStructure = "";
                    this.BOMDetails_NonPrintable_FullHTMLStructure = "";
                    this.BOMDetails_Printable_HTMLStructure = "";

                    this.loadEvent();
                    //console.log(this.BOMDetails_Printable_HTMLStructure);

                }
                else {
                    this.BOMDetails_Printable_HTMLStructure =
                        ' <tr>' +
                        ' <td align= "center" colspan="10"> BOM details is not selected while generating report/ No record found for BOM details. </td>' +
                        ' </tr>';
                    $(".tabRow").append(this.BOMDetails_Printable_HTMLStructure);

                    this.BOMDetails_NonPrintable_FullHTMLStructure = '<div style="text-align:center">No record found for specific equipment.</div>';
                    $(".total-wrapper").append(this.BOMDetails_NonPrintable_FullHTMLStructure);

                    this.BOMDetails_NonPrintable_FixedHeaderHTMLStructure = "";
                    this.BOMDetails_NonPrintable_RestColHeaderHTMLStructure = "";
                    this.BOMDetails_NonPrintable_RestColDataHTMLStructure = "";
                    this.BOMDetails_NonPrintable_FullHTMLStructure = "";
                    this.BOMDetails_Printable_HTMLStructure = "";
                }

                this.loaderService.display(false);

            }).catch(this.handleError);


    }

    Customround(num) {
        var arrNum = num.toString().split('.');
        if (arrNum != null && arrNum.length == 2) {            
            if (arrNum[1] == "00" || arrNum[1] == "0") {
                return arrNum[0];
            }
        }

        return num;
    }

    createIntervalColHeaderForNonPrintMode(colNames, startIndex, endIndex) {

        var str = "";
        //var endIndex = colNames.length > endIndex ? endIndex : colNames.length;
        for (var intervalCol = startIndex; intervalCol < endIndex; intervalCol++) {
            str += ' <span class="intervalHeaderCols"> ' + colNames[intervalCol] + ' </span> ';
        }

        return str;
    }

    createIntervalColValueForNonPrintMode(RowBOMDetails, colNames, startIndex, endIndex, unitPrice, Qty,
        sectionID, section, description, itemClass, rec, lifeTimeHours, totalForecastQty, classname) {

        var str = ' <div class="trow ' + classname + '"> ' +
            //' <span class="DescriptionCol">' + description + ' </span> ' +
            ' <span class="SectionIDcol">' + sectionID + ' </span> ' +
            ' <span class="SectionCol">' + section + '</span> ' +
            ' <span class="ItemClasscol">' + itemClass + ' </span> ' +
            ' <span class="RECcol">' + rec + ' </span> ' +
            ' <span class="LifetimeHoursCol">' + lifeTimeHours + ' </span> ' +
            ' <span class="QtyCol">' + Qty + ' </span> ' +
            ' <span class="UnitPriceCol ' + classname + '">' + unitPrice + ' </span> ' +
            ' <span class="TotalForecastQtyCol ' + classname + '">' + totalForecastQty + ' </span> ';

        //var endIndex = colNames.length > endIndex ? endIndex : colNames.length;
        for (var intervalCol = startIndex; intervalCol < endIndex; intervalCol++) {

            var colValue = (RowBOMDetails[colNames[intervalCol]] == null) ? "&nbsp;" : this.Customround((Qty * unitPrice).toFixed(2));
            str += ' <span class="intervalDataCols ' + classname + '"> ' + colValue + ' </span> ';
        }

        str += ' </div> ';

        return str;

    }

    createIntervalColRowForPrint(colNames, startIndex, endIndex) {

        var str = "";
        var endIndex = colNames.length > endIndex ? endIndex : colNames.length;
        for (var intervalCol = startIndex; intervalCol < endIndex; intervalCol++) {
            str += '<td class="dynamicRowStyle">' + colNames[intervalCol] + ' </td>';
        }

        return str;

    }

    createIntervalValueRowForPrint(RowBOMDetails, colNames, startIndex, endIndex, unitPrice, Qty) {
                
        var str = "";
        var endIndex = colNames.length > endIndex ? endIndex : colNames.length;
        for (var intervalCol = startIndex; intervalCol < endIndex; intervalCol++) {

            var colValue = (RowBOMDetails[colNames[intervalCol]] == null) ? "&nbsp;" : this.Customround((Qty * unitPrice).toFixed(2));
            str += '<td class="dynamicRowStyle">' + colValue + ' </td>';
        }

        return str;
    }

    createIntervalColRow(colNames) {

        var str = "";
        for (var intervalCol = 0; intervalCol < colNames.length; intervalCol++) {
            str += '<td class="dynamicRowStyle">' + colNames[intervalCol] + ' </td>';
        }

        return str;

    }

    createIntervalValueRow(RowBOMDetails, colNames, unitPrice, Qty) {

        var str = "";
        for (var intervalCol = 0; intervalCol < colNames.length; intervalCol++) {

            var colValue = (RowBOMDetails[colNames[intervalCol]] == null) ? "&nbsp;" : (Qty * unitPrice).toFixed(2);
            str += '<td class="dynamicRowStyle" style="padding-left: 15px !important;">' + colValue + ' </td>';
        }

        return str;
    }

    private handleError(error: any): any {
        this.loaderService.display(false);
        alert('An error occurred: ' + error);
    }
}
