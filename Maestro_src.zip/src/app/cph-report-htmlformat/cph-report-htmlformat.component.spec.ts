import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CphReportHtmlformatComponent } from './cph-report-htmlformat.component';

describe('CphReportHtmlformatComponent', () => {
  let component: CphReportHtmlformatComponent;
  let fixture: ComponentFixture<CphReportHtmlformatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CphReportHtmlformatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CphReportHtmlformatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
