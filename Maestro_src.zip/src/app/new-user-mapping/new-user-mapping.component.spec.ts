import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewUserMappingComponent } from './new-user-mapping.component';

describe('NewUserMappingComponent', () => {
  let component: NewUserMappingComponent;
  let fixture: ComponentFixture<NewUserMappingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewUserMappingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewUserMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
