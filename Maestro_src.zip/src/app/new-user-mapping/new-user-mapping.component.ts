import { Component, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable, ElementRef } from '@angular/core';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Subject }    from 'rxjs/Subject';
import { Country_mm } from '../services/eq-exclusions-class';
import {CustomerCountryService} from './../services/customer-country.service';
import { DataService } from './../services/data-component.service';
import { NewUserMappingService } from './../services/new-user-mapping.service';
import {EqExclusionsServiceService} from '../services/eq-exclusions-service.service';
import {SelectItem} from './api';
declare var PNotify: any;

declare var jquery: any;
declare var $: any;

@Component({
    selector: 'app-new-user-mapping',
    templateUrl: './new-user-mapping.component.html',
    styleUrls: ['./new-user-mapping.component.css'],
    providers: [CustomerCountryService, EqExclusionsServiceService]
})
export class NewUserMappingComponent implements OnInit {

    public countrymmAdmin: Country_mm[];
    DefaultCountry = 'select';
    UserName = '';
    UserID = '';
    UserRole = 'select';

    selectCountries = [];

    selectedCountries: string[] = [];

    //selectedCars2: string[] = [];

    formModel: any = {
        'DefaultCountry': 'select', 'UserName': 'input', 'UserRole': 'select', 'selectedcountries': ''
    };
    constructor(private eRef: ElementRef, public activeModal: NgbActiveModal, public changeRef: ChangeDetectorRef,
        private customerCountryService: CustomerCountryService, private dataService: DataService,
        private newUserMappingService: NewUserMappingService,
        private eqExclusionsServiceService: EqExclusionsServiceService,
    ) {
    }

    ngOnInit() {
        var divUsername = document.getElementById('UserName');
        divUsername.className = "ng-invalid-input";
        this.getCountry();
    }

    onModelChange(value, str) {
        this.formModel[str] = value;
    }

    multiselectDropDownDisable() {
        return this.UserRole == 'Admin';
    }

    getCountry(): void {

        this.eqExclusionsServiceService.getCountryList().then(result => {
            if (result) {
                //debugger;
                var uniqueCountries = [];
                result.forEach(objResult => {
                    var objCountry = this.selectCountries.filter(x => x.value == objResult.CountryCode);
                    if (objCountry.length == 0) {
                        var obj = {
                            "label": objResult.CountryName, "value": objResult.CountryCode
                        }
                        this.selectCountries.push(obj);
                        uniqueCountries.push({ CountryName: objResult.CountryName, CountryCode: objResult.CountryCode });
                    }

                })
                this.countrymmAdmin = uniqueCountries;
            }
        })
            .catch(error => console.log(error));
        //this.customerCountryService.customerCountryData().then(result => {
        //    const index = result.findIndex(res => res.COUNTRY === "All");
        //    result.splice(index, 1);
        //    this.countrymmAdmin = result;
        //    result.forEach(obj => {
        //        var objcountry = {
        //            "label": obj.COUNTRY, "value": obj.COUNTRY
        //        }
        //        this.selectCountries.push(objcountry);
        //    })
        //}).catch(error => console.log(error));
    }

    onOkClick() {

        PNotify.prototype.options.styling = "fontawesome";
        PNotify.prototype.options.stack.firstpos2 = 250;
        new PNotify({
            text: 'Saving Data',
            delay: 3000,
            width: 500
        });

        this.newUserMappingService.saveMaestroUsers(this.formModel).then(
            result => {
                if (result == "False") {
                    this.saveSuccessHandler("Error while saving data into database", "error");
                }
                else {
                    this.saveSuccessHandler("Data Saved Successfully", "success");
                    this.activeModal.dismiss(true);
                }
            }
        );
    }

    saveSuccessHandler(msg, messageType) {
        PNotify.removeAll();
        PNotify.prototype.options.styling = "fontawesome";
        PNotify.prototype.options.stack.firstpos2 = 250;

        new PNotify({
            //text: 'Data Saved Successfully',
            text: msg,
            delay: 3000,
            width: 2000,
            //type: 'success'
            type: messageType
        });
    }

    onReset() {
        this.activeModal.dismiss(true);
    }

    validateForm() {
        return $('select').hasClass('ng-invalid-select') || $('input').hasClass('ng-invalid-input');
    }

    getDynamicClass(ref, controlValue) {

        var className = "";
        if (ref == "DefaultCountry" || ref == "UserRole") {
            className = controlValue == 'select' ? 'ng-invalid-select' : 'ng-valid-select';
        }
        else if (ref == "UserName") {
            //className = !this.ValidateEmail(controlValue) ? 'ng-invalid-input' : 'ng-valid-input';
        }
        else {
            className = controlValue == '' ? 'ng-invalid-input' : 'ng-valid-input';
        }
        return className;
    }

    ValidateEmail(inputText) {

        //debugger;
        //var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        //var mailformat = /^\w+([\.-]?\w+)*@sandvik.com/;
        if (inputText) {
            if (inputText.indexOf('@') != -1) {
                var arrEmail = inputText.split('@');
                if (arrEmail.length == 2) {
                    if (arrEmail[1] == 'sandvik.com') {
                        return true;
                    }
                    else {
                        return false;
                    }
                }
                else {
                    return false;
                }
            }
            else {
                return false;
            }
            //if (inputText.match(mailformat)) {
            //    return true;
            //}
            //else {
            //    return false;
            //}
        }
        else {
            return false;
        }
    }

    getStyle(controlValue) {
        //debugger;
        var divUsername = document.getElementById('UserName');
        if (!this.ValidateEmail(controlValue)) {
            divUsername.className = "ng-invalid-input";
        }
        else {
            divUsername.className = "ng-valid-input";
        }
    }

}

@Injectable() export class NewUserMappingDialogService {

    constructor(private modalService: NgbModal) { }

    public show() {
        const modalRef = this.modalService.open(NewUserMappingComponent, { windowClass: "advanced-rule-window" });
        modalRef.componentInstance.name = "newUserMapping";
        modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }
}
