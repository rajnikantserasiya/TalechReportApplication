import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartConsumptionReportHtmlFormatComponent } from './part-consumption-report-html-format.component';

describe('PartConsumptionReportHtmlFormatComponent', () => {
  let component: PartConsumptionReportHtmlFormatComponent;
  let fixture: ComponentFixture<PartConsumptionReportHtmlFormatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartConsumptionReportHtmlFormatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartConsumptionReportHtmlFormatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
