import { Component, OnInit, AfterViewInit, ElementRef } from '@angular/core';
import {AccordionModule} from 'primeng/accordion';
import { AuthService } from "../interceptor/auth.service";
import { HttpClient } from '@angular/common/http';
import {Http, Response, Headers, RequestOptions, Request, RequestMethod} from "@angular/http";
import { environment } from '../../environments/environment';
import { LoaderService } from '../services/loader.service';
declare var jquery: any;
declare var $: any;

@Component({
    selector: 'app-part-consumption-report-html-format',
    templateUrl: './part-consumption-report-html-format.component.html',
    styleUrls: ['./part-consumption-report-html-format.component.css'],
    providers: [AccordionModule]
})
export class PartConsumptionReportHtmlFormatComponent implements OnInit, AfterViewInit {

    IsPrintClicked = false;
    toggleChecked: boolean = false;
    ModelCategory: string = '';
    Model: string = '';
    Equipment: string = '';
    //dtBOMDetails: PartConsumptionBOMDetailsClass[] = [];
    BOMDetailsHTMLStructure = '';
    BOMDetails_Printable_HTMLStructure = '';
    BOMDetails_NonPrintable_FixedHeaderHTMLStructure = '';
    BOMDetails_NonPrintable_RestColHeaderHTMLStructure = '';
    BOMDetails_NonPrintable_RestColDataHTMLStructure = '';
    BOMDetails_NonPrintable_FullHTMLStructure = '';

    //Executive summary section
    DateField = '';
    Author = '';
    Pricing = '';
    FromHrs = '';
    ToHrs = '';
    TotalItems = '';
    TotalPrice = '';
    Equipment_SN = '';
    Equipment_Model = '';
    Qty = '';
    Excludes = '';

    //Excluded
    dtExcludedItems = [];

    // visible tab properties
    tabBOMDetails = false;
    tabExecutiveSummary = false;

    constructor(private _http: HttpClient, private loaderService: LoaderService, public eRef: ElementRef) { }

    ngOnInit() {
        this.partConsumptionInHTMLFormat();
    }

    ngAfterViewInit() {
        //this.loadEvent();
    }

    loadEvent() {

        var fcBody = this.eRef.nativeElement.querySelector(".fix-column > .tbody"),
            rcBody = this.eRef.nativeElement.querySelector(".rest-columns > .tbody"),
            rcHead = this.eRef.nativeElement.querySelector(".rest-columns > .thead");
        rcBody.addEventListener(
            "scroll",
            function () {
                fcBody.scrollTop = this.scrollTop;
                rcHead.scrollLeft = this.scrollLeft;
            },
            { passive: true }
        );
    }

    PrintPreviewmodeMethod() {

        this.IsPrintClicked = !this.IsPrintClicked;
        if (!this.IsPrintClicked) {
            //$(".printableRow").hide();
            //$(".NonprintableRow").show();
            $(".printableTableFormat").hide();
            $(".nonprintableTableFormat").show();
        }

        if (this.IsPrintClicked) {
            //$(".printableRow").show();
            //$(".NonprintableRow").hide();
            $(".printableTableFormat").show();
            $(".nonprintableTableFormat").hide();
        }
    }

    trackByIndex(index: number, value: number) {
        return index;
    }

    partConsumptionInHTMLFormat() {

        this.loaderService.display(true);

        var username = localStorage.getItem("UserName");
        var eqSourceType = localStorage.getItem("htmlReportSelectedEquipment_SourceType");
        var SerialNo = localStorage.getItem("htmlReportSelectedEquipment_SerialNo");
        var Model = localStorage.getItem("htmlReportSelectedEquipment_Model");
        var FromHrs = localStorage.getItem("htmlReportSelectedEquipment_FromHrs");
        var ToHrs = localStorage.getItem("htmlReportSelectedEquipment_ToHrs");
        var ReportIntervalTxt = localStorage.getItem("ReportIntervalTxt");
        var ReportHrsType = localStorage.getItem("ReportHrsType");
        var ApplyAlignment = localStorage.getItem("ApplyAlignment");
        var ApplySuppression = localStorage.getItem("ApplySuppression");
        var ReportFilter = localStorage.getItem("ReportFilter");
        var PriceListType = localStorage.getItem("PriceListType");
        var PriceList = localStorage.getItem("PriceList");
        var reportCostPerStrategy = localStorage.getItem("htmlReportSelectedEquipment_ReportCostPerStrategy");
        var reportExecutiveSummary = localStorage.getItem("htmlReportSelectedEquipment_ReportExecutiveSummary");
        var reportIntervalSummary = localStorage.getItem("htmlReportSelectedEquipment_ReportIntervalSummary");
        var reportBOMDetails = localStorage.getItem("htmlReportSelectedEquipment_ReportBOMDetails");
        var reportInterest = localStorage.getItem("htmlReportSelectedEquipment_ReportInterest");
        var reportFormat = localStorage.getItem("htmlReportSelectedEquipment_ReportFormat");
        var PriceListCountry = localStorage.getItem("htmlReportSelectedEquipment_Country");

        if (reportExecutiveSummary == "true") {
            this.tabExecutiveSummary = true
        }

        if (reportBOMDetails == "true") {
            this.tabBOMDetails = true
        }

        let reportOption: string =
            '{"UserName":"' + username +
            '","EqSourceType":"' + eqSourceType +
            //'","SerialNo":"' + SerialNo +
            //'","Model":"' + Model +
            '","Model_SerialNo":"' + Model + SerialNo +
            '","HoursFrom":"' + FromHrs +
            '","HoursTo":"' + ToHrs +
            '","Interval":"' + ReportIntervalTxt +
            '","ReportHrsType":"' + ReportHrsType +
            '","ApplyAlignment":"' + ApplyAlignment +
            '","ApplySuppression":"' + ApplySuppression +
            '","FilterType":"' + ReportFilter +
            '","PriceType":"' + PriceListType +
            '","PriceList":"' + PriceList +
            '","PriceListCountry":"' + PriceListCountry +
            '","reportCostPerStrategy":"' + reportCostPerStrategy +
            '","reportExecutiveSummary":"' + reportExecutiveSummary +
            '","reportIntervalSummary":"' + reportIntervalSummary +
            '","reportBOMDetails":"' + reportBOMDetails +
            '","reportInterest":"' + reportInterest +
            '","reportFormat":"' + reportFormat +
            '"}';

        //let dataTosend: string = JSON.stringify(reportOption);

        var headers = new Headers();
        headers.append("Content-Type", 'application/json');
        headers.append("charset", 'utf-8');

        var requestoptions = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: reportOption
        })

        return this._http.post(environment.apiUrl + 'MaestroReport/PartConsumptionInHTMLFormat', requestoptions)
            .toPromise().then(result => {

                var CPHReportdata = JSON.parse(JSON.stringify(result));

                // Executive Summary section
                this.DateField = CPHReportdata.objExecutiveSummary.Date;
                this.Author = CPHReportdata.objExecutiveSummary.Author;
                this.Pricing = CPHReportdata.objExecutiveSummary.Pricing;
                this.FromHrs = CPHReportdata.objExecutiveSummary.From;
                this.ToHrs = CPHReportdata.objExecutiveSummary.To;
                this.TotalItems = CPHReportdata.objExecutiveSummary.TotalItems;
                this.TotalPrice = CPHReportdata.objExecutiveSummary.TotalPrice;
                this.Equipment_SN = CPHReportdata.objExecutiveSummary.Equipment;
                this.Equipment_Model = CPHReportdata.objExecutiveSummary.Model;
                this.Qty = CPHReportdata.objExecutiveSummary.Qty;
                this.Excludes = CPHReportdata.objExecutiveSummary.Excludes;

                //Excluded section
                this.dtExcludedItems = CPHReportdata.objExcludeItemsSummary.dtExcludedItems;

                //BOM Details section
                var dtBOMDetails = CPHReportdata.objBOMDetailsSummary.dtBOMDetails;
                this.ModelCategory = CPHReportdata.objBOMDetailsSummary.modelCategory;
                this.Model = CPHReportdata.objBOMDetailsSummary.model;
                this.Equipment = CPHReportdata.objBOMDetailsSummary.equipment;
                var colNames = CPHReportdata.objBOMDetailsSummary.lstIntervalCols;
                var classname = '';

                if (dtBOMDetails != null && dtBOMDetails.length > 0) {

                    //new table format for non printable view mode
                    var FixedheaderStartformat = '<div class="fix-column">' +
                        '<div class="thead">' +
                        '<span class="ItemIDCol">Item </span>' +
                        '<span class="DescriptionCol"> Description</span>' +
                        '</div> ' +
                        '<div class="tbody"> ';
                    var FixedheaderEndFormat = '</div> </div>'; // end tag for <div class="tbody"> and <div class="fix-column"> 

                    var RestcolsHeaderStartFormat =
                        '<div class="rest-columns"> ' +
                        '<div class="thead"> ' +
                        '<span class="SectionIDcol"> Section Id </span> ' +
                        '<span class="SectionCol"> Section </span> ' +
                        '<span class="ItemClasscol"> Item Class </span> ' +
                        '<span class="RECcol"> REC </span> ' +
                        '<span class="LifetimeHoursCol"> Lifetime Hours </span> ' +
                        '<span class="QtyCol"> Qty </span> ' +
                        //'<span class="UnitPriceCol"> Unit Price </span> ' +
                        '<span class="TotalForecastQtyCol"> Total ForecastQty </span> ';
                    var RestcolsHeaderEndFormat = ' </div> ';

                    var RestColDataStartFormat = ' <div class="tbody"> ';
                    var RestColDataEndFormat = ' </div> </div> '; // <div class="tbody"> end div and also <div class="rest-columns"> end div

                    var PrintableRowdisplayoption = this.IsPrintClicked ? 'block;' : 'none;';
                    var NonPrintableRowdisplayoption = !this.IsPrintClicked ? 'block;' : 'none;';

                    for (let i = 0; i < dtBOMDetails.length; i++) {

                        var SectionId = dtBOMDetails[i].SectionId;
                        var Section = dtBOMDetails[i].Section;
                        var Item = dtBOMDetails[i].Item;
                        var Description = dtBOMDetails[i].Description;
                        var ItemClass = (dtBOMDetails[i].ItemClass == null || dtBOMDetails[i].ItemClass == "") ? "&nbsp;" : dtBOMDetails[i].ItemClass;
                        var REC = dtBOMDetails[i].REC;
                        var LifetimeHours = (dtBOMDetails[i].LifetimeHours == null) ? "&nbsp;" : this.Customround(dtBOMDetails[i].LifetimeHours.toFixed(2));
                        var Qty = (dtBOMDetails[i].Qty == null) ? "&nbsp;" : this.Customround(dtBOMDetails[i].Qty.toFixed(2));
                        //var UnitPrice = (dtBOMDetails[i].UnitPrice == null || dtBOMDetails[i].UnitPrice == "") ? "" : dtBOMDetails[i].UnitPrice;
                        var TotalForecastQty = (dtBOMDetails[i].TotalForecastQty == null) ? "&nbsp;" : this.Customround(dtBOMDetails[i].TotalForecastQty.toFixed(2));

                        if (i == 0) {
                            classname = '';
                        }
                        else if (i == 1) {
                            classname = 'trBackGround';
                        }
                        else if (i % 2 == 0) {
                            classname = '';
                        }
                        else {
                            classname = 'trBackGround';
                        }

                        this.BOMDetailsHTMLStructure +=
                            ' <tr class=' + classname + '>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + SectionId + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + Section + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + Item + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + Description + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + ItemClass + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + REC + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + LifetimeHours + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + Qty + ' </td>' +
                            ' <td align= "left" class="dynamicRowStyle"> ' + TotalForecastQty + ' </td>' +
                            ' </tr>' +

                            ' <tr class="' + classname + ' printableRow">' +
                            '<td class="trBorder printablerow" colspan= "9" width= "100%">' +
                            '<table>' +
                            '<tr>' + this.createIntervalColRowForPrint(colNames, 0, 23) + '</tr>' +
                            '<tr>' + this.createIntervalValueRowForPrint(dtBOMDetails[i], colNames, 0, 23) + '</tr>' +
                            '<tr style=' + (colNames.length > 23 ? 'block;' : 'none;') + '>' + this.createIntervalColRowForPrint(colNames, 24, 47) + '</tr>' +
                            '<tr style=' + (colNames.length > 23 ? 'block;' : 'none;') + '>' + this.createIntervalValueRowForPrint(dtBOMDetails[i], colNames, 24, 47) + '</tr>' +
                            '<tr style=' + (colNames.length > 47 ? 'block;' : 'none;') + '>' + this.createIntervalColRowForPrint(colNames, 48, 71) + '</tr>' +
                            '<tr style=' + (colNames.length > 47 ? 'block;' : 'none;') + '>' + this.createIntervalValueRowForPrint(dtBOMDetails[i], colNames, 48, 71) + '</tr>' +
                            '<tr style=' + (colNames.length > 71 ? 'block;' : 'none;') + '>' + this.createIntervalColRowForPrint(colNames, 72, 95) + '</tr>' +
                            '<tr style=' + (colNames.length > 71 ? 'block;' : 'none;') + '>' + this.createIntervalValueRowForPrint(dtBOMDetails[i], colNames, 72, 95) + '</tr>' +
                            '<tr style=' + (colNames.length > 95 ? 'block;' : 'none;') + '>' + this.createIntervalColRowForPrint(colNames, 96, 119) + '</tr>' +
                            '<tr style=' + (colNames.length > 95 ? 'block;' : 'none;') + '>' + this.createIntervalValueRowForPrint(dtBOMDetails[i], colNames, 96, 119) + '</tr>' +
                            '</table>' +
                            '</td>' +
                            ' </tr>';

                        //'<tr class="NonprintableRow">' +
                        //    '<td class="trBorder nonprintablerow" colspan= "9" style = "max-width: 920px !important;overflow-x:auto !important;padding: 0 !important;">' +
                        //        '<table>' +
                        //            '<tr>' + this.createIntervalColRow(colNames) + '</tr>' +
                        //            '<tr>' + this.createIntervalValueRow(dtBOMDetails[i], colNames) + '</tr>' +
                        //        '</table>' +
                        //    '</td>' +
                        //'</tr>'

                        //new format table structure for non printable BOM Details table
                        if (i == 0) {
                            // Fixed header start format
                            this.BOMDetails_NonPrintable_FixedHeaderHTMLStructure = FixedheaderStartformat;
                            // Rest cols header start format
                            this.BOMDetails_NonPrintable_RestColHeaderHTMLStructure = RestcolsHeaderStartFormat;
                            // Rest cols header start format
                            this.BOMDetails_NonPrintable_RestColDataHTMLStructure = RestColDataStartFormat;
                        }

                        // Fixed Header data bind 
                        this.BOMDetails_NonPrintable_FixedHeaderHTMLStructure +=
                            ' <div class="trow ' + classname + '"> ' +
                            ' <span class="ItemIDCol"> ' + Item + ' </span> ' +
                            ' <span class="DescriptionCol">' + Description + '</span>' +
                            ' </div> ';

                        //Rest col header needs to bind only one time - Interval col names)
                        if (i == 0) {
                            this.BOMDetails_NonPrintable_RestColHeaderHTMLStructure +=
                                this.createIntervalColHeaderForNonPrintMode(colNames, 0, colNames.length);
                        }

                        // Rest col data bind
                        this.BOMDetails_NonPrintable_RestColDataHTMLStructure +=
                            this.createIntervalColValueForNonPrintMode(dtBOMDetails[i], colNames, 0, colNames.length, Qty,
                                SectionId, Section, Description, ItemClass, REC, LifetimeHours, TotalForecastQty, classname);


                        if (i == dtBOMDetails.length - 1) {

                            // Fixed header end format
                            this.BOMDetails_NonPrintable_FixedHeaderHTMLStructure += FixedheaderEndFormat;
                            // Rest Col header end format
                            this.BOMDetails_NonPrintable_RestColHeaderHTMLStructure += RestcolsHeaderEndFormat;
                            // Rest Col header end format
                            this.BOMDetails_NonPrintable_RestColDataHTMLStructure += RestColDataEndFormat;

                            this.BOMDetails_NonPrintable_FullHTMLStructure =
                                this.BOMDetails_NonPrintable_FixedHeaderHTMLStructure + this.BOMDetails_NonPrintable_RestColHeaderHTMLStructure + this.BOMDetails_NonPrintable_RestColDataHTMLStructure;
                        }

                    }

                    $(".tabRow").append(this.BOMDetailsHTMLStructure);
                    $(".total-wrapper").append(this.BOMDetails_NonPrintable_FullHTMLStructure);

                    this.BOMDetails_NonPrintable_FixedHeaderHTMLStructure = "";
                    this.BOMDetails_NonPrintable_RestColHeaderHTMLStructure = "";
                    this.BOMDetails_NonPrintable_RestColDataHTMLStructure = "";
                    this.BOMDetails_NonPrintable_FullHTMLStructure = "";
                    this.BOMDetailsHTMLStructure = "";

                    this.loadEvent();
                    //console.log(this.BOMDetailsHTMLStructure);

                }
                else {
                    this.BOMDetailsHTMLStructure =
                        ' <tr>' +
                        ' <td align= "center" colspan="9" > No record found for BOM details. </td>' +
                        ' </tr>';
                    $(".tabRow").append(this.BOMDetailsHTMLStructure);


                    this.BOMDetails_NonPrintable_FullHTMLStructure = '<div style="text-align:center">No record found for specific equipment.</div>';
                    $(".total-wrapper").append(this.BOMDetails_NonPrintable_FullHTMLStructure);

                    this.BOMDetails_NonPrintable_FixedHeaderHTMLStructure = "";
                    this.BOMDetails_NonPrintable_RestColHeaderHTMLStructure = "";
                    this.BOMDetails_NonPrintable_RestColDataHTMLStructure = "";
                    this.BOMDetails_NonPrintable_FullHTMLStructure = "";
                    this.BOMDetailsHTMLStructure = "";
                }

                this.loaderService.display(false);

            }).catch(this.handleError);


    }


    Customround(num) {
        var arrNum = num.toString().split('.');
        if (arrNum != null && arrNum.length == 2) {
            debugger;
            if (arrNum[1] == "00" || arrNum[1] == "0") {
                return arrNum[0];
            }
        }

        return num;
    }

    createIntervalColHeaderForNonPrintMode(colNames, startIndex, endIndex) {

        var str = "";
        //var endIndex = colNames.length > endIndex ? endIndex : colNames.length;
        for (var intervalCol = startIndex; intervalCol < endIndex; intervalCol++) {
            str += ' <span class="intervalHeaderCols"> ' + colNames[intervalCol] + ' </span> ';
        }

        return str;
    }

    createIntervalColValueForNonPrintMode(RowBOMDetails, colNames, startIndex, endIndex, Qty,
        sectionID, section, description, itemClass, rec, lifeTimeHours, totalForecastQty, classname) {

        var str = ' <div class="trow ' + classname + '"> ' +
            //' <span class="DescriptionCol">' + description + ' </span> ' +
            ' <span class="SectionIDcol">' + sectionID + ' </span> ' +
            ' <span class="SectionCol">' + section + '</span> ' +
            ' <span class="ItemClasscol">' + itemClass + ' </span> ' +
            ' <span class="RECcol">' + rec + ' </span> ' +
            ' <span class="LifetimeHoursCol">' + lifeTimeHours + ' </span> ' +
            ' <span class="QtyCol">' + Qty + ' </span> ' +
            //' <span class="UnitPriceCol ' + classname + '">' + unitPrice + ' </span> ' +
            ' <span class="TotalForecastQtyCol ' + classname + '">' + totalForecastQty + ' </span> ';

        //var endIndex = colNames.length > endIndex ? endIndex : colNames.length;
        for (var intervalCol = startIndex; intervalCol < endIndex; intervalCol++) {

            var colValue = (RowBOMDetails[colNames[intervalCol]] == null) ? "&nbsp;" : RowBOMDetails[colNames[intervalCol]];
            str += ' <span class="intervalDataCols ' + classname + '"> ' + colValue + ' </span> ';
        }

        str += ' </div> ';

        return str;

    }

    createIntervalColRowForPrint(colNames, startIndex, endIndex) {

        var str = "";
        var endIndex = colNames.length > endIndex ? endIndex : colNames.length;
        for (var intervalCol = startIndex; intervalCol < endIndex; intervalCol++) {
            str += '<td class="dynamicRowStyle">' + colNames[intervalCol] + ' </td>';
        }

        return str;

    }

    createIntervalValueRowForPrint(RowBOMDetails, colNames, startIndex, endIndex) {

        var str = "";
        var endIndex = colNames.length > endIndex ? endIndex : colNames.length;
        for (var intervalCol = startIndex; intervalCol < endIndex; intervalCol++) {
            var colValue = (RowBOMDetails[colNames[intervalCol]] == null || RowBOMDetails[colNames[intervalCol]] == "") ?
                "&nbsp;" : RowBOMDetails[colNames[intervalCol]];
            str += '<td class="dynamicRowStyle">' + colValue + ' </td>';
        }

        return str;
    }

    createIntervalColRow(colNames) {

        var str = "";
        for (var intervalCol = 0; intervalCol < colNames.length; intervalCol++) {
            str += '<td class="dynamicRowStyle">' + colNames[intervalCol] + ' </td>';
        }

        return str;
    }

    createIntervalValueRow(RowBOMDetails, colNames) {

        var str = "";
        for (var intervalCol = 0; intervalCol < colNames.length; intervalCol++) {
            var colValue = '';
            var intervalVal = RowBOMDetails[colNames[intervalCol]];

            if (intervalVal != null) {
                colValue = intervalVal;
            }
            else {
                colValue = "&nbsp;";
            }

            str += '<td class="dynamicRowStyle" style="padding-left: 15px !important;">' + colValue + ' </td>';
        }

        return str;
    }

    private extractData(res: Response) {
        return res;
    }

    private handleError(error: any): any {
        console.error('An error occurred', error);
    }

}



export class PartConsumptionBOMDetailsClass {
    SectionID: string;
    Section: string;
    Item: string;
    Description: string;
    ItemClass: number = 0;
    LifetimeHours: number = 0;
    Qty: number = 0;
    TotalForecastQty: string;
}