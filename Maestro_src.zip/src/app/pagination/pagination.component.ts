import {Component, Input, OnInit, OnDestroy, ApplicationRef, ChangeDetectorRef, Injectable, EventEmitter, Output, OnChanges, SimpleChange, SimpleChanges } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import {PaginationService } from '../services/pagination.service';

@Component({
    selector: 'app-pagination',
    templateUrl: './pagination.component.html',
    styleUrls: ['./pagination.component.css'],
    providers: [PaginationService]
})
export class PaginationComponent implements OnInit {

    pagesToDisplay: any = [{ 'page': 1 }];
    startIndex = 1;
    endIndex = 1;
    currentPage = 1;
    totalPages;
    changeLog: string[] = [];

    @Input('totalCount') totalCount: any;
    @Output() refreshData: EventEmitter<any> = new EventEmitter();
    recordsPerPage = 10;


    constructor(private paginationService: PaginationService) {
    }

    ngOnInit() {
        this.initialisePagination();
    }

    ngOnDestroy() {
        this.changeLog.push(`Component Destroyed`);
        this.pagesToDisplay = [];
    }

    ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
        let log: string[] = [];
        for (let propName in changes) {
            let changedProp = changes[propName];
            let to = JSON.stringify(changedProp.currentValue);
            if (changedProp.isFirstChange()) {
                log.push(`Initial value of ${propName} set to ${to}`);
            } else {
                let from = JSON.stringify(changedProp.previousValue);
                log.push(`${propName} changed from ${from} to ${to}`);
                if (propName === "totalCount" && changedProp.previousValue != changedProp.currentValue) {
                    this.initialisePagination();
                }
            }
        }
        this.changeLog.push(log.join(', '));
    }

    initialisePagination(): void {
        this.paginationService.setRecordsPerPage(this.recordsPerPage);
        this.paginationService.setTotalCount(this.totalCount);
        this.paginationService.setTotalNumberOfPages();
        this.totalPages = this.paginationService.getTotalNumberOfPages();
        this.currentPage = 1;
        this.pagesToDisplay = [];
        var pagingLimitTemp = 0;
        if (this.paginationService.getPagesToDisplay() > this.totalPages) {
            pagingLimitTemp = this.totalPages;
        } else {
            pagingLimitTemp = this.paginationService.getPagesToDisplay();
        }

        for (var i = 1; i <= pagingLimitTemp; i++) {
            this.pagesToDisplay.push({ "page": i });
            this.endIndex = i;
        }

        if (this.pagesToDisplay.length == 0) {
            this.pagesToDisplay.push({ "page": 0 });
        }
    }


    rerenderPagination(action): void {
        if (this.currentPage <= this.endIndex && (this.currentPage - this.endIndex == this.paginationService.getPagesToDisplay())) {
            // in case you have 5 pages and next page is 3 dont rerender pagination -todo
        }
        else if (this.currentPage > this.endIndex || this.currentPage < this.startIndex && action == "previous") {
            // make sure we maintain the total number of pages to be displayed any time if pages are more than 5 - todo
            this.startIndex = this.currentPage;        
            this.endIndex = this.startIndex + (this.paginationService.getPagesToDisplay()-1);
            if (this.endIndex > this.totalPages) {
                this.endIndex = this.totalPages;
            }
            this.pagesToDisplay = [];
            var count = 0;
            for (var i = this.startIndex; i <= this.endIndex; i++) {
                this.pagesToDisplay.push({ "page": i });
                count++;
                if (count == this.paginationService.getPagesToDisplay()) {
                    break;
                }
            }
        }
        this.refreshPaginationData();
    }

    changePage(action, pageClicked) {
        switch (action) {
            case "first":
                if (this.totalPages >= 1) {
                    this.currentPage = 1;
                }
                break;

            case "last":
                if (this.totalPages >= 1) {
                    this.currentPage = this.totalPages;
                }
                break;

            case "previous":
                if (this.currentPage > 1) {
                    this.currentPage -= 1;
                }
                break;

            case "next":
                //todo - one page is getting reduced in few cases 
                if (this.currentPage < this.totalPages) {
                    this.currentPage += 1;
                }
                break;

            case "goToPage":
                this.currentPage = pageClicked;

                break;
            default: break;
        }
        this.paginationService.setCurrentPage(this.currentPage);
        this.rerenderPagination(action);
    }

    setSelectedClass(item): string {
        if (item.page === this.currentPage) {
            return 'active';
        }
    }

    enableDisable(str): string {
        var cls = "";
        switch (str) {
            case 'previous':
                if (this.currentPage == 1 || this.totalPages == 1) {
                    cls = 'disabled';
                }
                break;

            case 'next':
                if (this.currentPage == this.totalPages) {
                    cls = 'disabled';
                }
                break;
        }
        return cls;
    }

    refreshPaginationData() {
        //fire's control back to the parent component -  end point for service or client pagination (client pagination will make use of filters to limit the data in the dom  tree)
        this.refreshData.emit({ "startIndex": this.currentPage, "endIndex": this.endIndex, "itemsPerPage": this.recordsPerPage, "action": "refresh" });
    }

}





