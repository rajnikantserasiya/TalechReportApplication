import {Component, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable } from '@angular/core';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import {ReportService} from '../services/report.service';
import { SelectEquipmentMasterService } from './../services/select-equipment-master.service';
import { DataService } from './../services/data-component.service';
import { EqSelectedPreviewList } from '../services/eq-exclusions-class';
import { EqSelectedList } from '../services/eq-exclusions-class';
declare var jquery: any;
declare var $: any;
declare var PNotify: any;

@Component({
    selector: 'app-reports-poc-bom-sheet',
    templateUrl: './reports-poc-bom-sheet.component.html',
    styleUrls: ['./reports-poc-bom-sheet.component.css']
})
export class ReportsPocBomSheetComponent implements OnInit {

    selectedEquipment: EqSelectedList[];
    eqSelectedPreviewList: EqSelectedPreviewList[] = [];
    strEquipment = "Select equipment";
    disableReportschange: boolean = false;

    constructor(private reportService: ReportService, private dataService: DataService, private selectEquipmentMasterService: SelectEquipmentMasterService) {
    }

    ngOnInit() {
        // UI Changes
        document.getElementById("slide-nav").style.width = "0";
        this.getSelectedEquipmentList();
        this.selectedEquipment = [];
    }

    getSelectedEquipmentList(): void {

        if (this.dataService.getData('selectedEquipment').length > 0) {
            var result = this.dataService.getData('selectedEquipment');
            this.getEquipmentSelectedList(result);
        } else {
            this.selectEquipmentMasterService.selectedEquipmentMaster()
                .then(result => {
                    this.getEquipmentSelectedList(result)
                })
                .catch(error => console.log(error));
        }
    }

    getEquipmentSelectedList(result) {

        this.selectedEquipment = result;
        let intInc: number = 0;

        for (let entry of this.selectedEquipment) {
            let strEquipment: string = "";
            intInc = intInc + 1;
            if (entry["EqSourceType"] == "1") {
                strEquipment = entry["Model"] + ' SN:' + entry["SerialNo"];
            };
            if (entry["EqSourceType"] == "2") {
                strEquipment = entry["Model"] + ' SN:' + entry["SerialNo"];
            }
            // if (entry["EqSourceType"] == "3") {
            //     strEquipment = entry["Model"] + ' SN:' + entry["SerialNo"];
            // }
            let newName = {
                Id: intInc.toString(),
                Equipment: strEquipment,
                EqSourceType: entry["EqSourceType"].toString(),
                SerialNo: entry["SerialNo"].toString(),
                Model: entry["Model"].toString(),
                UserName: entry["UserName"].toString(),
                Quantity: entry["Quantity"]
            };
            if (entry["EqSourceType"] == "1" || entry["EqSourceType"] == "2") {
                this.eqSelectedPreviewList.push(newName);
            }
        }
    }

    generatePOCBomSheetReport(): void {
        //debugger;

        var Equipid = $("#selectEquipment").val();
        if (Equipid != 'Select equipment') {
            this.reportService.setDownloadInProgress(true);
            for (let entry of this.eqSelectedPreviewList.filter(s => s.Id == Equipid)) {
                let strModel: string = "";
                let strSerialNo: string = "";

                if (entry["EqSourceType"] == "1") {
                    strSerialNo = entry["SerialNo"];
                };
                if (entry["EqSourceType"] == "2") {
                    strModel = entry["Model"];
                }
                if (entry["EqSourceType"] == "3") {
                    strModel = entry["Model"];
                }

                let newSalectedEQ = [{
                    SerialNo: strSerialNo,
                    Model: strModel,
                    EqSourceType: entry["EqSourceType"].toString(),
                    UserName: entry["UserName"].toString(),
                    Quantity: "",
                    HourFrom: "",
                    HourTo: "",
                    MODELCATEGORY: "",
                    EQ_LIFE: "",
                    HR_TYPE: "",
                    quant: entry["Quantity"],
                    serNo: entry["SerialNo"],
                    mod: entry["Model"],
                    id: entry["Model"] + ' SN:' + entry["SerialNo"]
                }];
                let objEqSelected: EqSelectedList = JSON.parse(JSON.stringify(newSalectedEQ));

                this.reportService.pocBOMSheetInExcelFormat(objEqSelected).subscribe(
                    value => {
                        PNotify.removeAll();
                        this.reportService.setDownloadInProgress(false);
                    },
                    err => {
                        console.log(err);
                        PNotify.removeAll();
                        alert("Error while processing your request");
                    }
                );

                PNotify.prototype.options.styling = "fontawesome";
                PNotify.prototype.options.stack.firstpos2 = 250;
                // UI Changes (Changed width to 500 from 300
                new PNotify({
                    text: 'Generating Report',
                    delay: 3000000,
                    width: 500
                });
                $(".ui-pnotify-text").append("<span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span>");
            }
        } else {
            alert("Please select any equipment to generate POC BOM Sheet");
        }
    }

    validateReportGeneration(): boolean {

        let disableReport: boolean = false;
        if (this.reportService.getDownloadInProgress()) {
            disableReport = true;
        } else {
            if (parseInt(this.selectEquipmentMasterService.getSelectedEquipment()) > 0) {
                disableReport = this.disableReportschange;
            } else {
                disableReport = true;
            }
        }
        
        //var IsHrsValue = this.dataService.getReportsValue('IsengineHrsValue');
        //if (this.dataService.getReportsValue('IsengineHrsValue') == false) {
        //    disableReport = true;
        //}
        return disableReport;
    }

}
