import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportsPocBomSheetComponent } from './reports-poc-bom-sheet.component';

describe('ReportsPocBomSheetComponent', () => {
  let component: ReportsPocBomSheetComponent;
  let fixture: ComponentFixture<ReportsPocBomSheetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportsPocBomSheetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportsPocBomSheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
