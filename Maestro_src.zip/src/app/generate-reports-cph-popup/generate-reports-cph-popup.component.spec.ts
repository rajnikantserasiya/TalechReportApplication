import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateReportsCphPopupComponent } from './generate-reports-cph-popup.component';

describe('GenerateReportsCphPopupComponent', () => {
  let component: GenerateReportsCphPopupComponent;
  let fixture: ComponentFixture<GenerateReportsCphPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenerateReportsCphPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerateReportsCphPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
