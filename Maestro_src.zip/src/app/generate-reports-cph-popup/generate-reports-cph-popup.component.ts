import {Component, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable } from '@angular/core';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import {ReportService} from '../services/report.service';
import {SaveService} from '../services/save.service';
import { SelectEquipmentMasterService } from './../services/select-equipment-master.service';
import { CommonService } from '../services/common.service';
declare var jquery: any;
declare var $: any;
declare var PNotify: any;

@Component({
    selector: 'app-generate-reports-cph-popup',
    templateUrl: './generate-reports-cph-popup.component.html',
    styleUrls: ['./generate-reports-cph-popup.component.css']
})
export class GenerateReportsCphPopupComponent  {

    PriceListPriceType = "";

    constructor(private reportService: ReportService, public activeModal: NgbActiveModal, public changeRef: ChangeDetectorRef, private selectEquipmentMasterService: SelectEquipmentMasterService, private commonService: CommonService
        , public saveService: SaveService) {
        this.commonService.generateReportObservable$.subscribe((data) => {
            if (data === "partscom_cph") {
                this.onReportsCPHOkClicked();
            }
        },
        (error) => {
            console.log('error');
        },
        () => {
            console.log('observable to generate report completed');
        }
    )
    }

    ngOnInit() {
        this.PriceListPriceType = this.commonService.setPriceTypePriceListLabel();        
    }

    onReportsCPHOkClicked(): void {
        this.reportService.setDownloadInProgress(true);
        if (localStorage.getItem("ReportOption") == "XLS Spreadsheet") {
            this.reportService.generatePartConsumptionCalendarInExcelFormatCPH().subscribe(
                value => {
                    PNotify.removeAll();
                },
                err => {
                    console.log(err);
                    this.reportService.setDownloadInProgress(false);
                },
                () => {
                    this.reportService.setDownloadInProgress(false);
                }
            );
        }               
        PNotify.prototype.options.styling = "fontawesome";
        PNotify.prototype.options.stack.firstpos2 = 250;
        // UI Changes (Changed width to 500 from 300
        new PNotify({
            text: 'Generating Report',
            delay: 3000000,
            width: 500
        });
        $(".ui-pnotify-text").append("<span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span>");
    }

    showReportPopUp() {
        var popUpRef : HTMLElement ;        
        popUpRef = document.getElementById('reportPopUp');
        if(popUpRef) {
            this.activeModal.dismiss(true);
            this.commonService.setReportType('partscom_cph');
            this.saveService.reportDurationService()
                .then(item => {
                    var item = item[0];
                    if (item['HourFrom'] != "" && item['HourFrom'] != null) {
                        this.commonService.setReportInterval(item["HourFrom"], 'from');
                    }
                    if (item['HourTo'] != "" && item['HourTo'] != null) {
                        this.commonService.setReportInterval(item['HourTo'], 'to');
                    }
                    popUpRef.click();
                })
                .catch(error => console.log(error));
        }
    }
}

@Injectable() export class GenerateCostReportsCPHService {

    constructor(private modalService: NgbModal) { }

    public show() {
        const modalRef = this.modalService.open(GenerateReportsCphPopupComponent);
        modalRef.componentInstance.name = "showreportsdlg1";
        modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }
}