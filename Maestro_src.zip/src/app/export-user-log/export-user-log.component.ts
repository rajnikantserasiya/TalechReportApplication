import {Component, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable } from '@angular/core';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import {CalendarModule} from 'primeng/calendar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {ReportService} from '../services/report.service';
declare var PNotify: any;
declare var moment: any;
declare var $: any;

@Component({
    selector: 'app-export-user-log',
    templateUrl: './export-user-log.component.html',
    styleUrls: ['./export-user-log.component.css']
})
export class ExportUserLogComponent implements OnInit {
    USER: 'Select User Name';
    // UI Changes
    public frmdate: Date = new Date(new Date().getFullYear(), 0, 1);
    public todate: Date = new Date();

    constructor(public activeModal: NgbActiveModal, private reportService: ReportService, public changeRef: ChangeDetectorRef) { }

    ngOnInit() {
        this.todate = moment(this.todate).format("MM.DD.YYYY");
        // UI Changes
        this.frmdate = moment(this.frmdate).format("MM.DD.YYYY");
    }

    exportUserLog(frmdate, todate): void {
        
        document.getElementById("slide-nav").style.width = "0";
        frmdate = moment(frmdate).format("YYYY-MM-DD");
        todate = moment(todate).format("YYYY-MM-DD");

        PNotify.prototype.options.styling = "fontawesome";
        PNotify.prototype.options.stack.firstpos2 = 250;
        // UI Changes (Changed width to 500 from 300
        new PNotify({
            text: 'Exporting User Logs',
            delay: 3000000,
            width: 500
        });
        $(".ui-pnotify-text").append("<span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span>");

        this.reportService.exportUserLog(frmdate, todate).subscribe(
            value => {
                this.activeModal.dismiss(true);

                PNotify.removeAll();
                // UI Changes (Changed width to 500 from 300
                new PNotify({
                    text: 'Exported User Logs Successfully',
                    delay: 1000,
                    width: 500,
                    type: 'success'
                });
            },
            err => {
                console.log(err);
                this.reportService.setDownloadInProgress(false);
            },
            () => {
                this.reportService.setDownloadInProgress(false);
            }
        );
    }
}

@Injectable() export class ExportUserLogDialogService {

    constructor(private modalService: NgbModal) { }

    public show() {
        const modalRef = this.modalService.open(ExportUserLogComponent);
        modalRef.componentInstance.name = "showexportdlg";
        modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }
}
