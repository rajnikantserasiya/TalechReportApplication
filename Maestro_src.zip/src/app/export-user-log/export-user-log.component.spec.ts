import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExportUserLogComponent } from './export-user-log.component';

describe('ExportUserLogComponent', () => {
  let component: ExportUserLogComponent;
  let fixture: ComponentFixture<ExportUserLogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExportUserLogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExportUserLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
