import { Component, OnInit, ElementRef } from '@angular/core';
import { NgIf } from '@angular/common';
import { Router } from '@angular/router';
import { LoginDialogService } from '../login-popup/login-popup.component';
import { LogoutService } from '../services/logout.service';
import {DialogModule} from 'primeng/dialog';
import { CommonService } from '../services/common.service';
import { CommonUtil }  from './../common/common-util';
import { ReportService } from '../services/report.service';
import { SelectedEquipmentModelService} from '../html-report-selected-equipment-model/html-report-selected-equipment-model.component';

//Azure AD Changes
import { AuthService } from "../interceptor/auth.service";
import {Http, Response, Headers, RequestMethod, RequestOptions} from "@angular/http";
//Azure AD Changes

declare var jquery: any;
declare var $: any;
declare var PNotify: any;


@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css'],
    providers: [LoginDialogService]
})
export class HeaderComponent {
    public tokenValue: any = "123";
    display: boolean = false;
    reportDurationHrFrom: string = "200";
    reportDurationHrTo: string = "500";

    reportDurationHrType: string = "Engine Hours";

    reportType: string = "";
    max: Number = 7;
    constructor(private reportService: ReportService, private eRef: ElementRef, private commonUtil: CommonUtil, private loginDlgService: LoginDialogService,
        private logoutService: LogoutService, private maestroRouter: Router, public commonService: CommonService, private selectedEquipmentModelService: SelectedEquipmentModelService,
        //Azure AD Changes
        private authService: AuthService, private _http: Http) { }

    ngOnInit() {

        //Azure AD Changes
        if (this.commonService.getAzureADAuthenticationEnableFlagValue()) {
            this.loginTextDisplay_AzureADLogin();
        }
    }


    loginTextDisplay(): void {
        //debugger;             
        var loginTxt = (<HTMLInputElement>document.getElementById("login-btn"));
        var welcomeUsrTxt = (<HTMLInputElement>document.getElementById("welcomeUsr"));
        var slideOutDiv = (<HTMLInputElement>document.getElementById("slide-nav"));
        var openslideBtn = (<HTMLInputElement>document.getElementById("openslideBtn"));
        var adminSlide = (<HTMLInputElement>document.getElementById("adminSlideId"));
        var beforeLoginTxt = (<HTMLInputElement>document.getElementById("beforeLogin"));
        var tokenValue = localStorage.getItem("token");
        var userRoleValue = localStorage.getItem("userRole");
        if (tokenValue === "" || tokenValue === null) {
            loginTxt.value = "LogIn"
            loginTxt.innerText = "LOG IN";
            welcomeUsrTxt.hidden = true;
            if (beforeLoginTxt) {
                beforeLoginTxt.style.display = 'block';
            }
        }
        else {
            loginTxt.value = "LogOut"
            loginTxt.innerText = "LOG OUT";
            slideOutDiv.style.display = 'block';
            openslideBtn.style.display = 'block';
            welcomeUsrTxt.childNodes[1].textContent = localStorage.getItem("userId");
            welcomeUsrTxt.hidden = false;
            if (userRoleValue === "Admin") {
                adminSlide.style.display = 'block';
            } else {
                adminSlide.style.display = 'none';
            }
        }

        if (localStorage.getItem("ReportHrsType") == "ENG") {
            this.reportDurationHrType = "Engine Hours";
        }
        if (localStorage.getItem("ReportHrsType") == "PERC") {
            this.reportDurationHrType = "Percussion Hours";
        }
        if (localStorage.getItem("ReportHrsType") == "COMP") {
            this.reportDurationHrType = "Compressor Hours";
        }
        if (localStorage.getItem("ReportHrsType") == "PPACK") {
            this.reportDurationHrType = "Powerpack Hourss";
        }
        if (localStorage.getItem("ReportHrsType") == "GRBX") {
            this.reportDurationHrType = "Hydraulic Hours";
        }

        this.reportDurationHrFrom = this.commonService.getReportInterval('from');
        this.reportDurationHrTo = this.commonService.getReportInterval('to');
    }

    openLogin(): void {
        var loginTxt = (<HTMLInputElement>document.getElementById("login-btn"));
        if (loginTxt.value === "LogIn") {
            this.loginDlgService.show();
        } else if (loginTxt.value === "LogOut") {
            this.logoutService.logoutUser(localStorage.getItem("token")).then(result => result)
                .catch(error => console.log(error));

            localStorage.setItem("token", "");
            localStorage.setItem("PriceListType", "");
            localStorage.setItem("PriceList", "");

            this.maestroRouter.navigateByUrl('main');

            var beforeLoginTxt = (<HTMLInputElement>document.getElementById("beforeLogin"));

            if (beforeLoginTxt != null) {
                beforeLoginTxt.style.display = 'block';
            }

            loginTxt.innerText = "LOG IN";
            loginTxt.value = "LogIn"

            var welcomeUsrTxt = (<HTMLInputElement>document.getElementById("welcomeUsr"));
            welcomeUsrTxt.hidden = true;

            var slideOutDiv = (<HTMLInputElement>document.getElementById("slide-nav"));
            slideOutDiv.style.display = 'none';

            var openslideBtn = (<HTMLInputElement>document.getElementById("openslideBtn"));
            openslideBtn.style.display = 'none';
        } else {
            this.loginDlgService.show();
        }
    }

    generateReport() {
        //save from and to interval in a common service and invoke the specific report generation handler        
        if (this.commonService.getReportType()) {
            this.generateReportFromApi();
            //this.commonService.generateReportHandler(this.commonService.getReportType());           
        } else {
            console.log('invalid type');
        }
        this.display = false;
    }

    generateReportFromApi(): void {

        var reportType = this.commonService.getReportType() || '';
        // var closeLoginBtn = document.getElementById("generate-cost-reports-popupCancelBtn");
        this.reportService.setDownloadInProgress(true);

        if (reportType === "cost_forecast") {
            if (localStorage.getItem("ReportOption") == "XLS Spreadsheet") {
                this.LoaderMethod();
                this.reportService.costForecastInExcelFormat().subscribe(
                    value => {
                        PNotify.removeAll();
                    },
                    err => {
                        console.log(err);
                        this.reportService.setDownloadInProgress(false);
                    },
                    () => {
                        this.reportService.setDownloadInProgress(false);
                    }
                );
            }
            else if (localStorage.getItem("ReportOption") == 'HTML report') {

                this.reportService.setDownloadInProgress(false);
                this.selectedEquipmentModelService.show();
            }

        } else if (reportType === "partscom_cph") {
            if (localStorage.getItem("ReportOption") == "XLS Spreadsheet") {

                this.LoaderMethod();
                this.reportService.generatePartConsumptionCalendarInExcelFormatCPH().subscribe(
                    value => {
                        PNotify.removeAll();
                    },
                    err => {
                        console.log(err);
                        this.reportService.setDownloadInProgress(false);
                    },
                    () => {
                        this.reportService.setDownloadInProgress(false);
                    }
                );
            }
            else if (localStorage.getItem("ReportOption") == 'HTML report') {

                this.reportService.setDownloadInProgress(false);
                this.selectedEquipmentModelService.show();
            }
        } else if (reportType === "partscom_xls") {

            if (localStorage.getItem("ReportOption") == "XLS Spreadsheet") {

                this.LoaderMethod();
                this.reportService.generatePartConsumptionCalendarInExcelFormat().subscribe(
                    value => {
                        PNotify.removeAll();
                    },
                    err => {
                        console.log(err);
                        this.reportService.setDownloadInProgress(false);
                    },
                    () => {
                        this.reportService.setDownloadInProgress(false);
                    }
                );
            }
            else if (localStorage.getItem("ReportOption") == 'HTML report') {

                this.reportService.setDownloadInProgress(false);
                this.selectedEquipmentModelService.show();
            }
        }



    }

    LoaderMethod() {
        PNotify.prototype.options.styling = "fontawesome";
        PNotify.prototype.options.stack.firstpos2 = 250;
        // UI Changes (Changed width to 500 from 300
        new PNotify({
            text: 'Generating Report',
            delay: 3000000,
            width: 500
        });
        $(".ui-pnotify-text").append("<span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span><span class='loader__dot'>.</span>");

    }

    onModelChange(value, field) {
        var ngNativeEl: HTMLInputElement;
        if (value) {
            var temp = value.toString() || "";
            switch (field) {
                case 'HourFrom':
                    ngNativeEl = this.eRef.nativeElement.querySelector('#' + 'reports_hr_from');
                    if (this.commonUtil.checkSpecialRegex(temp, false, false) || temp.length > this.max) {
                        if (ngNativeEl) {
                            ngNativeEl.value = this.reportDurationHrFrom;
                        }
                    } else {
                        this.reportDurationHrFrom = value;
                    }
                    break;

                case 'HourTo':
                    ngNativeEl = this.eRef.nativeElement.querySelector('#' + 'reports_hr_to');
                    if (this.commonUtil.checkSpecialRegex(temp, false, false) || temp.toString().length > this.max) {
                        if (ngNativeEl) {
                            ngNativeEl.value = this.reportDurationHrTo;
                        }
                    } else {
                        this.reportDurationHrTo = value;
                    }
                    break;

                default: break;
            }
        }
        this.commonService.setReportInterval(this.reportDurationHrFrom, 'from');
        this.commonService.setReportInterval(this.reportDurationHrTo, 'to');
    }

    validateReport() {
        return +this.reportDurationHrFrom > +this.reportDurationHrTo;
    }

    onShow(evt) {
        this.reportDurationHrTo = this.commonService.getReportInterval('to');
        this.reportDurationHrFrom = this.commonService.getReportInterval('from');
        var ngNativeElFrom = this.eRef.nativeElement.querySelector('#' + 'reports_hr_from');
        var ngNativeElTo = this.eRef.nativeElement.querySelector('#' + 'reports_hr_to');
        ngNativeElFrom.value = this.reportDurationHrFrom;
        ngNativeElTo.value = this.reportDurationHrTo;
    }

    //Azure AD Changes
    loginTextDisplay_AzureADLogin(): void {
        //debugger;
        //var loginTxt = (<HTMLInputElement>document.getElementById("login-btn"));
        var welcomeUsrTxt = (<HTMLInputElement>document.getElementById("welcomeUsr"));
        var slideOutDiv = (<HTMLInputElement>document.getElementById("slide-nav"));
        var openslideBtn = (<HTMLInputElement>document.getElementById("openslideBtn"));
        var adminSlide = (<HTMLInputElement>document.getElementById("adminSlideId"));
        var beforeLoginTxt = (<HTMLInputElement>document.getElementById("beforeLogin"));
        var tokenValue = this.authService.getAuthToken();
        var userRoleValue = localStorage.getItem("userRole");

        //loginTxt.value = "LogOut"
        //loginTxt.innerText = "LOG OUT";
        slideOutDiv.style.display = 'block';
        openslideBtn.style.display = 'block';
        welcomeUsrTxt.childNodes[1].textContent = localStorage.getItem("userId");
        welcomeUsrTxt.hidden = false;
        if (userRoleValue === "Admin") {
            adminSlide.style.display = 'block';
        } else {
            adminSlide.style.display = 'none';
        }

        //For Azure AD Authentication
        //loginTxt.style.display = 'none';

        if (localStorage.getItem("ReportHrsType") == "ENG") {
            this.reportDurationHrType = "Engine Hours";
        }
        if (localStorage.getItem("ReportHrsType") == "PERC") {
            this.reportDurationHrType = "Percussion Hours";
        }
        if (localStorage.getItem("ReportHrsType") == "COMP") {
            this.reportDurationHrType = "Compressor Hours";
        }
        if (localStorage.getItem("ReportHrsType") == "PPACK") {
            this.reportDurationHrType = "Powerpack Hourss";
        }
        if (localStorage.getItem("ReportHrsType") == "GRBX") {
            this.reportDurationHrType = "Hydraulic Hours";
        }

        this.reportDurationHrFrom = this.commonService.getReportInterval('from');
        this.reportDurationHrTo = this.commonService.getReportInterval('to');
    }

    //Azure AD Changes
    LogOut(): void {
        this.logoutService.logoutUserFromAzureAD();
    }
}
