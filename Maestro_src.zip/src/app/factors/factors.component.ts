import { Component, OnInit ,ElementRef } from '@angular/core';
import { SelectItem } from 'primeng/primeng';
import {EqExclusionsServiceService} from '../services/eq-exclusions-service.service';
import {EqFactorsList} from '../services/eq-exclusions-class';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { AppConstant } from './../app.constant';
import { DataService } from './../services/data-component.service';
import { CommonUtil }  from './../common/common-util';

@Component({
  selector: 'app-factors',
  templateUrl: './factors.component.html',
  styleUrls: ['./factors.component.css'],  
  providers: [ EqExclusionsServiceService ]
})
export class FactorsComponent implements OnInit {

    infotextTitle = "For each equipment in your current session, please provide the relevant anticipated meter hours per year.";
    eqHeadText = "Equipment";
    modHeadText = "Model";
    mcatHeadText = "Model Category";
    mcatMeterTypeText = "Meter Type";  
    aehrsHeadText = "Annual Engine Hours";
    aphrsHeadText = "Annual Percussion Hours";
    alhpphrsHeadText = "Annual LH Powerpack Hours";
    achrsHeadText = "Annual Compressor Hours";
    agbxhrsHeadText = "Annual Hydraulic Hours";
    max: Number = 7;
    equipfactors: EqFactorsList[];

    constructor(private eRef : ElementRef , private eqExclusionsServiceService: EqExclusionsServiceService, private fetchCurrentDataService: FetchCurrentDataService, private appConstant: AppConstant , private dataService : DataService , private commonUtil : CommonUtil) {
        this.fetchCurrentDataService.screenDataStream$.subscribe(
        () => {
            if (!this.fetchCurrentDataService.disableFlagSaveFactor) {
                var factorData : any = []; 
                this.fetchCurrentDataService.disableFlagSaveFactor = true;               
                if( this.dataService.getData(this.appConstant.factorsRoot).length > 0){
                    factorData = this.dataService.getData(this.appConstant.factorsRoot);
                   }
                if (factorData && factorData.length > 0) {
                    this.fetchCurrentDataService.createJsonToSave(factorData, this.appConstant.factorsRoot);                    
                }                                                                    
            }
        });

        this.fetchCurrentDataService.refreshScreenStream$.subscribe(
            () => {              
            if(!this.fetchCurrentDataService.reloadFlagFactors) {
              this.fetchCurrentDataService.reloadFlagFactors = true;      
              this.equipfactors = [];        
              this.ngOnInit();       
            }
          });  
    }
    
    public restrictNumeric(e) {       
        if (!this.commonUtil.checkSpecialRegex(e.target.value , false , false) || e.target.value.length >= this.max) {
            e.preventDefault();
        }       
    }

    onModelChange(value , data , field , key) {
        try {            
            var id : string  ="";
            if( data['SerialNo']  &&  data['SerialNo'].toLowerCase() === "n/a"){
                id = field+(data['Model']);
            } else if( data['Model']  && data['Model'].toLowerCase() === "n/a") {
                id = field+(data['SerialNo']);
            } else {
                id = field+(data['SerialNo']);
            }               
            id = id.replace(/\s/g, ""); 
            var ngNativeEl =  this.eRef.nativeElement.querySelector('#'+id);
        } catch (e){
            console.log(e);
        }

        if (this.commonUtil.checkSpecialRegex(value , false , false) || value.length >= this.max) {
           value = data[field];
           ngNativeEl.value = data[field]; 
        } else {
           data[field] = value;
           this.dataService.setTabModified('tab-factors', true);
        }         
    }

    ngOnInit() {
        this.dataService.setSkipTabChange(false , 'all') ;         
        document.getElementById("slide-nav").style.width = "0";        
        this.getEqFactors();
    }

    onOkUpdateFactorClicked(equipfactors , tabReload): any {
        this.dataService.setTabModified('tab-factors', false);
        this.eqExclusionsServiceService.saveMaestroFactoreData(equipfactors).then(
            result => {    
                this.dataService.setSkipTabChange(false , 'all');          
                if(tabReload){
                    this.dataService.clearReferenceForList(false);        
                    document.getElementById('reload_tab').click();
                }            
            })
            .catch(error => console.log(error));
    }

    disablePerComponent(equip): boolean {
        return equip['PERCUSSION'] == "N/A";       
    }

    disableEngComponent(equip): boolean {
        return equip['ENGINE'] == "N/A";           
    }

    disableTransComponent(equip): boolean {
        return equip['POWERPACK'] == "N/A";                   
    }

    disableCompComponent(equip): boolean {
        return equip['COMPRESSOR'] == "N/A";                           
    }

    disableHydrComponent(equip): boolean {
        return equip['GearBox'] == "N/A";                                   
    }

  getEqFactors(): void {
   if( this.dataService.getData(this.appConstant.factorsRoot).length > 0){
    this.equipfactors = this.dataService.getData(this.appConstant.factorsRoot);
   } else {
    this.eqExclusionsServiceService.selectedEquipmentFoctorsMaster()
        .then(result => {

            result.forEach(item => {
                if (item['ENGINE'] == "N/A" && item['ENG']==true)
                    item["ENGINE"] = "0"

                if (item['PERCUSSION'] == "N/A" && item['PERC'] == true)
                    item["PERCUSSION"] = "0"

                if (item['COMPRESSOR'] == "N/A" && item['COMPR'] == true)
                    item["COMPRESSOR"] = "0"

                if (item['POWERPACK'] == "N/A" && item['PPACK'] == true)
                    item["POWERPACK"] = "0"

                if (item['GearBox'] == "N/A" && item['HYDR'] == true)
                    item["GearBox"] = "0"
                }  
                );

        this.equipfactors=result;
        var filterdata =  this.dataService.getData(this.appConstant.factorsRoot);
        if(filterdata.length == 0 ){
         this.dataService.setData(this.appConstant.factorsRoot , this.equipfactors , true);
        }      
     })
     .catch(error => console.log(error));
   }
  }

  setDynamicId( field, data) {
    var id : string  ="";
    if(data['SerialNo']  &&  data['SerialNo'].toLowerCase() === "n/a"){
        id = field+(data['Model']);
    }else if(data['Model']  &&  data['Model'].toLowerCase() === "n/a") {
        id = field+(data['SerialNo']);
    } else {
        id = field+(data['SerialNo']);
    }   

    id = id.replace(/\s/g, ""); 
    //id = id.trim();
    return id;
  }

  saveFactorsData(str) { 
    var factorData : any = [];              
    if(this.dataService.getData(this.appConstant.factorsRoot).length > 0) {
        factorData = this.dataService.getData(this.appConstant.factorsRoot);
    }
    if(factorData && factorData.length > 0) {    
        if(str === "manual"){
            // set it to true in case for reload and cache clear
            this.onOkUpdateFactorClicked(factorData , true);
        } else {
            this.onOkUpdateFactorClicked(factorData , false);    
        }    
    }    
  }

  resetFactorsData() {    
    this.dataService.setData(this.appConstant.factorsRoot , [] , true);
    this.getEqFactors();
  }

  validateSave() {
    return !this.dataService.getTabModified('tab-factors');
  }
}
