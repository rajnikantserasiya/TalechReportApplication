import {Component, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable } from '@angular/core';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import * as XLSX from 'xlsx';
import { DataService } from './../services/data-component.service';
import {AdminImportBomService}  from '../services/admin-import-bom.service';
import {LoadImportFleetModalService} from '../admin-import-fleet-popup/admin-import-fleet-popup.component';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { AppConstant } from './../app.constant';
declare var PNotify: any;

@Component({
  selector: 'app-update-boms-popup',
  templateUrl: './update-boms-popup.component.html',
  styleUrls: ['./update-boms-popup.component.css']
})
export class UpdateBomsPopupComponent {
    data: any;
    columns: any = [];
    modifiedDataSet_admin: any = [];
    mappedJson_admin: any = [];
    modelCategory: string = "";
    formModel: any = { 'modelCategory': 'select', 'model': 'select', 'serialNumber': 'select', 'level': 'select', 'parentId': 'select', 'parentDescription': 'select', 'item': 'select', 'itemDescription': 'select', 'quantity': 'select', 'lifeHours': 'select' };
    displayData: boolean = false;
    fileName: "";
    displayFileName: boolean = false;
    pagingConfig = { "startIndex": 1, "endIndex": 5, "itemsPerPage": 10, "action": "refresh" };
    totalCount: number = 0;
    mappedJsonOriginal_admin: any = [];
    viewData_admin: any = [];

    constructor(public activeModal: NgbActiveModal, public changeRef: ChangeDetectorRef, private dataService: DataService,
        private loadImportFleetModalService: LoadImportFleetModalService, private appConstant: AppConstant, public adminImportBomService: AdminImportBomService) {

        this.loadImportFleetModalService.onOkClickStream$.subscribe(
            (data) => {
                if (data) {                    
                    this.formModel = data;
                    this.onOkClick();
                }
            });
    }

    //openBomDialog(): void {               
    //    var closeUpdateBomBtn = document.getElementById("closeUpdateBomBtn");
    //    closeUpdateBomBtn.click();  
    //    setTimeout( () => {
    //        var fileLoaderButton = document.getElementById("update_Bom");
    //        fileLoaderButton.click();
    //    }, 1000);        
    //}

    onFileChange(evt: any) {
        //debugger;
        /* wire up file reader */
        const target: DataTransfer = <DataTransfer>(evt.target);
        var fileName = "";
        if (evt.target.files[0]["name"]) {
            this.fileName = evt.target.files[0]["name"];
            fileName = this.fileName;
            this.dataService.setAdminImportedBomFileName(this.fileName);
        }
        if (fileName.indexOf('xls') > 0 || fileName.indexOf('xlsx') > 0) {
            if (target.files.length !== 1) throw new Error('Cannot use multiple files');
            const reader: FileReader = new FileReader();
            reader.onload = (e: any) => {
                /* read workbook */
                const bstr: string = e.target.result;
                const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

                /* grab first sheet -  considering single sheet scenario currently*/
                const wsname: string = wb.SheetNames[0];
                const ws: XLSX.WorkSheet = wb.Sheets[wsname];

                /* save data */
                this.data = (XLSX.utils.sheet_to_json(ws, { header: 1 }));
                this.updateAdminImportData();
            };
            reader.readAsBinaryString(target.files[0]);
        } else {
            alert('Please Select valid file format');
        }
    }

    updateAdminImportData() {

        //debugger;
        this.clearPreviousData();
        this.loadImportFleetModalService.setColumns([]);
        var obj = [];
        var intervalStartIndex = -1;
        var json = [];
        var array = [];

        this.data[0].forEach(item => {
            if (isNaN(item)) {
                this.columns.push(item);
                obj.push({ "filterName": item, "filterValue": [] });
            }
        });
        intervalStartIndex = obj.length;
        for (var i = 1; i < this.data.length; i++) {
            var tempArray = this.data[i];
            var objTemp = {};
            for (var j = 0; j < intervalStartIndex; j++) {
                objTemp[obj[j]["filterName"]] = tempArray[j];
            }
            json.push(objTemp);
        }
        array = this.columns;
        this.columns = array.filter(function (item, pos) {
            return array.indexOf(item) == pos;
        })
        this.modifiedDataSet_admin = json;
        this.loadImportFleetModalService.setColumns(this.columns);
        this.loadImportFleetModalService.show();
    }

    clearPreviousData() {
        this.viewData_admin = [];
        this.mappedJson_admin = [];
        this.mappedJsonOriginal_admin = [];
        //this.dataService.setData('importBomPreview', [], true);
        //this.dataService.setAdminViewBomModel([]);
    }

    onOkClick() {
        //debugger;
        var obj = [];
        obj = this.modifiedDataSet_admin.map(item => <any>{
            'UserName': localStorage.getItem("UserName"),
            'IsInclude': true,
            'modelCategory': this.formModel['modelCategory'],
            'model': this.formModel['model'],
            'serialNumber': item[this.formModel['serialNumber']],
            //'level': item[this.formModel['level']],
            'parentId': item[this.formModel['parentId']],
            'parentDescription': item[this.formModel['parentDescription']],
            'item': item[this.formModel['item']],
            'itemDescription': item[this.formModel['itemDescription']],
            'quantity': item[this.formModel['quantity']],
            //'lifeHours': item[this.formModel['lifeHours']]
        });
        this.mappedJson_admin = obj;
        this.mappedJsonOriginal_admin = JSON.parse(JSON.stringify(obj));
        //this.dataService.setData('adminimportBomPreview', obj, true);
        this.loadImportFleetModalService.setColumns(this.columns);
        this.displayFileName = true;
        this.totalCount = obj.length;
        //if (this.mappedJson_admin.length > 0) {
        //    this.viewData_admin.push(this.mappedJson_admin[0]);
        //    this.viewData_admin.forEach(item => {
        //        item['checked'] = false;
        //    });
        //}
        //this.dataService.setAdminViewBomModel(this.viewData_admin);
        this.saveData();
    }

    saveData() {
        //debugger;
        //this.saveSuccessHandler("Saving Data..", "success");
        PNotify.removeAll();
        PNotify.prototype.options.styling = "fontawesome";
        PNotify.prototype.options.stack.firstpos2 = 250;
        // UI Changes (Changed width to 500 from 300
        new PNotify({
            text: 'Saving Data',
            delay: 3000,
            width: 500
        });
        //var popUpModelData = this.dataService.getImportedBomModel();
        if (this.mappedJson_admin.length > 0) {
            this.adminImportBomService.saveAdminImportedBOM(this.mappedJson_admin, this.formModel)
                .then(result => {
                    if (result == "False") {
                        this.saveSuccessHandler("Error while saving data into database", "error");
                    }
                    else {
                        //this.dataService.clearReferenceForList(true);
                        //this.dataService.setImportedBomModel([]);                        
                        this.saveSuccessHandler("Data Saved Successfully", "success");
                        setTimeout(item => {
                            this.CancelClick();
                        }, 1000)
                        
                    }


                })
                .catch(error => console.log(error));
        }
    }

    saveSuccessHandler(msg, messageType) {
        PNotify.removeAll();
        PNotify.prototype.options.styling = "fontawesome";
        PNotify.prototype.options.stack.firstpos2 = 250;

        new PNotify({
            //text: 'Data Saved Successfully',
            text: msg,
            delay: 3000,
            width: 500,
            //type: 'success'
            type: messageType
        });
    }

    CancelClick() {
        PNotify.removeAll();
        this.clearPreviousData();
        this.activeModal.dismiss(true);
    }
}

@Injectable() export class UpdateBomsDialogService {

constructor(private modalService: NgbModal) { }

public show() {
    const modalRef = this.modalService.open(UpdateBomsPopupComponent);
    modalRef.componentInstance.name = "showupdatedlg";
    modalRef.componentInstance.changeRef.markForCheck();
    return modalRef.result;
}
}
