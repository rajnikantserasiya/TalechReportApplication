import { Component, OnInit, ElementRef } from '@angular/core';
import { AppConstant } from './../app.constant';
import {DialogModule} from 'primeng/dialog';
import { GenerateCostReportsService } from '../generate-cost-forecast-reports-popup/generate-cost-forecast-reports-popup.component';
import { GenerateReportsService } from '../generate-reports-popup/generate-reports-popup.component';
import { GenerateCostReportsCPHService } from '../generate-reports-cph-popup/generate-reports-cph-popup.component';
import {ReportService} from '../services/report.service';
import { SelectEquipmentMasterService } from './../services/select-equipment-master.service';
import { DataService } from './../services/data-component.service';
import { CommonService } from '../services/common.service';
import { SelectedEquipmentModelService} from '../html-report-selected-equipment-model/html-report-selected-equipment-model.component';

@Component({
    selector: 'app-report-maintenance-part-schedule',
    templateUrl: './report-maintenance-part-schedule.component.html',
    styleUrls: ['./report-maintenance-part-schedule.component.css'],
    providers: [GenerateReportsService, GenerateCostReportsService, GenerateCostReportsCPHService, SelectedEquipmentModelService]
})
export class ReportMaintenancePartScheduleComponent implements OnInit {

    rbnInterestValue = '';
    rbnReportFormat = '';
    chkCostPerStrategy: boolean = false;
    chkExecutiveSummary: boolean = false;
    chkIntervalSummary: boolean = false;
    chkBOMDetails: boolean = false;
    display: boolean = false;
    errorMessage = '';
    btnReportGenerationDisabled: boolean = false;
    disableReportschange: boolean = false;

    constructor(private generatereportsservice: GenerateReportsService, private generateCostReportsCPHService: GenerateCostReportsCPHService,
        private generateCostReportsService: GenerateCostReportsService, private reportService: ReportService
        , private selectEquipmentMasterService: SelectEquipmentMasterService, private dataService: DataService,
        private commonService: CommonService, private selectedEquipmentModelService: SelectedEquipmentModelService) { }

    ngOnInit() {
        this.rbnInterestValue = 'volumeQty';
        this.rbnReportFormat = 'excel';
        localStorage.setItem("ReportOption", "XLS Spreadsheet");
        //this.chkExecutiveSummary = true;
    }

    onInterestChecked(value) {
        if (value == 'volumeQty') {
            this.rbnInterestValue = 'volumeQty';
            this.chkIntervalSummary = false;
            this.chkCostPerStrategy = false;
        }
        else if (value == 'Cost') {
            this.rbnInterestValue = 'Cost'
        }
    }

    onReportFormatChecked(value) {
        if (value == 'html') {
            this.rbnReportFormat = 'html';
            localStorage.setItem("ReportOption", "HTML report");
        }
        else if (value == 'excel') {
            this.rbnReportFormat = 'excel';
            localStorage.setItem("ReportOption", "XLS Spreadsheet");
        }
    }

    ExecutiveSummaryCheckBoxChanged(value) {
        this.chkExecutiveSummary = !this.chkExecutiveSummary;
    }

    IntervalSummaryCheckBoxChanged(value) {
        this.chkIntervalSummary = !this.chkIntervalSummary;
    }

    BOMDetailsCheckBoxChanged(value) {
        this.chkBOMDetails = !this.chkBOMDetails;
    }

    CostPerStrategyCheckBoxChanged(value) {
        this.chkCostPerStrategy = !this.chkCostPerStrategy;
        if (this.chkCostPerStrategy) {
            this.chkIntervalSummary = true;
        }
        else {
            this.chkIntervalSummary = false;
        }
    }

    GenerateReport() {

        if (this.rbnReportFormat == 'excel' || this.rbnReportFormat == 'html') {
            if (this.rbnInterestValue == 'volumeQty') {
                //this.showDialog("Parts Consumption Schedule Report Called.");
                this.commonService.setMaintenancePartsForeCostsReportParameters(this.chkCostPerStrategy, this.chkExecutiveSummary, this.chkIntervalSummary, this.chkBOMDetails, this.rbnInterestValue, this.rbnReportFormat);
                this.generatePartsConsumptionReportDlg();
            }
            else if (this.rbnInterestValue == 'Cost') {
                if (this.chkCostPerStrategy) {
                    //this.showDialog("CPH Report Called.");
                    this.commonService.setMaintenancePartsForeCostsReportParameters(this.chkCostPerStrategy, this.chkExecutiveSummary, this.chkIntervalSummary, this.chkBOMDetails, this.rbnInterestValue, this.rbnReportFormat);
                    this.generateCPHReportDlg();
                }
                else {
                    //this.showDialog("ForeCast Report Called.");
                    this.commonService.setMaintenancePartsForeCostsReportParameters(this.chkCostPerStrategy, this.chkExecutiveSummary, this.chkIntervalSummary, this.chkBOMDetails, this.rbnInterestValue, this.rbnReportFormat);
                    this.generateCostForeCastReportDlg();
                }
            }
        }
        //else {
        //    //this.showDialog("Currently HTML report format is not supported.");
        //    //this.selectedEquipmentModelService.show();
        //}
    }

    showDialog(message) {
        this.errorMessage = message;
        this.display = true;
    }

    generateCostForeCastReportDlg(): void {
        if (localStorage.getItem("PriceListType_Report") == "" || localStorage.getItem("PriceList_Report") == "") {
            alert("Please select Price Type and Country in the Option tab.");
        } else {
            this.generateCostReportsService.show();
        }
    }

    generatePartsConsumptionReportDlg(): void {
        if (localStorage.getItem("PriceListType_Report") == "" || localStorage.getItem("PriceList_Report") == "") {
            alert("Please select Price Type and Country in the Option tab.");
        }
        else {
            this.generatereportsservice.show();
        }
    }

    generateCPHReportDlg(): void {
        if (localStorage.getItem("PriceListType_Report") == "" || localStorage.getItem("PriceList_Report") == "") {
            alert("Please select Price Type and Country in the Option tab.");
        }
        else {
            this.generateCostReportsCPHService.show();
        }
    }

    validateReportGeneration(): boolean {
        let disableReport: boolean = false;
        if (this.reportService.getDownloadInProgress()) {
            disableReport = true;
        } else {
            if (parseInt(this.selectEquipmentMasterService.getSelectedEquipment()) > 0) {
                disableReport = this.disableReportschange;
            } else {
                disableReport = true;
            }
        }
        if (this.dataService.getReportsValue('IsengineHrsValue') == false) {
            disableReport = true;
        }
        return disableReport;
    }

}
