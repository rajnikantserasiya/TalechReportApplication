import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportMaintenancePartScheduleComponent } from './report-maintenance-part-schedule.component';

describe('ReportMaintenancePartScheduleComponent', () => {
  let component: ReportMaintenancePartScheduleComponent;
  let fixture: ComponentFixture<ReportMaintenancePartScheduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportMaintenancePartScheduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportMaintenancePartScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
