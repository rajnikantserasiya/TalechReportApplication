import {Component, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable } from '@angular/core';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { ReportService } from '../services/report.service';

@Component({
  selector: 'app-load-old-session-popup',
  templateUrl: './load-old-session-popup.component.html',
  styleUrls: ['./load-old-session-popup.component.css']
})
export class LoadOldSessionPopupComponent  {

    constructor(public activeModal: NgbActiveModal, public changeRef: ChangeDetectorRef, 
        private reportService: ReportService) {
    }
    
    openDialog(): void {
        var closeLoadOldSessionBtn = document.getElementById("closeLoadOldSessionBtn");
        var fileLoaderButton = document.getElementById("fileLoader");
        closeLoadOldSessionBtn.click();        
        fileLoaderButton.click();
        this.reportService.SaveUserLoginTrack("Load Session");
    }
    
}

@Injectable() export class LoadOldSessionDialogService {

    constructor(private modalService: NgbModal) { }

    public show() {
        const modalRef = this.modalService.open(LoadOldSessionPopupComponent);
        modalRef.componentInstance.name = "showlogindlg";
        modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }
}

