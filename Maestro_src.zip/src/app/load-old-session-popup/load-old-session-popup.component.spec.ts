import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoadOldSessionPopupComponent } from './load-old-session-popup.component';

describe('LoadOldSessionPopupComponent', () => {
  let component: LoadOldSessionPopupComponent;
  let fixture: ComponentFixture<LoadOldSessionPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoadOldSessionPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoadOldSessionPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
