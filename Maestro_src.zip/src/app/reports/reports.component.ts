import { Component, OnInit } from '@angular/core';
import { DataService } from './../services/data-component.service';
import { FetchCurrentDataService } from './../services/fetch-current-data.service';
import { AppConstant } from './../app.constant';
import { HtmlResultPoupservice } from '../htmlview/html-result.component';
import {EqExclusionsServiceService} from '../services/eq-exclusions-service.service';


@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css'],
  providers: [HtmlResultPoupservice]
})
export class ReportsComponent implements OnInit {
    contentRestrictionModel = "0"; 
    reportIntervalModel: Number = 500;
    showValidationMessage: boolean = false;
    columnDropdown = [];
    engineHours = "";
    //activeReportTab = "costForecast";
    activeReportTab = "maintenancePartSchedule";

    reportValues = [
        {'id': "0" , 'name': 'None'},
        {'id': "1" , 'name': 'Show Service Items Only'},
        {'id': "2" , 'name': 'Show Main Components Only'},
        {'id': "3" , 'name': 'Exclude non-Fair Wear'} 
    ];
    currentOrientation = 'vertical';

    constructor(private eqExclusionsServiceService: EqExclusionsServiceService,private htmlResultPoupservice: HtmlResultPoupservice, private fetchCurrentDataService: FetchCurrentDataService, private appConstant: AppConstant , private dataService : DataService ) { 
        this.fetchCurrentDataService.screenDataStream$.subscribe(
        () => {
            if (!this.fetchCurrentDataService.disableFlagSaveReports) {
                this.fetchCurrentDataService.disableFlagSaveReports = true;
                if(this.dataService.getReportsValue('contentRestrictionValue').length > 0){
                    this.contentRestrictionModel = this.dataService.getReportsValue('contentRestrictionValue'); 
                }
                this.fetchCurrentDataService.createJsonToSave(this.contentRestrictionModel, this.appConstant.contentRestrictionValue);             
                console.log('Fetching data for Report - Content Restriction');
            }
        });
    }
  
    reportsPartSchedule(): void { }
  
    ngOnInit() {
        this.closeNav(); 
        setTimeout( () => {        
            if(this.dataService.getReportsValue('contentRestrictionValue').length > 0){
                this.contentRestrictionModel = this.dataService.getReportsValue('contentRestrictionValue');             
                localStorage.setItem("ReportFilter", "");
                if( this.contentRestrictionModel.length > 1){
                    if (this.contentRestrictionModel == "None")
                    {
                        localStorage.setItem("ReportFilter", "0");
                    }
                    if (this.contentRestrictionModel == "Show Filters Only") {
                        localStorage.setItem("ReportFilter", "4");
                    }
                    if (this.contentRestrictionModel == "Show Service Items Only") {
                        localStorage.setItem("ReportFilter", "1");
                    }
                    if (this.contentRestrictionModel == "Exclude non-Fair Wear") {
                        localStorage.setItem("ReportFilter", "5");
                    }
                    if (this.contentRestrictionModel == "Show Main Components Only") {
                        localStorage.setItem("ReportFilter", "2");
                    }                    
                } else {
                    localStorage.setItem("ReportFilter",  this.contentRestrictionModel);
                }
                this.contentRestrictionModel = localStorage.getItem("ReportFilter");               
            } else {            
                localStorage.setItem("ReportFilter", "0");
            }                
        }, 100);
        let filterdata = this.dataService.getData(this.appConstant.factorsRoot);
        if (filterdata.length > 0) {
            this.LoadHrsType(filterdata);
        }
        else {
            this.eqExclusionsServiceService.selectedEquipmentFoctorsMaster()
                .then(result => {
                    filterdata = result;
                    this.LoadHrsType(filterdata);
                }
                );
        }
    }

    public restrictZero(e) {
        var key = e.keyCode ? e.keyCode : e.which;     
    }

    startHtmlResult(): void {
        this.closeNav();
        this.htmlResultPoupservice.show();
    }
  
    closeNav() {
        document.getElementById("slide-nav").style.width = "0";
    }
  
    onModelChange(value) {
        this.contentRestrictionModel = value;
        this.dataService.setReportsValue('contentRestrictionValue', value);       
        localStorage.setItem("ReportFilter", "");
        localStorage.setItem("ReportFilter", value);     
    }

    reportIntervalChange(value): any {
        if (value < 50 || value > 9999) {
            this.showValidationMessage = true;         
        } else {
            this.showValidationMessage = false;
            this.reportIntervalModel = value;          
            localStorage.setItem("ReportIntervalTxt", value);
            this.dataService.setReportsValue('partscon_reportInterval', value);
        }
    }

    //  UI Changes
    NumericOnly(e): any {
        if (e.keyCode != 8 && e.keyCode != 0 && (e.keyCode < 48 || e.keyCode > 57)) {           
            return false;
        }
    }


    LoadHrsType(filterdata) {
        var engineHourCount: number = 0;
        var percussionHourcount: number = 0;
        var compressorHourcount: number = 0;
        var powerpackHourcount: number = 0;
        var hydraulicHourcount: number = 0;
        var cachedEngineHourValue : string = "";

        filterdata.forEach(element => {
            if (element['ENGINE'] > 0 && element['ENGINE'] != 'N/A' && element['ENGINE'] != '') {
                engineHourCount++;
            }
            if (element['PERCUSSION'] > 0 && element['PERCUSSION'] != 'N/A' && element['PERCUSSION'] != '') {
                percussionHourcount++;
            }
            if (element['COMPRESSOR'] > 0 && element['COMPRESSOR'] != 'N/A' && element['COMPRESSOR'] != '') {
                compressorHourcount++;
            }
            if (element['POWERPACK'] > 0 && element['POWERPACK'] != 'N/A' && element['POWERPACK'] != '') {
                powerpackHourcount++;
            }
            if (element['GearBox'] > 0 && element['GearBox'] != 'N/A' && element['GearBox'] != '') {
                hydraulicHourcount++;
            }
        });

        if (filterdata.length > 1) {
            if (engineHourCount > 1 && filterdata.length == engineHourCount) {
                this.columnDropdown.push('Engine Hours');
            }
            if (percussionHourcount > 1 && filterdata.length == percussionHourcount) {
                this.columnDropdown.push('Percussion Hours');
            }
            if (compressorHourcount > 1 && filterdata.length == compressorHourcount) {
                this.columnDropdown.push('Compressor Hours');
            }
            if (powerpackHourcount > 1 && filterdata.length == powerpackHourcount) {
                this.columnDropdown.push('Powerpack Hours');
            }
            if (hydraulicHourcount > 1 && filterdata.length == hydraulicHourcount) {
                this.columnDropdown.push('Hydraulic Hours');
            }
        }
        else {
            if (engineHourCount > 0) {
                this.columnDropdown.push('Engine Hours');
            }
            if (percussionHourcount > 0) {
                this.columnDropdown.push('Percussion Hours');
            }
            if (compressorHourcount > 0) {
                this.columnDropdown.push('Compressor Hours');
            }
            if (powerpackHourcount > 0) {
                this.columnDropdown.push('Powerpack Hours');
            }
            if (hydraulicHourcount > 0) {
                this.columnDropdown.push('Hydraulic Hours');
            }
        }

        if (this.columnDropdown.length == 0) {
            this.dataService.setReportsValue('IsengineHrsValue', false);
        }
        else      
        {   
            cachedEngineHourValue = this.dataService.getReportsValue('engineHrsValue');
            if(cachedEngineHourValue.length > 0){
                this.engineHours = this.dataService.getReportsValue('engineHrsValue');
            } else {
                this.engineHours = this.columnDropdown[0];
                this.dataService.setReportsValue('engineHrsValue', this.columnDropdown[0]); 
            }        
            this.dataService.setReportsValue('IsengineHrsValue', true);
            if (this.dataService.getReportsValue('partscon_reportInterval') > 0) {
                this.reportIntervalModel = this.dataService.getReportsValue('partscon_reportInterval');
            }
            localStorage.setItem("ReportIntervalTxt", "");
            localStorage.setItem("ReportHrsType", "");
            localStorage.setItem("ReportIntervalTxt", this.reportIntervalModel.toString());
            if (this.engineHours == "Engine Hours") {
                localStorage.setItem("ReportHrsType", "ENG");
            }
            if (this.engineHours == "Percussion Hours") {
                localStorage.setItem("ReportHrsType", "PERC");
            }
            if (this.engineHours == "Compressor Hours") {
                localStorage.setItem("ReportHrsType", "COMP");
            }
            if (this.engineHours == "Powerpack Hours") {
                localStorage.setItem("ReportHrsType", "PPACK");
            }
            if (this.engineHours == "Hydraulic Hours") {
                localStorage.setItem("ReportHrsType", "GRBX");
            }
        }
    }

    onHrsTypeModelChange(event) {
        this.dataService.setReportsValue('engineHrsValue', event.target.value); 
        var ReportIntervalTxt = (<HTMLInputElement>document.getElementById("reportIntervalTxt"));
        var ReportHrsType = (<HTMLInputElement>document.getElementById("engineHoursSelect"));
        localStorage.setItem("ReportIntervalTxt", "");
        localStorage.setItem("ReportHrsType", "");
        localStorage.setItem("ReportIntervalTxt", ReportIntervalTxt.value);
        if (ReportHrsType.value == "Engine Hours") {
            localStorage.setItem("ReportHrsType", "ENG");
        }
        if (ReportHrsType.value == "Percussion Hours") {
            localStorage.setItem("ReportHrsType", "PERC");
        }
        if (ReportHrsType.value == "Compressor Hours") {
            localStorage.setItem("ReportHrsType", "COMP");
        }
        if (ReportHrsType.value == "Powerpack Hours") {
            localStorage.setItem("ReportHrsType", "PPACK");
        }
        if (ReportHrsType.value == "Hydraulic Hours") {
            localStorage.setItem("ReportHrsType", "GRBX");
        }     
        this.dataService.setReportsValue('partscon_colDropdown', event.target.value);
    }

    validateReportGeneration(): boolean {
        let disableReport: boolean = false;
        if (this.columnDropdown.length == 0) {
            var generateReportBtn = (<HTMLInputElement>document.getElementById("generateReportBtn"));
            generateReportBtn.disabled = true;
        }
        return disableReport;
    }

    getActiveTab(event) {
        if(event.nextId) {
            this.activeReportTab = event.nextId;
        }
    }

    showActiveTab(tab) {
        return tab === this.activeReportTab;
    }



}
