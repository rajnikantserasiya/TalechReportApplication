import {Component, Input, OnInit, ApplicationRef, ChangeDetectorRef, Injectable } from '@angular/core';
import {NgbModal, NgbModalOptions, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { DataService } from './../services/data-component.service';

import { ReportService } from '../services/report.service';

@Component({
  selector: 'app-continue-existing-session-popup',
  templateUrl: './continue-existing-session-popup.component.html',
  styleUrls: ['./continue-existing-session-popup.component.css']
})
export class ContinueExistingSessionPopupComponent {

  constructor(public activeModal: NgbActiveModal, public changeRef: ChangeDetectorRef, 
    private maestroRouter: Router , private dataService : DataService, 
    private reportService : ReportService) { }

  onContinueClicked(): void {
    var closeLoginBtn = document.getElementById("closeContinueSessionBtn");
    localStorage.removeItem("COUNTRY");
    console.log("continue existing session");    
    closeLoginBtn.click();    
    this.dataService.clearReferenceForList(true);    
    this.maestroRouter.navigateByUrl('contsession');  
    this.reportService.SaveUserLoginTrack("Continue Existing Session");	  
  }

}

@Injectable() export class ContinueExistingSessionDialogService {

    constructor(private modalService: NgbModal) { }

    public show() {
        const modalRef = this.modalService.open(ContinueExistingSessionPopupComponent);
        modalRef.componentInstance.name = "showlogindlg";
        modalRef.componentInstance.changeRef.markForCheck();
        return modalRef.result;
    }
}