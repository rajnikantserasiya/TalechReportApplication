import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContinueExistingSessionPopupComponent } from './continue-existing-session-popup.component';

describe('ContinueExistingSessionPopupComponent', () => {
  let component: ContinueExistingSessionPopupComponent;
  let fixture: ComponentFixture<ContinueExistingSessionPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContinueExistingSessionPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContinueExistingSessionPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
