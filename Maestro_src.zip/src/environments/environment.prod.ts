export const environment = {
    production: true,
	
    //apiUrl: 'https://maestrosessionwebapi20180404030633.azurewebsites.net/api/v1.0/',
	
    //apiUrl: 'https://maestrowebapith540.azurewebsites.net/api/v1.0/',
    apiUrl: 'https://maestrosessionwebapi20180331035118.azurewebsites.net/api/v1.0/',
    //apiUrl: 'https://maestrosessionwebapiauth.azurewebsites.net/api/v1.0/',
	
    authenticationUrl: 'https://authenticationwebapi20180331035517.azurewebsites.net/api/v1.0/Authentication/'
	
};
