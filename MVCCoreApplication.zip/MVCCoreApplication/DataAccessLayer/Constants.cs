﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLayer
{
    public class Constants
    {
        public const string LoginUser_SP = "";
    }
}
